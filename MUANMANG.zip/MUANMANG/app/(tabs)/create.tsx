import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { Camera, Music, Palette, Video, Mic, Image } from 'lucide-react-native';
import Header from '@/components/Header';
import CreatorToolCard from '@/components/CreatorToolCard';

const creatorTools = [
  {
    id: '1',
    title: 'Editor de Video',
    description: 'Crea contenido audiovisual con efectos africanos únicos',
    icon: Video,
    colors: ['#FF6B35', '#F7931E'],
  },
  {
    id: '2',
    title: 'Beat Maker',
    description: 'Produce beats con samples de música tradicional africana',
    icon: Music,
    colors: ['#8B5CF6', '#A855F7'],
  },
  {
    id: '3',
    title: 'Diseño Gráfico',
    description: 'Diseña con patrones y elementos culturales africanos',
    icon: Palette,
    colors: ['#10B981', '#059669'],
  },
  {
    id: '4',
    title: 'Photo Studio',
    description: 'Edita fotos con filtros inspirados en África',
    icon: Image,
    colors: ['#F59E0B', '#D97706'],
  },
  {
    id: '5',
    title: 'Grabador de Audio',
    description: 'Graba podcasts, voces y efectos de sonido',
    icon: Mic,
    colors: ['#EF4444', '#DC2626'],
  },
  {
    id: '6',
    title: 'Cámara Pro',
    description: 'Captura momentos con herramientas profesionales',
    icon: Camera,
    colors: ['#06B6D4', '#0891B2'],
  },
];

export default function CreateScreen() {
  const handleToolPress = (toolId: string) => {
    console.log(`Opening tool: ${toolId}`);
    // Aquí implementarías la navegación a cada herramienta
  };

  return (
    <View style={styles.container}>
      <Header title="Creator Studio" showSearch={false} />
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.welcome}>
          <Text style={styles.welcomeTitle}>¡Crea contenido increíble!</Text>
          <Text style={styles.welcomeSubtitle}>
            Herramientas profesionales para dar vida a tu creatividad cultural
          </Text>
        </View>

        <View style={styles.stats}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>2.4K</Text>
            <Text style={styles.statLabel}>Seguidores</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>156</Text>
            <Text style={styles.statLabel}>Creaciones</Text>
          </View>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>89K</Text>
            <Text style={styles.statLabel}>Vistas</Text>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Herramientas de Creación</Text>
        
        <View style={styles.toolsContainer}>
          {creatorTools.map((tool) => (
            <CreatorToolCard
              key={tool.id}
              title={tool.title}
              description={tool.description}
              icon={tool.icon}
              colors={tool.colors}
              onPress={() => handleToolPress(tool.id)}
            />
          ))}
        </View>

        <View style={styles.inspiration}>
          <Text style={styles.inspirationTitle}>💡 Inspiración del día</Text>
          <Text style={styles.inspirationText}>
            "La creatividad africana no tiene límites. Cada diseño, cada beat, cada historia 
            que compartes ayuda a preservar y evolucionar nuestra rica cultura."
          </Text>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  welcome: {
    paddingVertical: 30,
    alignItems: 'center',
  },
  welcomeTitle: {
    fontSize: 28,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 10,
  },
  welcomeSubtitle: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#999',
    textAlign: 'center',
    lineHeight: 24,
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    padding: 20,
    marginBottom: 30,
    borderWidth: 1,
    borderColor: '#333',
  },
  statItem: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontFamily: 'Ubuntu-Bold',
    color: '#FF6B35',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#999',
    marginTop: 5,
  },
  sectionTitle: {
    fontSize: 22,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    marginBottom: 20,
  },
  toolsContainer: {
    marginBottom: 30,
  },
  inspiration: {
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    padding: 20,
    marginBottom: 100,
    borderWidth: 1,
    borderColor: '#333',
  },
  inspirationTitle: {
    fontSize: 18,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    marginBottom: 15,
  },
  inspirationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#999',
    lineHeight: 22,
  },
});