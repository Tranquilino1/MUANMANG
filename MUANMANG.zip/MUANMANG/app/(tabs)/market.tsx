import React, { useState } from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, TextInput } from 'react-native';
import { Search, Filter, Grid2x2 as Grid, List } from 'lucide-react-native';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';

const mockProducts = [
  {
    id: '1',
    name: 'Camiseta Afro-Urban Limited Edition',
    price: 27000,
    image: 'https://images.pexels.com/photos/1148960/pexels-photo-1148960.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2',
    seller: 'Designer Kofi',
    rating: 4.8,
    category: 'Fashion',
  },
  {
    id: '2',
    name: 'Beat Pack Afrobeat Fusion',
    price: 15000,
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2',
    seller: 'Producer Amina',
    rating: 4.9,
    category: 'Music',
  },
  {
    id: '3',
    name: 'Collar Artesanal Africano',
    price: 21000,
    image: 'https://images.pexels.com/photos/1191531/pexels-photo-1191531.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2',
    seller: 'Artesana Nia',
    rating: 4.7,
    category: 'Accessories',
  },
  {
    id: '4',
    name: 'Preset Pack Urban Photography',
    price: 12000,
    image: 'https://images.pexels.com/photos/1193743/pexels-photo-1193743.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2',
    seller: 'Photo Kwame',
    rating: 4.6,
    category: 'Digital',
  },
  {
    id: '5',
    name: 'Gorra Snapback Afro-Style',
    price: 18000,
    image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2',
    seller: 'Urban Jabari',
    rating: 4.5,
    category: 'Fashion',
  },
  {
    id: '6',
    name: 'Logo Pack Cultural Designs',
    price: 24000,
    image: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=400&h=400&dpr=2',
    seller: 'Graphics Zara',
    rating: 4.8,
    category: 'Digital',
  },
];

const categories = ['Todo', 'Moda', 'Música', 'Digital', 'Arte', 'Accesorios'];

export default function MarketScreen() {
  const [selectedCategory, setSelectedCategory] = useState('Todo');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredProducts = mockProducts.filter(product => {
    const matchesCategory = selectedCategory === 'Todo' || product.category === selectedCategory;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <View style={styles.container}>
      <Header title="Market" />
      
      <View style={styles.content}>
        {/* Search Bar */}
        <View style={styles.searchContainer}>
          <View style={styles.searchBar}>
            <Search size={20} color="#999" />
            <TextInput
              style={styles.searchInput}
              placeholder="Buscar en el mercado..."
              placeholderTextColor="#999"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
          <TouchableOpacity style={styles.filterButton}>
            <Filter size={20} color="#FF6B35" />
          </TouchableOpacity>
        </View>

        {/* Categories */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoriesContainer}>
          <View style={styles.categories}>
            {categories.map((category) => (
              <TouchableOpacity
                key={category}
                style={[
                  styles.categoryButton,
                  selectedCategory === category && styles.activeCategoryButton,
                ]}
                onPress={() => setSelectedCategory(category)}
              >
                <Text
                  style={[
                    styles.categoryText,
                    selectedCategory === category && styles.activeCategoryText,
                  ]}
                >
                  {category}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>

        {/* View Toggle */}
        <View style={styles.viewToggle}>
          <Text style={styles.resultsText}>{filteredProducts.length} productos</Text>
          <View style={styles.toggleButtons}>
            <TouchableOpacity
              style={[styles.toggleButton, viewMode === 'grid' && styles.activeToggleButton]}
              onPress={() => setViewMode('grid')}
            >
              <Grid size={16} color={viewMode === 'grid' ? 'white' : '#999'} />
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.toggleButton, viewMode === 'list' && styles.activeToggleButton]}
              onPress={() => setViewMode('list')}
            >
              <List size={16} color={viewMode === 'list' ? 'white' : '#999'} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Products Grid */}
        <ScrollView style={styles.productsContainer} showsVerticalScrollIndicator={false}>
          <View style={styles.productsGrid}>
            {filteredProducts.map((product) => (
              <View key={product.id} style={styles.productWrapper}>
                <ProductCard product={product} />
              </View>
            ))}
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    gap: 15,
    marginVertical: 20,
  },
  searchBar: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 12,
    gap: 10,
    borderWidth: 1,
    borderColor: '#333',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: 'white',
  },
  filterButton: {
    backgroundColor: '#1a1a1a',
    borderRadius: 25,
    padding: 12,
    borderWidth: 1,
    borderColor: '#333',
  },
  categoriesContainer: {
    marginBottom: 20,
  },
  categories: {
    flexDirection: 'row',
    gap: 10,
  },
  categoryButton: {
    backgroundColor: '#1a1a1a',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  activeCategoryButton: {
    backgroundColor: '#FF6B35',
    borderColor: '#FF6B35',
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#999',
  },
  activeCategoryText: {
    color: 'white',
  },
  viewToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  resultsText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  toggleButtons: {
    flexDirection: 'row',
    backgroundColor: '#1a1a1a',
    borderRadius: 20,
    padding: 2,
  },
  toggleButton: {
    padding: 8,
    borderRadius: 18,
  },
  activeToggleButton: {
    backgroundColor: '#FF6B35',
  },
  productsContainer: {
    flex: 1,
  },
  productsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    paddingBottom: 100,
  },
  productWrapper: {
    width: '48%',
  },
});