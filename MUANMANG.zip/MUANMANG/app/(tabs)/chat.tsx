import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Search, MoveVertical as MoreVertical, Circle } from 'lucide-react-native';
import Header from '@/components/Header';

const mockChats = [
  {
    id: '1',
    user: {
      name: 'Amina Cultura',
      avatar: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      online: true,
    },
    lastMessage: '¡Me encanta tu último beat! 🔥',
    timestamp: '10:30',
    unread: 2,
  },
  {
    id: '2',
    user: {
      name: 'Designer Kofi',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      online: false,
    },
    lastMessage: 'Podemos colaborar en el próximo proyecto?',
    timestamp: 'Ayer',
    unread: 0,
  },
  {
    id: '3',
    user: {
      name: 'Grupo: Artistas GQ',
      avatar: 'https://images.pexels.com/photos/1689731/pexels-photo-1689731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      online: false,
    },
    lastMessage: 'MC Urbano: Challenge aceptado! 💪',
    timestamp: 'Ayer',
    unread: 5,
    isGroup: true,
  },
  {
    id: '4',
    user: {
      name: 'Producer Kwame',
      avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      online: true,
    },
    lastMessage: 'Los samples están listos para descarga',
    timestamp: '2 días',
    unread: 0,
  },
  {
    id: '5',
    user: {
      name: 'Nia Artesana',
      avatar: 'https://images.pexels.com/photos/1689731/pexels-photo-1689731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      online: false,
    },
    lastMessage: 'Gracias por comprar mi collar! ✨',
    timestamp: '3 días',
    unread: 0,
  },
];

export default function ChatScreen() {
  return (
    <View style={styles.container}>
      <Header title="Chat" />
      
      <View style={styles.content}>
        {/* Search */}
        <TouchableOpacity style={styles.searchBar}>
          <Search size={20} color="#999" />
          <Text style={styles.searchPlaceholder}>Buscar conversaciones...</Text>
        </TouchableOpacity>

        {/* Online Users */}
        <View style={styles.onlineSection}>
          <Text style={styles.sectionTitle}>Activos ahora</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.onlineUsers}>
              {mockChats.filter(chat => chat.user.online && !chat.isGroup).map((chat) => (
                <TouchableOpacity key={chat.id} style={styles.onlineUser}>
                  <View style={styles.onlineAvatarContainer}>
                    <Image source={{ uri: chat.user.avatar }} style={styles.onlineAvatar} />
                    <View style={styles.onlineIndicator} />
                  </View>
                  <Text style={styles.onlineUserName} numberOfLines={1}>
                    {chat.user.name.split(' ')[0]}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Chats List */}
        <View style={styles.chatsSection}>
          <Text style={styles.sectionTitle}>Mensajes</Text>
          <ScrollView showsVerticalScrollIndicator={false}>
            {mockChats.map((chat) => (
              <TouchableOpacity key={chat.id} style={styles.chatItem}>
                <View style={styles.avatarContainer}>
                  <Image source={{ uri: chat.user.avatar }} style={styles.avatar} />
                  {chat.user.online && !chat.isGroup && (
                    <View style={styles.onlineIndicator} />
                  )}
                </View>
                
                <View style={styles.chatContent}>
                  <View style={styles.chatHeader}>
                    <Text style={styles.userName}>{chat.user.name}</Text>
                    <Text style={styles.timestamp}>{chat.timestamp}</Text>
                  </View>
                  <View style={styles.chatFooter}>
                    <Text style={styles.lastMessage} numberOfLines={1}>
                      {chat.lastMessage}
                    </Text>
                    {chat.unread > 0 && (
                      <View style={styles.unreadBadge}>
                        <Text style={styles.unreadCount}>{chat.unread}</Text>
                      </View>
                    )}
                  </View>
                </View>
                
                <TouchableOpacity style={styles.moreButton}>
                  <MoreVertical size={18} color="#666" />
                </TouchableOpacity>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1a1a1a',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 12,
    gap: 10,
    marginVertical: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  searchPlaceholder: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#999',
  },
  onlineSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    marginBottom: 15,
  },
  onlineUsers: {
    flexDirection: 'row',
    gap: 15,
  },
  onlineUser: {
    alignItems: 'center',
    width: 70,
  },
  onlineAvatarContainer: {
    position: 'relative',
    marginBottom: 8,
  },
  onlineAvatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  onlineIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#00D924',
    borderWidth: 2,
    borderColor: '#000',
  },
  onlineUserName: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    textAlign: 'center',
  },
  chatsSection: {
    flex: 1,
  },
  chatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#1a1a1a',
  },
  avatarContainer: {
    position: 'relative',
    marginRight: 15,
  },
  avatar: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  chatContent: {
    flex: 1,
  },
  chatHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 5,
  },
  userName: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  timestamp: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#666',
  },
  chatFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  lastMessage: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#999',
    flex: 1,
    marginRight: 10,
  },
  unreadBadge: {
    backgroundColor: '#FF6B35',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
  },
  unreadCount: {
    fontSize: 11,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  moreButton: {
    padding: 5,
    marginLeft: 10,
  },
});