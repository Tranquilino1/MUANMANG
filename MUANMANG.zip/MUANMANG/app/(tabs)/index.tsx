import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, FlatList, RefreshControl, TouchableOpacity } from 'react-native';
import { Filter } from 'lucide-react-native';
import Header from '@/components/Header';
import StoryCard from '@/components/StoryCard';
import PostCard from '@/components/PostCard';
import CategoryTabs from '@/components/CategoryTabs';
import FilterSidebar from '@/components/FilterSidebar';

const mockStories = [
  { id: '1', user: { name: 'Kwame', avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2' } },
  { id: '2', user: { name: 'Amara', avatar: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2', isLive: true } },
  { id: '3', user: { name: 'Kofi', avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2' } },
  { id: '4', user: { name: 'Nia', avatar: 'https://images.pexels.com/photos/1689731/pexels-photo-1689731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2' } },
  { id: '5', user: { name: 'Jabari', avatar: 'https://images.pexels.com/photos/1722198/pexels-photo-1722198.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2', isLive: true } },
  { id: '6', user: { name: 'Zara', avatar: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2' } },
];

const mockPosts = [
  {
    id: '1',
    user: {
      name: 'Amina Cultura',
      avatar: 'https://images.pexels.com/photos/1382731/pexels-photo-1382731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      verified: true,
      location: 'Malabo, Guinea Ecuatorial',
    },
    content: '🎵 Nuevo beat fusionando ritmos tradicionales con afrobeats moderno! La cultura ecuatoguineana sigue evolucionando y conquistando el mundo. ¿Qué opinan de esta fusión? 🔥🇬🇶',
    image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2',
    likes: 1247,
    comments: 89,
    timeAgo: '2h',
    tags: ['afrobeats', 'GuineaEcuatorial', 'cultura', 'música', 'tradición'],
    music: '🎵 Ritmos de Malabo - Amina Cultura',
    category: 'Música',
  },
  {
    id: '2',
    user: {
      name: 'Designer Kofi',
      avatar: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      location: 'Bata, Guinea Ecuatorial',
    },
    content: 'Nueva colección de streetwear inspirada en los patrones tradicionales fang y bubi. Cada diseño cuenta la historia de nuestros ancestros con un toque urbano moderno. Arte que trasciende fronteras! 🌍✨',
    image: 'https://images.pexels.com/photos/1148960/pexels-photo-1148960.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2',
    likes: 892,
    comments: 156,
    timeAgo: '4h',
    tags: ['fashion', 'streetwear', 'diseño', 'fang', 'bubi', 'arte'],
    category: 'Arte',
  },
  {
    id: '3',
    user: {
      name: 'Chef Ebebiyín',
      avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      location: 'Ebebiyín, Guinea Ecuatorial',
    },
    content: 'Preparando el tradicional "Succotash" ecuatoguineano con un twist moderno. Los sabores de nuestra tierra nunca pasan de moda. Receta completa en mi perfil! 👨‍🍳🍽️',
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2',
    likes: 634,
    comments: 78,
    timeAgo: '6h',
    tags: ['gastronomía', 'tradición', 'cocina', 'GuineaEcuatorial', 'recetas'],
    category: 'Gastronomía',
  },
  {
    id: '4',
    user: {
      name: 'Artista Malabo',
      avatar: 'https://images.pexels.com/photos/1689731/pexels-photo-1689731.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      verified: true,
      location: 'Malabo, Guinea Ecuatorial',
    },
    content: 'Mural terminado en el centro de Malabo! Representa la unión entre nuestras tres etnias principales: Fang, Bubi y Ndowe. El arte urbano como puente cultural 🎨🌈',
    image: 'https://images.pexels.com/photos/1193743/pexels-photo-1193743.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2',
    likes: 1456,
    comments: 203,
    timeAgo: '8h',
    tags: ['arte', 'mural', 'cultura', 'Malabo', 'unidad', 'etnias'],
    category: 'Arte',
  },
  {
    id: '5',
    user: {
      name: 'Eventos GQ',
      avatar: 'https://images.pexels.com/photos/1722198/pexels-photo-1722198.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2',
      location: 'Malabo, Guinea Ecuatorial',
    },
    content: '🎉 ¡Festival de Cultura Urbana GQ 2024 confirmado! 3 días de música, arte, gastronomía y moda. Del 15 al 17 de marzo en Malabo. ¡Entradas ya disponibles! 🎫',
    image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&dpr=2',
    likes: 2103,
    comments: 445,
    timeAgo: '12h',
    tags: ['festival', 'eventos', 'cultura', 'música', 'arte', 'Malabo2024'],
    category: 'Eventos',
  },
];

export default function HomeScreen() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('tendencias');
  const [filterVisible, setFilterVisible] = useState(false);
  const [filteredPosts, setFilteredPosts] = useState(mockPosts);
  const [searchQuery, setSearchQuery] = useState('');

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    // Simulate API call
    setTimeout(() => {
      setRefreshing(false);
    }, 2000);
  }, []);

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category);
    filterPosts(category, searchQuery);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    filterPosts(selectedCategory, query);
  };

  const filterPosts = (category: string, query: string) => {
    let filtered = mockPosts;

    // Filter by category
    if (category !== 'tendencias') {
      const categoryMap: { [key: string]: string } = {
        'arte': 'Arte',
        'cultura': 'Cultura',
        'gastronomia': 'Gastronomía',
        'musica': 'Música',
        'eventos': 'Eventos'
      };
      filtered = filtered.filter(post => post.category === categoryMap[category]);
    }

    // Filter by search query
    if (query) {
      filtered = filtered.filter(post => 
        post.content.toLowerCase().includes(query.toLowerCase()) ||
        post.tags?.some(tag => tag.toLowerCase().includes(query.toLowerCase())) ||
        post.user.name.toLowerCase().includes(query.toLowerCase())
      );
    }

    setFilteredPosts(filtered);
  };

  const handleFiltersApply = (filters: any) => {
    // Apply additional filters here
    console.log('Filters applied:', filters);
  };

  const renderStory = ({ item, index }: { item: any; index: number }) => {
    if (index === 0) {
      return <StoryCard isAddStory isDarkMode={isDarkMode} />;
    }
    return <StoryCard user={item.user} isDarkMode={isDarkMode} />;
  };

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#1a1a1a' : '#F8F9FA' }]}>
      <Header 
        isDarkMode={isDarkMode}
        onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        onSearch={handleSearch}
      />
      
      <CategoryTabs 
        onCategoryChange={handleCategoryChange}
        isDarkMode={isDarkMode}
      />

      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Stories Section */}
        <View style={styles.storiesSection}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
              Historias
            </Text>
            <TouchableOpacity 
              style={styles.filterButton}
              onPress={() => setFilterVisible(true)}
            >
              <Filter size={18} color={isDarkMode ? 'white' : '#2C3E50'} />
            </TouchableOpacity>
          </View>
          <FlatList
            data={[{}, ...mockStories]}
            renderItem={renderStory}
            keyExtractor={(item, index) => index.toString()}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.storiesList}
          />
        </View>

        {/* Trending Hashtags */}
        <View style={styles.trendingSection}>
          <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
            🔥 Tendencias en Guinea Ecuatorial
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.trendingTags}>
              {[
                '#GuineaEcuatorial', '#MalaboCulture', '#AfroBeatsGQ', 
                '#CulturaFang', '#ArteBubi', '#GastronomíaGQ', '#EventosGQ'
              ].map((tag, index) => (
                <TouchableOpacity key={index} style={styles.trendingTag}>
                  <Text style={styles.trendingTagText}>{tag}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Posts Section */}
        <View style={styles.postsSection}>
          <View style={styles.postsSectionHeader}>
            <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
              {selectedCategory === 'tendencias' ? 'Feed Principal' : `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}`}
            </Text>
            <Text style={[styles.postsCount, { color: isDarkMode ? '#BDC3C7' : '#7F8C8D' }]}>
              {filteredPosts.length} publicaciones
            </Text>
          </View>
          
          {filteredPosts.length === 0 ? (
            <View style={styles.emptyState}>
              <Text style={[styles.emptyStateText, { color: isDarkMode ? '#BDC3C7' : '#7F8C8D' }]}>
                No se encontraron publicaciones para esta categoría
              </Text>
            </View>
          ) : (
            filteredPosts.map((post) => (
              <PostCard key={post.id} post={post} isDarkMode={isDarkMode} />
            ))
          )}
        </View>
      </ScrollView>

      <FilterSidebar
        visible={filterVisible}
        onClose={() => setFilterVisible(false)}
        onFiltersApply={handleFiltersApply}
        isDarkMode={isDarkMode}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  storiesSection: {
    paddingVertical: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Ubuntu-Bold',
  },
  filterButton: {
    padding: 8,
    backgroundColor: 'rgba(0, 158, 73, 0.1)',
    borderRadius: 20,
  },
  storiesList: {
    paddingHorizontal: 20,
  },
  trendingSection: {
    paddingBottom: 20,
  },
  trendingTags: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    gap: 10,
  },
  trendingTag: {
    backgroundColor: '#009E49',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  trendingTagText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  postsSection: {
    paddingHorizontal: 20,
    paddingBottom: 100,
  },
  postsSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  postsCount: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyStateText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    textAlign: 'center',
  },
});