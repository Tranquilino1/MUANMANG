import React from 'react';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Settings, Award, Users, TrendingUp, Calendar, MapPin, Link } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Header from '@/components/Header';

const achievements = [
  { id: '1', name: 'Creator Pioneer', description: 'Primer contenido publicado', icon: '🎨' },
  { id: '2', name: 'Viral Star', description: '+10K vistas en un post', icon: '🌟' },
  { id: '3', name: 'Community Builder', description: '500+ seguidores', icon: '👥' },
  { id: '4', name: 'Culture Ambassador', description: 'Contenido cultural destacado', icon: '🏆' },
];

const recentPosts = [
  { id: '1', image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2', likes: 234 },
  { id: '2', image: 'https://images.pexels.com/photos/1148960/pexels-photo-1148960.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2', likes: 156 },
  { id: '3', image: 'https://images.pexels.com/photos/1191531/pexels-photo-1191531.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2', likes: 189 },
  { id: '4', image: 'https://images.pexels.com/photos/1193743/pexels-photo-1193743.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2', likes: 267 },
  { id: '5', image: 'https://images.pexels.com/photos/1040945/pexels-photo-1040945.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2', likes: 145 },
  { id: '6', image: 'https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2', likes: 298 },
];

export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Header title="Mi Perfil" showSearch={false} />
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Profile Header */}
        <View style={styles.profileHeader}>
          <LinearGradient
            colors={['#FF6B35', '#F7931E', '#FFD700']}
            style={styles.avatarBorder}
          >
            <Image
              source={{ uri: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&dpr=2' }}
              style={styles.avatar}
            />
          </LinearGradient>
          
          <Text style={styles.name}>Kwame Creator</Text>
          <Text style={styles.username}>@kwame_urban</Text>
          
          <View style={styles.location}>
            <MapPin size={14} color="#999" />
            <Text style={styles.locationText}>Malabo, Guinea Ecuatorial</Text>
          </View>
          
          <Text style={styles.bio}>
            🎵 Productor musical | 🎨 Diseñador urbano | 🌍 Embajador de la cultura africana
            Fusionando tradición con modernidad
          </Text>
          
          <TouchableOpacity style={styles.websiteLink}>
            <Link size={14} color="#FF6B35" />
            <Text style={styles.websiteLinkText}>kwamebeats.com</Text>
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View style={styles.stats}>
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>2.4K</Text>
            <Text style={styles.statLabel}>Seguidores</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>1.8K</Text>
            <Text style={styles.statLabel}>Siguiendo</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>156</Text>
            <Text style={styles.statLabel}>Posts</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statNumber}>89K</Text>
            <Text style={styles.statLabel}>Likes</Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.editButton}>
            <Text style={styles.editButtonText}>Editar Perfil</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.settingsButton}>
            <Settings size={20} color="#999" />
          </TouchableOpacity>
        </View>

        {/* Achievements */}
        <View style={styles.achievementsSection}>
          <Text style={styles.sectionTitle}>🏆 Logros</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            <View style={styles.achievements}>
              {achievements.map((achievement) => (
                <View key={achievement.id} style={styles.achievementCard}>
                  <Text style={styles.achievementIcon}>{achievement.icon}</Text>
                  <Text style={styles.achievementName}>{achievement.name}</Text>
                  <Text style={styles.achievementDescription}>{achievement.description}</Text>
                </View>
              ))}
            </View>
          </ScrollView>
        </View>

        {/* Analytics Preview */}
        <View style={styles.analyticsSection}>
          <Text style={styles.sectionTitle}>📊 Estadísticas del mes</Text>
          <View style={styles.analyticsCards}>
            <View style={styles.analyticsCard}>
              <TrendingUp size={24} color="#00D924" />
              <Text style={styles.analyticsNumber}>+25%</Text>
              <Text style={styles.analyticsLabel}>Crecimiento</Text>
            </View>
            <View style={styles.analyticsCard}>
              <Users size={24} color="#FF6B35" />
              <Text style={styles.analyticsNumber}>45K</Text>
              <Text style={styles.analyticsLabel}>Alcance</Text>
            </View>
            <View style={styles.analyticsCard}>
              <Award size={24} color="#FFD700" />
              <Text style={styles.analyticsNumber}>4.8</Text>
              <Text style={styles.analyticsLabel}>Rating</Text>
            </View>
          </View>
        </View>

        {/* Recent Posts Grid */}
        <View style={styles.postsSection}>
          <View style={styles.postsSectionHeader}>
            <Text style={styles.sectionTitle}>Mis Creaciones</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>Ver todo</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.postsGrid}>
            {recentPosts.map((post) => (
              <TouchableOpacity key={post.id} style={styles.postItem}>
                <Image source={{ uri: post.image }} style={styles.postImage} />
                <View style={styles.postOverlay}>
                  <Text style={styles.postLikes}>{post.likes}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
  },
  content: {
    flex: 1,
  },
  profileHeader: {
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 30,
  },
  avatarBorder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    padding: 4,
    marginBottom: 15,
  },
  avatar: {
    width: 112,
    height: 112,
    borderRadius: 56,
  },
  name: {
    fontSize: 24,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    marginBottom: 5,
  },
  username: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#999',
    marginBottom: 10,
  },
  location: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginBottom: 15,
  },
  locationText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: '#999',
  },
  bio: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
    color: 'white',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 15,
  },
  websiteLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  websiteLinkText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FF6B35',
  },
  stats: {
    flexDirection: 'row',
    backgroundColor: '#1a1a1a',
    marginHorizontal: 20,
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#333',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statDivider: {
    width: 1,
    backgroundColor: '#333',
    marginHorizontal: 10,
  },
  statNumber: {
    fontSize: 20,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#999',
    marginTop: 5,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 15,
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  editButton: {
    flex: 1,
    backgroundColor: '#FF6B35',
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: 'center',
  },
  editButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
  settingsButton: {
    backgroundColor: '#1a1a1a',
    padding: 12,
    borderRadius: 25,
    borderWidth: 1,
    borderColor: '#333',
  },
  achievementsSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    marginBottom: 15,
    paddingHorizontal: 20,
  },
  achievements: {
    flexDirection: 'row',
    gap: 15,
    paddingHorizontal: 20,
  },
  achievementCard: {
    backgroundColor: '#1a1a1a',
    width: 120,
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
  achievementIcon: {
    fontSize: 30,
    marginBottom: 8,
  },
  achievementName: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    textAlign: 'center',
    marginBottom: 5,
  },
  achievementDescription: {
    fontSize: 10,
    fontFamily: 'Inter-Regular',
    color: '#999',
    textAlign: 'center',
  },
  analyticsSection: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  analyticsCards: {
    flexDirection: 'row',
    gap: 15,
  },
  analyticsCard: {
    flex: 1,
    backgroundColor: '#1a1a1a',
    padding: 20,
    borderRadius: 15,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#333',
  },
  analyticsNumber: {
    fontSize: 18,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    marginTop: 8,
  },
  analyticsLabel: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#999',
    marginTop: 5,
  },
  postsSection: {
    paddingHorizontal: 20,
    paddingBottom: 100,
  },
  postsSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  seeAllText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#FF6B35',
  },
  postsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  postItem: {
    width: '31%',
    aspectRatio: 1,
    position: 'relative',
  },
  postImage: {
    width: '100%',
    height: '100%',
    borderRadius: 10,
  },
  postOverlay: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  postLikes: {
    fontSize: 11,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});