import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { marketService } from './market';
import { profileService } from './profile';
import { categoriesService } from './categories';

export interface SEOMetadata {
  title: string;
  description: string;
  keywords: string[];
  ogImage?: string;
  ogTitle?: string;
  ogDescription?: string;
  canonicalUrl?: string;
  robots?: string;
  structuredData?: Record<string, any>;
}

export interface SitemapEntry {
  url: string;
  lastModified: Date;
  changeFrequency: 'always' | 'hourly' | 'daily' | 'weekly' | 'monthly' | 'yearly' | 'never';
  priority: number;
}

export interface SEOStats {
  totalIndexedPages: number;
  topKeywords: Array<{ keyword: string; count: number }>;
  averageMetaLength: {
    title: number;
    description: number;
  };
  missingMetadata: {
    titles: number;
    descriptions: number;
    images: number;
  };
}

export class SEOService {
  private db = getFirestore();
  private static instance: SEOService;

  private constructor() {}

  static getInstance(): SEOService {
    if (!SEOService.instance) {
      SEOService.instance = new SEOService();
    }
    return SEOService.instance;
  }

  async generateProductMetadata(productId: string): Promise<SEOMetadata> {
    try {
      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      const seller = await profileService.getUserProfile(product.sellerId);
      const category = await categoriesService.getCategory(product.categoryId);

      const metadata: SEOMetadata = {
        title: `${product.name} | ${category.name} | MUANMANG`,
        description: this.truncateDescription(product.description, 160),
        keywords: [
          ...product.tags,
          category.name,
          'comprar online',
          'Guinea Ecuatorial',
          'marketplace',
        ],
        ogImage: product.images[0],
        ogTitle: product.name,
        ogDescription: this.truncateDescription(product.description, 200),
        canonicalUrl: `https://muanmang.com/product/${productId}`,
        robots: 'index, follow',
        structuredData: {
          '@context': 'https://schema.org',
          '@type': 'Product',
          name: product.name,
          description: product.description,
          image: product.images,
          offers: {
            '@type': 'Offer',
            price: product.price,
            priceCurrency: 'XAF',
            availability: product.stock > 0 ? 'InStock' : 'OutOfStock',
            seller: {
              '@type': 'Organization',
              name: seller.displayName,
            },
          },
        },
      };

      return metadata;
    } catch (error: any) {
      throw new Error(`Error al generar metadatos del producto: ${error.message}`);
    }
  }

  async generateCategoryMetadata(categoryId: string): Promise<SEOMetadata> {
    try {
      const category = await categoriesService.getCategory(categoryId);
      if (!category) {
        throw new Error('Categoría no encontrada');
      }

      const products = await marketService.getProductsByCategory(categoryId, { limit: 5 });
      const popularTags = await categoriesService.getCategoryTags(categoryId, { limit: 10 });

      const metadata: SEOMetadata = {
        title: `${category.name} | Comprar en MUANMANG`,
        description: `Explora nuestra selección de ${category.name.toLowerCase()} en MUANMANG. Encuentra los mejores productos de Guinea Ecuatorial.`,
        keywords: [
          category.name,
          ...popularTags,
          'comprar online',
          'Guinea Ecuatorial',
          'marketplace',
        ],
        ogImage: category.image,
        ogTitle: `${category.name} | MUANMANG`,
        ogDescription: `Descubre ${products.length}+ productos en la categoría ${category.name.toLowerCase()}.`,
        canonicalUrl: `https://muanmang.com/category/${categoryId}`,
        robots: 'index, follow',
        structuredData: {
          '@context': 'https://schema.org',
          '@type': 'CollectionPage',
          name: category.name,
          description: category.description,
          numberOfItems: products.length,
        },
      };

      return metadata;
    } catch (error: any) {
      throw new Error(`Error al generar metadatos de la categoría: ${error.message}`);
    }
  }

  async generateSellerMetadata(sellerId: string): Promise<SEOMetadata> {
    try {
      const seller = await profileService.getUserProfile(sellerId);
      if (!seller) {
        throw new Error('Vendedor no encontrado');
      }

      const products = await marketService.getSellerProducts(sellerId);
      const topCategories = await this.getSellerTopCategories(sellerId);

      const metadata: SEOMetadata = {
        title: `${seller.displayName} | Tienda en MUANMANG`,
        description: `Visita la tienda de ${seller.displayName} en MUANMANG. Encuentra ${products.length}+ productos únicos de Guinea Ecuatorial.`,
        keywords: [
          seller.displayName,
          ...topCategories,
          'tienda online',
          'Guinea Ecuatorial',
          'vendedor verificado',
        ],
        ogImage: seller.profileImage,
        ogTitle: `Tienda de ${seller.displayName}`,
        ogDescription: seller.bio || `Descubre los productos de ${seller.displayName} en MUANMANG.`,
        canonicalUrl: `https://muanmang.com/seller/${sellerId}`,
        robots: 'index, follow',
        structuredData: {
          '@context': 'https://schema.org',
          '@type': 'Organization',
          name: seller.displayName,
          description: seller.bio,
          image: seller.profileImage,
          url: `https://muanmang.com/seller/${sellerId}`,
        },
      };

      return metadata;
    } catch (error: any) {
      throw new Error(`Error al generar metadatos del vendedor: ${error.message}`);
    }
  }

  private async getSellerTopCategories(sellerId: string): Promise<string[]> {
    try {
      const products = await marketService.getSellerProducts(sellerId);
      const categoryCounts = products.reduce((acc, product) => {
        acc[product.categoryId] = (acc[product.categoryId] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const sortedCategories = Object.entries(categoryCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5);

      const categoryNames = await Promise.all(
        sortedCategories.map(async ([categoryId]) => {
          const category = await categoriesService.getCategory(categoryId);
          return category.name;
        })
      );

      return categoryNames;
    } catch (error: any) {
      throw new Error(`Error al obtener categorías principales del vendedor: ${error.message}`);
    }
  }

  async generateSitemap(): Promise<SitemapEntry[]> {
    try {
      const sitemap: SitemapEntry[] = [
        {
          url: 'https://muanmang.com',
          lastModified: new Date(),
          changeFrequency: 'daily',
          priority: 1.0,
        },
      ];

      // Agregar productos
      const products = await marketService.getAllProducts();
      products.forEach((product) => {
        sitemap.push({
          url: `https://muanmang.com/product/${product.id}`,
          lastModified: product.updatedAt,
          changeFrequency: 'daily',
          priority: 0.8,
        });
      });

      // Agregar categorías
      const categories = await categoriesService.getAllCategories();
      categories.forEach((category) => {
        sitemap.push({
          url: `https://muanmang.com/category/${category.id}`,
          lastModified: category.updatedAt,
          changeFrequency: 'weekly',
          priority: 0.7,
        });
      });

      // Agregar vendedores
      const sellers = await profileService.getActiveSellers();
      sellers.forEach((seller) => {
        sitemap.push({
          url: `https://muanmang.com/seller/${seller.id}`,
          lastModified: seller.updatedAt,
          changeFrequency: 'weekly',
          priority: 0.6,
        });
      });

      return sitemap;
    } catch (error: any) {
      throw new Error(`Error al generar sitemap: ${error.message}`);
    }
  }

  async getSEOStats(): Promise<SEOStats> {
    try {
      const products = await marketService.getAllProducts();
      const categories = await categoriesService.getAllCategories();
      const sellers = await profileService.getActiveSellers();

      const allKeywords = products.flatMap((p) => p.tags);
      const keywordCounts = allKeywords.reduce((acc, keyword) => {
        acc[keyword] = (acc[keyword] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const topKeywords = Object.entries(keywordCounts)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 10)
        .map(([keyword, count]) => ({ keyword, count }));

      const stats: SEOStats = {
        totalIndexedPages: products.length + categories.length + sellers.length + 1, // +1 for homepage
        topKeywords,
        averageMetaLength: {
          title: this.calculateAverageLength(products, 'name'),
          description: this.calculateAverageLength(products, 'description'),
        },
        missingMetadata: {
          titles: products.filter((p) => !p.name).length,
          descriptions: products.filter((p) => !p.description).length,
          images: products.filter((p) => !p.images || p.images.length === 0).length,
        },
      };

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas SEO: ${error.message}`);
    }
  }

  private calculateAverageLength(items: any[], field: string): number {
    const totalLength = items.reduce((sum, item) => {
      return sum + (item[field]?.length || 0);
    }, 0);
    return Math.round(totalLength / items.length) || 0;
  }

  private truncateDescription(description: string, maxLength: number): string {
    if (description.length <= maxLength) return description;
    return description.substring(0, maxLength - 3) + '...';
  }
}

export const seoService = SEOService.getInstance();