import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { marketService } from './market';
import { profileService } from './profile';

export interface Promotion {
  id: string;
  name: string;
  description: string;
  type: 'percentage' | 'fixed_amount' | 'buy_x_get_y' | 'bundle';
  value: number;
  startDate: Date;
  endDate: Date;
  conditions?: {
    minPurchase?: number;
    maxDiscount?: number;
    applicableProducts?: string[];
    applicableCategories?: string[];
    userType?: 'all' | 'new' | 'returning';
    usageLimit?: number;
    usagePerUser?: number;
  };
  status: 'active' | 'scheduled' | 'expired' | 'cancelled';
  usageCount: number;
  createdBy: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface PromotionUsage {
  id: string;
  promotionId: string;
  userId: string;
  orderId: string;
  discountAmount: number;
  appliedAt: Date;
}

export interface Bundle {
  id: string;
  name: string;
  description: string;
  products: Array<{
    productId: string;
    quantity: number;
    individualPrice: number;
  }>;
  bundlePrice: number;
  totalSavings: number;
  savingsPercentage: number;
  stock: number;
  startDate: Date;
  endDate: Date;
  status: 'active' | 'scheduled' | 'expired' | 'out_of_stock';
  createdAt: Date;
  updatedAt: Date;
}

export class PromotionService {
  private db = getFirestore();
  private static instance: PromotionService;

  private constructor() {}

  static getInstance(): PromotionService {
    if (!PromotionService.instance) {
      PromotionService.instance = new PromotionService();
    }
    return PromotionService.instance;
  }

  async createPromotion(promotion: Omit<Promotion, 'id' | 'usageCount' | 'createdAt' | 'updatedAt'>): Promise<Promotion> {
    try {
      const newPromotion: Omit<Promotion, 'id'> = {
        ...promotion,
        usageCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'promotions'), newPromotion);
      return { ...newPromotion, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear promoción: ${error.message}`);
    }
  }

  async getPromotion(promotionId: string): Promise<Promotion> {
    try {
      const docRef = doc(this.db, 'promotions', promotionId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Promoción no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as Promotion;
    } catch (error: any) {
      throw new Error(`Error al obtener promoción: ${error.message}`);
    }
  }

  async updatePromotion(
    promotionId: string,
    updates: Partial<Omit<Promotion, 'id' | 'createdAt' | 'updatedAt'>>
  ): Promise<void> {
    try {
      const promotionRef = doc(this.db, 'promotions', promotionId);
      await updateDoc(promotionRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar promoción: ${error.message}`);
    }
  }

  async deletePromotion(promotionId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'promotions', promotionId));
    } catch (error: any) {
      throw new Error(`Error al eliminar promoción: ${error.message}`);
    }
  }

  async getActivePromotions(): Promise<Promotion[]> {
    try {
      const now = new Date();
      const q = query(
        collection(this.db, 'promotions'),
        where('status', '==', 'active'),
        where('startDate', '<=', now),
        where('endDate', '>=', now)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Promotion[];
    } catch (error: any) {
      throw new Error(`Error al obtener promociones activas: ${error.message}`);
    }
  }

  async calculateDiscount(
    promotionId: string,
    userId: string,
    items: Array<{ productId: string; quantity: number; price: number }>
  ): Promise<{
    discountAmount: number;
    applicableItems: string[];
    message: string;
  }> {
    try {
      const promotion = await this.getPromotion(promotionId);
      const user = await profileService.getUserProfile(userId);

      // Verificar si la promoción está activa
      if (promotion.status !== 'active') {
        throw new Error('La promoción no está activa');
      }

      // Verificar límites de uso
      if (promotion.conditions?.usageLimit && promotion.usageCount >= promotion.conditions.usageLimit) {
        throw new Error('La promoción ha alcanzado su límite de uso');
      }

      const userUsage = await this.getUserPromotionUsage(userId, promotionId);
      if (
        promotion.conditions?.usagePerUser &&
        userUsage.length >= promotion.conditions.usagePerUser
      ) {
        throw new Error('Has alcanzado el límite de uso para esta promoción');
      }

      // Calcular subtotal y verificar monto mínimo
      const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
      if (promotion.conditions?.minPurchase && subtotal < promotion.conditions.minPurchase) {
        throw new Error(
          `El monto mínimo requerido es ${promotion.conditions.minPurchase} XAF`
        );
      }

      // Filtrar items aplicables
      const applicableItems = items.filter((item) => {
        if (!promotion.conditions?.applicableProducts && !promotion.conditions?.applicableCategories) {
          return true;
        }

        const product = await marketService.getProduct(item.productId);
        return (
          promotion.conditions.applicableProducts?.includes(item.productId) ||
          promotion.conditions.applicableCategories?.includes(product.categoryId)
        );
      });

      if (applicableItems.length === 0) {
        throw new Error('No hay productos aplicables para esta promoción');
      }

      // Calcular descuento
      let discountAmount = 0;
      switch (promotion.type) {
        case 'percentage':
          discountAmount = subtotal * (promotion.value / 100);
          break;
        case 'fixed_amount':
          discountAmount = promotion.value;
          break;
        case 'buy_x_get_y':
          // Implementar lógica específica para promociones tipo "compra X lleva Y"
          break;
        case 'bundle':
          // Implementar lógica específica para promociones tipo bundle
          break;
      }

      // Aplicar límite máximo de descuento si existe
      if (promotion.conditions?.maxDiscount) {
        discountAmount = Math.min(discountAmount, promotion.conditions.maxDiscount);
      }

      return {
        discountAmount,
        applicableItems: applicableItems.map((item) => item.productId),
        message: `Descuento de ${discountAmount} XAF aplicado`,
      };
    } catch (error: any) {
      throw new Error(`Error al calcular descuento: ${error.message}`);
    }
  }

  async recordPromotionUsage(
    promotionId: string,
    userId: string,
    orderId: string,
    discountAmount: number
  ): Promise<void> {
    try {
      const usage: Omit<PromotionUsage, 'id'> = {
        promotionId,
        userId,
        orderId,
        discountAmount,
        appliedAt: new Date(),
      };

      await addDoc(collection(this.db, 'promotionUsages'), usage);
      await this.updatePromotion(promotionId, { usageCount: increment(1) });
    } catch (error: any) {
      throw new Error(`Error al registrar uso de promoción: ${error.message}`);
    }
  }

  private async getUserPromotionUsage(userId: string, promotionId: string): Promise<PromotionUsage[]> {
    try {
      const q = query(
        collection(this.db, 'promotionUsages'),
        where('userId', '==', userId),
        where('promotionId', '==', promotionId)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as PromotionUsage[];
    } catch (error: any) {
      throw new Error(`Error al obtener uso de promoción: ${error.message}`);
    }
  }

  async createBundle(bundle: Omit<Bundle, 'id' | 'createdAt' | 'updatedAt'>): Promise<Bundle> {
    try {
      // Verificar que todos los productos existen y tienen stock suficiente
      await Promise.all(
        bundle.products.map(async (item) => {
          const product = await marketService.getProduct(item.productId);
          if (!product) {
            throw new Error(`Producto ${item.productId} no encontrado`);
          }
          if (product.stock < item.quantity) {
            throw new Error(`Stock insuficiente para el producto ${product.name}`);
          }
        })
      );

      const newBundle: Omit<Bundle, 'id'> = {
        ...bundle,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'bundles'), newBundle);
      return { ...newBundle, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear bundle: ${error.message}`);
    }
  }

  async getBundle(bundleId: string): Promise<Bundle> {
    try {
      const docRef = doc(this.db, 'bundles', bundleId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Bundle no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as Bundle;
    } catch (error: any) {
      throw new Error(`Error al obtener bundle: ${error.message}`);
    }
  }

  async updateBundleStock(bundleId: string, quantity: number): Promise<void> {
    try {
      const bundle = await this.getBundle(bundleId);
      const newStock = bundle.stock - quantity;

      if (newStock < 0) {
        throw new Error('Stock insuficiente');
      }

      const bundleRef = doc(this.db, 'bundles', bundleId);
      await updateDoc(bundleRef, {
        stock: newStock,
        status: newStock === 0 ? 'out_of_stock' : bundle.status,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar stock del bundle: ${error.message}`);
    }
  }

  async getActiveBundles(): Promise<Bundle[]> {
    try {
      const now = new Date();
      const q = query(
        collection(this.db, 'bundles'),
        where('status', '==', 'active'),
        where('startDate', '<=', now),
        where('endDate', '>=', now)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Bundle[];
    } catch (error: any) {
      throw new Error(`Error al obtener bundles activos: ${error.message}`);
    }
  }
}

export const promotionService = PromotionService.getInstance();