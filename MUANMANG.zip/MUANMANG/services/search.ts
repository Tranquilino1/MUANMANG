import { getFirestore, collection, query, where, orderBy, getDocs, limit } from 'firebase/firestore';
import { categoryService } from './categories';

export interface SearchFilters {
  categories?: string[];
  priceRange?: {
    min: number;
    max: number;
  };
  tags?: string[];
  condition?: 'new' | 'used' | 'refurbished';
  location?: string;
  seller?: {
    id?: string;
    minRating?: number;
  };
  sortBy?: 'price_asc' | 'price_desc' | 'date' | 'popularity' | 'rating';
  shipping?: boolean;
}

export interface SearchResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  filters: SearchFilters;
  suggestions?: string[];
}

export class SearchService {
  private db = getFirestore();

  async searchProducts({
    query: searchQuery,
    filters,
    page = 1,
    pageSize = 20,
  }: {
    query?: string;
    filters?: SearchFilters;
    page?: number;
    pageSize?: number;
  }): Promise<SearchResult<any>> {
    try {
      let q = query(collection(this.db, 'products'));

      // Aplicar filtros básicos
      q = query(q, where('status', '==', 'active'));

      if (filters?.categories?.length) {
        q = query(q, where('category', 'in', filters.categories));
      }

      if (filters?.priceRange) {
        if (filters.priceRange.min !== undefined) {
          q = query(q, where('price', '>=', filters.priceRange.min));
        }
        if (filters.priceRange.max !== undefined) {
          q = query(q, where('price', '<=', filters.priceRange.max));
        }
      }

      if (filters?.seller?.id) {
        q = query(q, where('seller.id', '==', filters.seller.id));
      }

      if (filters?.seller?.minRating) {
        q = query(q, where('seller.rating', '>=', filters.seller.minRating));
      }

      if (filters?.condition) {
        q = query(q, where('condition', '==', filters.condition));
      }

      if (filters?.shipping !== undefined) {
        q = query(q, where('shipping.available', '==', filters.shipping));
      }

      // Aplicar ordenamiento
      switch (filters?.sortBy) {
        case 'price_asc':
          q = query(q, orderBy('price', 'asc'));
          break;
        case 'price_desc':
          q = query(q, orderBy('price', 'desc'));
          break;
        case 'date':
          q = query(q, orderBy('createdAt', 'desc'));
          break;
        case 'popularity':
          q = query(q, orderBy('stats.views', 'desc'));
          break;
        case 'rating':
          q = query(q, orderBy('seller.rating', 'desc'));
          break;
        default:
          q = query(q, orderBy('createdAt', 'desc'));
      }

      // Aplicar paginación
      q = query(q, limit(pageSize));

      const snapshot = await getDocs(q);
      let items = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      // Filtrar por búsqueda de texto si existe
      if (searchQuery) {
        const searchLower = searchQuery.toLowerCase();
        items = items.filter(
          (item) =>
            item.name.toLowerCase().includes(searchLower) ||
            item.description.toLowerCase().includes(searchLower) ||
            (item.tags && item.tags.some((tag: string) => tag.toLowerCase().includes(searchLower)))
        );
      }

      // Filtrar por tags si existen
      if (filters?.tags?.length) {
        items = items.filter((item) =>
          item.tags && filters.tags?.some((tag) => item.tags.includes(tag))
        );
      }

      // Generar sugerencias de búsqueda
      let suggestions: string[] = [];
      if (searchQuery && items.length < 5) {
        suggestions = await this.generateSearchSuggestions(searchQuery);
      }

      return {
        items,
        total: items.length,
        page,
        pageSize,
        filters: filters || {},
        suggestions,
      };
    } catch (error: any) {
      throw new Error(`Error en la búsqueda: ${error.message}`);
    }
  }

  private async generateSearchSuggestions(query: string): Promise<string[]> {
    try {
      const suggestions: string[] = [];

      // Obtener categorías relacionadas
      const categories = await categoryService.getCategories();
      const categoryMatches = categories
        .filter((category) =>
          category.name.toLowerCase().includes(query.toLowerCase()) ||
          category.description?.toLowerCase().includes(query.toLowerCase())
        )
        .map((category) => category.name);
      suggestions.push(...categoryMatches);

      // Obtener tags relacionados
      const tags = await categoryService.getTags();
      const tagMatches = tags
        .filter((tag) =>
          tag.name.toLowerCase().includes(query.toLowerCase()) ||
          tag.description?.toLowerCase().includes(query.toLowerCase())
        )
        .map((tag) => tag.name);
      suggestions.push(...tagMatches);

      // Eliminar duplicados y limitar a 5 sugerencias
      return Array.from(new Set(suggestions)).slice(0, 5);
    } catch (error: any) {
      console.error('Error al generar sugerencias:', error);
      return [];
    }
  }

  async searchUsers({
    query: searchQuery,
    filters,
    page = 1,
    pageSize = 20,
  }: {
    query?: string;
    filters?: {
      role?: string;
      location?: string;
      minRating?: number;
      verified?: boolean;
    };
    page?: number;
    pageSize?: number;
  }): Promise<SearchResult<any>> {
    try {
      let q = query(collection(this.db, 'users'));

      if (filters?.role) {
        q = query(q, where('role', '==', filters.role));
      }

      if (filters?.location) {
        q = query(q, where('location', '==', filters.location));
      }

      if (filters?.minRating) {
        q = query(q, where('stats.rating', '>=', filters.minRating));
      }

      if (filters?.verified) {
        q = query(q, where('verification.government', '==', true));
      }

      q = query(q, orderBy('displayName'));
      q = query(q, limit(pageSize));

      const snapshot = await getDocs(q);
      let items = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      if (searchQuery) {
        const searchLower = searchQuery.toLowerCase();
        items = items.filter(
          (item) =>
            item.displayName.toLowerCase().includes(searchLower) ||
            (item.bio && item.bio.toLowerCase().includes(searchLower))
        );
      }

      return {
        items,
        total: items.length,
        page,
        pageSize,
        filters: filters || {},
      };
    } catch (error: any) {
      throw new Error(`Error en la búsqueda de usuarios: ${error.message}`);
    }
  }
}

export const searchService = new SearchService();