import { getFirestore, collection, doc, getDoc, setDoc, updateDoc, query, where, getDocs } from 'firebase/firestore';
import { settingsService } from './settings';

export interface Translation {
  id: string;
  locale: string;
  namespace: string;
  key: string;
  value: string;
  description?: string;
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface Locale {
  code: string;
  name: string;
  nativeName: string;
  direction: 'ltr' | 'rtl';
  dateFormat: string;
  timeFormat: string;
  numberFormat: {
    decimal: string;
    thousand: string;
    precision: number;
  };
  currencyFormat: {
    code: string;
    symbol: string;
    position: 'before' | 'after';
  };
  active: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface TranslationNamespace {
  id: string;
  name: string;
  description?: string;
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export class I18nService {
  private db = getFirestore();
  private static instance: I18nService;
  private currentLocale: string = 'es';
  private translations: Map<string, Map<string, string>> = new Map();
  private locales: Map<string, Locale> = new Map();

  private constructor() {
    this.initialize();
  }

  static getInstance(): I18nService {
    if (!I18nService.instance) {
      I18nService.instance = new I18nService();
    }
    return I18nService.instance;
  }

  private async initialize() {
    try {
      // Cargar configuración de idioma por defecto
      const settings = await settingsService.getSettings();
      this.currentLocale = settings.defaultLocale || 'es';

      // Cargar locales disponibles
      await this.loadLocales();

      // Cargar traducciones para el idioma actual
      await this.loadTranslations(this.currentLocale);
    } catch (error: any) {
      console.error('Error al inicializar I18nService:', error);
    }
  }

  async setLocale(locale: string): Promise<void> {
    try {
      if (!this.locales.has(locale)) {
        throw new Error(`Locale ${locale} no está disponible`);
      }

      this.currentLocale = locale;
      await this.loadTranslations(locale);

      // Actualizar preferencia de idioma del usuario si está autenticado
      // TODO: Implementar actualización de preferencia de usuario
    } catch (error: any) {
      throw new Error(`Error al cambiar locale: ${error.message}`);
    }
  }

  getLocale(): string {
    return this.currentLocale;
  }

  async getAvailableLocales(): Promise<Locale[]> {
    return Array.from(this.locales.values());
  }

  translate(key: string, namespace: string = 'common', params: Record<string, any> = {}): string {
    try {
      const namespaceTranslations = this.translations.get(namespace);
      if (!namespaceTranslations) {
        throw new Error(`Namespace ${namespace} no encontrado`);
      }

      const translation = namespaceTranslations.get(key);
      if (!translation) {
        console.warn(`Traducción no encontrada para la clave: ${key} en namespace: ${namespace}`);
        return key;
      }

      return this.interpolate(translation, params);
    } catch (error: any) {
      console.error(`Error al traducir: ${error.message}`);
      return key;
    }
  }

  private interpolate(text: string, params: Record<string, any>): string {
    return text.replace(/{{\s*([\w.]+)\s*}}/g, (_, key) => {
      const value = key.split('.').reduce((obj: any, k: string) => obj?.[k], params);
      return value !== undefined ? String(value) : `{{${key}}}`;
    });
  }

  async createTranslation(translation: Omit<Translation, 'id' | 'createdAt' | 'updatedAt'>): Promise<Translation> {
    try {
      const newTranslation: Omit<Translation, 'id'> = {
        ...translation,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'translations'), newTranslation);
      const result = { ...newTranslation, id: docRef.id };

      // Actualizar caché local
      const namespaceTranslations = this.translations.get(translation.namespace) || new Map();
      namespaceTranslations.set(translation.key, translation.value);
      this.translations.set(translation.namespace, namespaceTranslations);

      return result;
    } catch (error: any) {
      throw new Error(`Error al crear traducción: ${error.message}`);
    }
  }

  async updateTranslation(
    translationId: string,
    updates: Partial<Omit<Translation, 'id' | 'createdAt' | 'updatedAt'>>
  ): Promise<void> {
    try {
      const translationRef = doc(this.db, 'translations', translationId);
      await updateDoc(translationRef, {
        ...updates,
        updatedAt: new Date(),
      });

      // Actualizar caché local si es necesario
      if (updates.value) {
        const translation = await this.getTranslation(translationId);
        const namespaceTranslations = this.translations.get(translation.namespace) || new Map();
        namespaceTranslations.set(translation.key, updates.value);
        this.translations.set(translation.namespace, namespaceTranslations);
      }
    } catch (error: any) {
      throw new Error(`Error al actualizar traducción: ${error.message}`);
    }
  }

  async getTranslation(translationId: string): Promise<Translation> {
    try {
      const docRef = doc(this.db, 'translations', translationId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Traducción no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as Translation;
    } catch (error: any) {
      throw new Error(`Error al obtener traducción: ${error.message}`);
    }
  }

  async createLocale(locale: Omit<Locale, 'createdAt' | 'updatedAt'>): Promise<Locale> {
    try {
      const newLocale: Locale = {
        ...locale,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      await setDoc(doc(this.db, 'locales', locale.code), newLocale);

      // Actualizar caché local
      this.locales.set(locale.code, newLocale);

      return newLocale;
    } catch (error: any) {
      throw new Error(`Error al crear locale: ${error.message}`);
    }
  }

  async updateLocale(localeCode: string, updates: Partial<Omit<Locale, 'code' | 'createdAt' | 'updatedAt'>>): Promise<void> {
    try {
      const localeRef = doc(this.db, 'locales', localeCode);
      await updateDoc(localeRef, {
        ...updates,
        updatedAt: new Date(),
      });

      // Actualizar caché local
      const locale = await this.getLocaleByCode(localeCode);
      this.locales.set(localeCode, locale);
    } catch (error: any) {
      throw new Error(`Error al actualizar locale: ${error.message}`);
    }
  }

  async getLocaleByCode(code: string): Promise<Locale> {
    try {
      const docRef = doc(this.db, 'locales', code);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Locale no encontrado');
      }

      return docSnap.data() as Locale;
    } catch (error: any) {
      throw new Error(`Error al obtener locale: ${error.message}`);
    }
  }

  async createNamespace(namespace: Omit<TranslationNamespace, 'id' | 'createdAt' | 'updatedAt'>): Promise<TranslationNamespace> {
    try {
      const newNamespace: Omit<TranslationNamespace, 'id'> = {
        ...namespace,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'translationNamespaces'), newNamespace);
      return { ...newNamespace, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear namespace: ${error.message}`);
    }
  }

  async getNamespaces(): Promise<TranslationNamespace[]> {
    try {
      const snapshot = await getDocs(collection(this.db, 'translationNamespaces'));
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as TranslationNamespace[];
    } catch (error: any) {
      throw new Error(`Error al obtener namespaces: ${error.message}`);
    }
  }

  private async loadLocales(): Promise<void> {
    try {
      const snapshot = await getDocs(collection(this.db, 'locales'));
      snapshot.forEach((doc) => {
        const locale = doc.data() as Locale;
        this.locales.set(locale.code, locale);
      });
    } catch (error: any) {
      throw new Error(`Error al cargar locales: ${error.message}`);
    }
  }

  private async loadTranslations(locale: string): Promise<void> {
    try {
      const q = query(
        collection(this.db, 'translations'),
        where('locale', '==', locale)
      );
      const snapshot = await getDocs(q);

      this.translations.clear();
      snapshot.forEach((doc) => {
        const translation = doc.data() as Translation;
        const namespaceTranslations = this.translations.get(translation.namespace) || new Map();
        namespaceTranslations.set(translation.key, translation.value);
        this.translations.set(translation.namespace, namespaceTranslations);
      });
    } catch (error: any) {
      throw new Error(`Error al cargar traducciones: ${error.message}`);
    }
  }

  formatDate(date: Date, format?: string): string {
    const locale = this.locales.get(this.currentLocale);
    if (!locale) return date.toLocaleDateString();

    return date.toLocaleDateString(locale.code, {
      ...this.getDateFormatOptions(format || locale.dateFormat),
    });
  }

  formatTime(date: Date, format?: string): string {
    const locale = this.locales.get(this.currentLocale);
    if (!locale) return date.toLocaleTimeString();

    return date.toLocaleTimeString(locale.code, {
      ...this.getTimeFormatOptions(format || locale.timeFormat),
    });
  }

  formatNumber(number: number, precision?: number): string {
    const locale = this.locales.get(this.currentLocale);
    if (!locale) return number.toString();

    return new Intl.NumberFormat(locale.code, {
      minimumFractionDigits: precision || locale.numberFormat.precision,
      maximumFractionDigits: precision || locale.numberFormat.precision,
    }).format(number);
  }

  formatCurrency(amount: number): string {
    const locale = this.locales.get(this.currentLocale);
    if (!locale) return amount.toString();

    const formatted = this.formatNumber(amount);
    return locale.currencyFormat.position === 'before'
      ? `${locale.currencyFormat.symbol}${formatted}`
      : `${formatted}${locale.currencyFormat.symbol}`;
  }

  private getDateFormatOptions(format: string): Intl.DateTimeFormatOptions {
    // Implementar parsing de formato de fecha personalizado
    return {};
  }

  private getTimeFormatOptions(format: string): Intl.DateTimeFormatOptions {
    // Implementar parsing de formato de hora personalizado
    return {};
  }
}

export const i18nService = I18nService.getInstance();