import { getFirestore, collection, addDoc, query, where, orderBy, getDocs, limit } from 'firebase/firestore';

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'warning' | 'error' | 'debug';
  category: string;
  message: string;
  userId?: string;
  metadata?: any;
  stack?: string;
  tags?: string[];
}

export interface ErrorReport {
  id: string;
  timestamp: Date;
  userId?: string;
  error: {
    name: string;
    message: string;
    stack?: string;
  };
  context: {
    route?: string;
    action?: string;
    component?: string;
    params?: any;
  };
  device: {
    platform: string;
    os: string;
    browser?: string;
    version?: string;
  };
  metadata?: any;
}

export class LoggerService {
  private db = getFirestore();
  private static instance: LoggerService;

  private constructor() {}

  static getInstance(): LoggerService {
    if (!LoggerService.instance) {
      LoggerService.instance = new LoggerService();
    }
    return LoggerService.instance;
  }

  async log({
    level,
    category,
    message,
    userId,
    metadata,
    tags,
  }: {
    level: LogEntry['level'];
    category: string;
    message: string;
    userId?: string;
    metadata?: any;
    tags?: string[];
  }): Promise<void> {
    try {
      const logEntry: Omit<LogEntry, 'id'> = {
        timestamp: new Date(),
        level,
        category,
        message,
        userId,
        metadata,
        tags,
      };

      await addDoc(collection(this.db, 'logs'), logEntry);

      // Registrar en la consola para desarrollo
      if (process.env.NODE_ENV === 'development') {
        const consoleMethod = level === 'error' ? 'error' : level === 'warning' ? 'warn' : 'log';
        console[consoleMethod](`[${category}] ${message}`, metadata);
      }
    } catch (error: any) {
      console.error('Error al registrar log:', error);
    }
  }

  async reportError(error: Error, context: ErrorReport['context'] = {}): Promise<void> {
    try {
      const errorReport: Omit<ErrorReport, 'id'> = {
        timestamp: new Date(),
        error: {
          name: error.name,
          message: error.message,
          stack: error.stack,
        },
        context,
        device: {
          platform: 'react-native',
          os: Platform.OS,
          version: Platform.Version,
        },
      };

      await addDoc(collection(this.db, 'error_reports'), errorReport);

      // Registrar en la consola para desarrollo
      if (process.env.NODE_ENV === 'development') {
        console.error('Error Report:', {
          error: errorReport.error,
          context: errorReport.context,
        });
      }
    } catch (error: any) {
      console.error('Error al reportar error:', error);
    }
  }

  async getRecentLogs({
    level,
    category,
    limit: limitCount = 100,
  }: {
    level?: LogEntry['level'];
    category?: string;
    limit?: number;
  } = {}): Promise<LogEntry[]> {
    try {
      let q = query(collection(this.db, 'logs'), orderBy('timestamp', 'desc'));

      if (level) {
        q = query(q, where('level', '==', level));
      }

      if (category) {
        q = query(q, where('category', '==', category));
      }

      q = query(q, limit(limitCount));

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as LogEntry[];
    } catch (error: any) {
      console.error('Error al obtener logs:', error);
      return [];
    }
  }

  async getErrorReports({
    startDate,
    endDate,
    limit: limitCount = 50,
  }: {
    startDate?: Date;
    endDate?: Date;
    limit?: number;
  } = {}): Promise<ErrorReport[]> {
    try {
      let q = query(collection(this.db, 'error_reports'), orderBy('timestamp', 'desc'));

      if (startDate) {
        q = query(q, where('timestamp', '>=', startDate));
      }

      if (endDate) {
        q = query(q, where('timestamp', '<=', endDate));
      }

      q = query(q, limit(limitCount));

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as ErrorReport[];
    } catch (error: any) {
      console.error('Error al obtener reportes de error:', error);
      return [];
    }
  }

  async getUserActivityLogs(userId: string, limit: number = 50): Promise<LogEntry[]> {
    try {
      const q = query(
        collection(this.db, 'logs'),
        where('userId', '==', userId),
        orderBy('timestamp', 'desc'),
        limit(limit)
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as LogEntry[];
    } catch (error: any) {
      console.error('Error al obtener logs de usuario:', error);
      return [];
    }
  }

  // Métodos de conveniencia para diferentes niveles de log
  async info(category: string, message: string, metadata?: any): Promise<void> {
    await this.log({ level: 'info', category, message, metadata });
  }

  async warning(category: string, message: string, metadata?: any): Promise<void> {
    await this.log({ level: 'warning', category, message, metadata });
  }

  async error(category: string, message: string, metadata?: any): Promise<void> {
    await this.log({ level: 'error', category, message, metadata });
  }

  async debug(category: string, message: string, metadata?: any): Promise<void> {
    if (process.env.NODE_ENV === 'development') {
      await this.log({ level: 'debug', category, message, metadata });
    }
  }
}

export const loggerService = LoggerService.getInstance();