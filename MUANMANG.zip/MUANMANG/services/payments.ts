import { Alert } from 'react-native';
import { doc, addDoc, collection, updateDoc, getFirestore } from 'firebase/firestore';

interface PaymentMethod {
  id: string;
  name: string;
  type: 'munidinero' | 'ecobank' | 'bange';
  processingFee: number;
  minimumAmount: number;
  maximumAmount: number;
  requiresVerification: boolean;
}

interface Transaction {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  description: string;
  metadata?: any;
  createdAt: Date;
  updatedAt: Date;
}

const paymentMethods: PaymentMethod[] = [
  {
    id: 'munidinero',
    name: 'MuniDinero',
    type: 'munidinero',
    processingFee: 0.015, // 1.5%
    minimumAmount: 1000, // 1000 XAF
    maximumAmount: 500000, // 500,000 XAF
    requiresVerification: true,
  },
  {
    id: 'ecobank',
    name: 'Ecobank',
    type: 'ecobank',
    processingFee: 0.02, // 2%
    minimumAmount: 5000, // 5000 XAF
    maximumAmount: 1000000, // 1,000,000 XAF
    requiresVerification: true,
  },
  {
    id: 'bange',
    name: 'BANGE',
    type: 'bange',
    processingFee: 0.018, // 1.8%
    minimumAmount: 2500, // 2500 XAF
    maximumAmount: 750000, // 750,000 XAF
    requiresVerification: true,
  },
];

export class PaymentService {
  private db = getFirestore();

  async initializePayment({
    userId,
    amount,
    paymentMethod,
    description,
  }: {
    userId: string;
    amount: number;
    paymentMethod: string;
    description: string;
  }): Promise<Transaction> {
    try {
      const method = paymentMethods.find((m) => m.id === paymentMethod);
      if (!method) {
        throw new Error('Método de pago no válido');
      }

      if (amount < method.minimumAmount || amount > method.maximumAmount) {
        throw new Error(
          `El monto debe estar entre ${method.minimumAmount} XAF y ${method.maximumAmount} XAF`
        );
      }

      const processingFee = amount * method.processingFee;
      const totalAmount = amount + processingFee;

      const transaction: Omit<Transaction, 'id'> = {
        userId,
        amount: totalAmount,
        currency: 'XAF',
        paymentMethod: method.id,
        status: 'pending',
        description,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'transactions'), transaction);
      return { ...transaction, id: docRef.id } as Transaction;
    } catch (error: any) {
      Alert.alert('Error', error.message);
      throw error;
    }
  }

  async processPayment(transactionId: string): Promise<Transaction> {
    try {
      const transactionRef = doc(this.db, 'transactions', transactionId);

      // Aquí se implementaría la lógica de integración con cada proveedor de pago
      // Por ahora, simulamos un proceso exitoso
      await updateDoc(transactionRef, {
        status: 'completed',
        updatedAt: new Date(),
      });

      return {
        id: transactionId,
        status: 'completed',
        updatedAt: new Date(),
      } as Transaction;
    } catch (error: any) {
      Alert.alert('Error', 'Error al procesar el pago');
      throw error;
    }
  }

  async refundPayment(transactionId: string): Promise<Transaction> {
    try {
      const transactionRef = doc(this.db, 'transactions', transactionId);

      await updateDoc(transactionRef, {
        status: 'refunded',
        updatedAt: new Date(),
      });

      return {
        id: transactionId,
        status: 'refunded',
        updatedAt: new Date(),
      } as Transaction;
    } catch (error: any) {
      Alert.alert('Error', 'Error al procesar el reembolso');
      throw error;
    }
  }

  getPaymentMethods(): PaymentMethod[] {
    return paymentMethods;
  }

  calculateFees(amount: number, paymentMethodId: string): {
    processingFee: number;
    totalAmount: number;
  } {
    const method = paymentMethods.find((m) => m.id === paymentMethodId);
    if (!method) {
      throw new Error('Método de pago no válido');
    }

    const processingFee = amount * method.processingFee;
    const totalAmount = amount + processingFee;

    return {
      processingFee,
      totalAmount,
    };
  }
}

export const paymentService = new PaymentService();