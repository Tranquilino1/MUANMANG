import { getFirestore, collection, addDoc, query, where, orderBy, onSnapshot, doc, updateDoc } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  receiverId: string;
  content: string;
  type: 'text' | 'image' | 'file';
  attachments?: {
    url: string;
    type: string;
    name: string;
    size: number;
  }[];
  status: 'sent' | 'delivered' | 'read';
  createdAt: Date;
  updatedAt: Date;
}

export interface Conversation {
  id: string;
  participants: string[];
  lastMessage?: {
    content: string;
    senderId: string;
    createdAt: Date;
  };
  unreadCount: {
    [userId: string]: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

export class ChatService {
  private db = getFirestore();
  private storage = getStorage();

  async createConversation(participants: string[]): Promise<Conversation> {
    try {
      const conversationData: Omit<Conversation, 'id'> = {
        participants,
        unreadCount: participants.reduce((acc, userId) => ({ ...acc, [userId]: 0 }), {}),
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'conversations'), conversationData);
      return { ...conversationData, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear conversación: ${error.message}`);
    }
  }

  async sendMessage({
    conversationId,
    senderId,
    receiverId,
    content,
    type = 'text',
    attachments,
  }: {
    conversationId: string;
    senderId: string;
    receiverId: string;
    content: string;
    type?: 'text' | 'image' | 'file';
    attachments?: {
      file: Blob;
      type: string;
      name: string;
      size: number;
    }[];
  }): Promise<Message> {
    try {
      let processedAttachments;

      if (attachments && attachments.length > 0) {
        processedAttachments = await Promise.all(
          attachments.map(async (attachment) => {
            const storageRef = ref(
              this.storage,
              `chats/${conversationId}/${Date.now()}_${attachment.name}`
            );
            await uploadBytes(storageRef, attachment.file);
            const url = await getDownloadURL(storageRef);

            return {
              url,
              type: attachment.type,
              name: attachment.name,
              size: attachment.size,
            };
          })
        );
      }

      const messageData: Omit<Message, 'id'> = {
        conversationId,
        senderId,
        receiverId,
        content,
        type,
        attachments: processedAttachments,
        status: 'sent',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'messages'), messageData);

      // Actualizar la última conversación
      const conversationRef = doc(this.db, 'conversations', conversationId);
      await updateDoc(conversationRef, {
        lastMessage: {
          content,
          senderId,
          createdAt: new Date(),
        },
        [`unreadCount.${receiverId}`]: increment(1),
        updatedAt: new Date(),
      });

      return { ...messageData, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al enviar mensaje: ${error.message}`);
    }
  }

  subscribeToMessages(conversationId: string, callback: (messages: Message[]) => void): () => void {
    const q = query(
      collection(this.db, 'messages'),
      where('conversationId', '==', conversationId),
      orderBy('createdAt', 'asc')
    );

    return onSnapshot(q, (snapshot) => {
      const messages = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Message[];
      callback(messages);
    });
  }

  subscribeToConversations(userId: string, callback: (conversations: Conversation[]) => void): () => void {
    const q = query(
      collection(this.db, 'conversations'),
      where('participants', 'array-contains', userId),
      orderBy('updatedAt', 'desc')
    );

    return onSnapshot(q, (snapshot) => {
      const conversations = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Conversation[];
      callback(conversations);
    });
  }

  async markMessagesAsRead(conversationId: string, userId: string): Promise<void> {
    try {
      const conversationRef = doc(this.db, 'conversations', conversationId);
      await updateDoc(conversationRef, {
        [`unreadCount.${userId}`]: 0,
        updatedAt: new Date(),
      });

      const q = query(
        collection(this.db, 'messages'),
        where('conversationId', '==', conversationId),
        where('receiverId', '==', userId),
        where('status', '!=', 'read')
      );

      const snapshot = await getDocs(q);
      const batch = writeBatch(this.db);

      snapshot.docs.forEach((doc) => {
        batch.update(doc.ref, { status: 'read', updatedAt: new Date() });
      });

      await batch.commit();
    } catch (error: any) {
      throw new Error(`Error al marcar mensajes como leídos: ${error.message}`);
    }
  }

  async deleteMessage(messageId: string): Promise<void> {
    try {
      const messageRef = doc(this.db, 'messages', messageId);
      await deleteDoc(messageRef);
    } catch (error: any) {
      throw new Error(`Error al eliminar mensaje: ${error.message}`);
    }
  }

  async deleteConversation(conversationId: string): Promise<void> {
    try {
      // Eliminar todos los mensajes de la conversación
      const messagesQuery = query(
        collection(this.db, 'messages'),
        where('conversationId', '==', conversationId)
      );
      const snapshot = await getDocs(messagesQuery);
      const batch = writeBatch(this.db);

      snapshot.docs.forEach((doc) => {
        batch.delete(doc.ref);
      });

      // Eliminar la conversación
      batch.delete(doc(this.db, 'conversations', conversationId));

      await batch.commit();
    } catch (error: any) {
      throw new Error(`Error al eliminar conversación: ${error.message}`);
    }
  }
}

export const chatService = new ChatService();