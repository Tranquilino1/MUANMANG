import { getFirestore, collection, doc, getDoc, setDoc, updateDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { marketService } from './market';
import { profileService } from './profile';

export interface MarketStats {
  id: string;
  totalProducts: number;
  totalUsers: number;
  totalOrders: number;
  totalSales: number;
  activeListings: number;
  averageOrderValue: number;
  categories: Array<{
    id: string;
    name: string;
    count: number;
    value: number;
  }>;
  topSellers: Array<{
    userId: string;
    sales: number;
    revenue: number;
    rating: number;
  }>;
  topProducts: Array<{
    productId: string;
    sales: number;
    revenue: number;
    views: number;
  }>;
  periodStart: Date;
  periodEnd: Date;
  updatedAt: Date;
}

export interface UserStats {
  id: string;
  userId: string;
  totalListings: number;
  activeSales: number;
  completedSales: number;
  totalRevenue: number;
  averageRating: number;
  responseRate: number;
  responseTime: number; // en minutos
  views: number;
  favorites: number;
  followers: number;
  following: number;
  periodStart: Date;
  periodEnd: Date;
  updatedAt: Date;
}

export interface ProductStats {
  id: string;
  productId: string;
  views: number;
  uniqueViews: number;
  favorites: number;
  shares: number;
  clicks: number;
  conversions: number;
  conversionRate: number;
  revenue: number;
  periodStart: Date;
  periodEnd: Date;
  updatedAt: Date;
}

export interface CategoryStats {
  id: string;
  categoryId: string;
  totalProducts: number;
  activeListings: number;
  totalSales: number;
  totalRevenue: number;
  averagePrice: number;
  views: number;
  searches: number;
  periodStart: Date;
  periodEnd: Date;
  updatedAt: Date;
}

export class StatsService {
  private db = getFirestore();
  private static instance: StatsService;

  private constructor() {}

  static getInstance(): StatsService {
    if (!StatsService.instance) {
      StatsService.instance = new StatsService();
    }
    return StatsService.instance;
  }

  async getMarketStats(period: 'daily' | 'weekly' | 'monthly' | 'yearly'): Promise<MarketStats> {
    try {
      const periodStart = this.getPeriodStart(period);
      const periodEnd = new Date();

      const statsRef = doc(this.db, 'marketStats', period);
      const statsDoc = await getDoc(statsRef);

      if (!statsDoc.exists()) {
        // Si no existen estadísticas para el período, crearlas
        return this.generateMarketStats(period, periodStart, periodEnd);
      }

      const stats = statsDoc.data() as MarketStats;

      // Si las estadísticas están desactualizadas, actualizarlas
      if (stats.updatedAt.getTime() < this.getLastUpdateThreshold(period)) {
        return this.generateMarketStats(period, periodStart, periodEnd);
      }

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas del mercado: ${error.message}`);
    }
  }

  async getUserStats(userId: string, period: 'daily' | 'weekly' | 'monthly' | 'yearly'): Promise<UserStats> {
    try {
      const periodStart = this.getPeriodStart(period);
      const periodEnd = new Date();

      const statsRef = doc(this.db, 'userStats', `${userId}_${period}`);
      const statsDoc = await getDoc(statsRef);

      if (!statsDoc.exists()) {
        return this.generateUserStats(userId, period, periodStart, periodEnd);
      }

      const stats = statsDoc.data() as UserStats;

      if (stats.updatedAt.getTime() < this.getLastUpdateThreshold(period)) {
        return this.generateUserStats(userId, period, periodStart, periodEnd);
      }

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas del usuario: ${error.message}`);
    }
  }

  async getProductStats(productId: string, period: 'daily' | 'weekly' | 'monthly' | 'yearly'): Promise<ProductStats> {
    try {
      const periodStart = this.getPeriodStart(period);
      const periodEnd = new Date();

      const statsRef = doc(this.db, 'productStats', `${productId}_${period}`);
      const statsDoc = await getDoc(statsRef);

      if (!statsDoc.exists()) {
        return this.generateProductStats(productId, period, periodStart, periodEnd);
      }

      const stats = statsDoc.data() as ProductStats;

      if (stats.updatedAt.getTime() < this.getLastUpdateThreshold(period)) {
        return this.generateProductStats(productId, period, periodStart, periodEnd);
      }

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas del producto: ${error.message}`);
    }
  }

  async getCategoryStats(categoryId: string, period: 'daily' | 'weekly' | 'monthly' | 'yearly'): Promise<CategoryStats> {
    try {
      const periodStart = this.getPeriodStart(period);
      const periodEnd = new Date();

      const statsRef = doc(this.db, 'categoryStats', `${categoryId}_${period}`);
      const statsDoc = await getDoc(statsRef);

      if (!statsDoc.exists()) {
        return this.generateCategoryStats(categoryId, period, periodStart, periodEnd);
      }

      const stats = statsDoc.data() as CategoryStats;

      if (stats.updatedAt.getTime() < this.getLastUpdateThreshold(period)) {
        return this.generateCategoryStats(categoryId, period, periodStart, periodEnd);
      }

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas de la categoría: ${error.message}`);
    }
  }

  private getPeriodStart(period: string): Date {
    const now = new Date();
    switch (period) {
      case 'daily':
        return new Date(now.setHours(0, 0, 0, 0));
      case 'weekly':
        return new Date(now.setDate(now.getDate() - now.getDay()));
      case 'monthly':
        return new Date(now.setDate(1));
      case 'yearly':
        return new Date(now.setMonth(0, 1));
      default:
        throw new Error('Período no válido');
    }
  }

  private getLastUpdateThreshold(period: string): number {
    const now = Date.now();
    switch (period) {
      case 'daily':
        return now - 1 * 60 * 60 * 1000; // 1 hora
      case 'weekly':
        return now - 6 * 60 * 60 * 1000; // 6 horas
      case 'monthly':
        return now - 24 * 60 * 60 * 1000; // 24 horas
      case 'yearly':
        return now - 7 * 24 * 60 * 60 * 1000; // 7 días
      default:
        throw new Error('Período no válido');
    }
  }

  private async generateMarketStats(
    period: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<MarketStats> {
    try {
      // Implementar lógica para generar estadísticas del mercado
      // Esto podría incluir consultas a diferentes colecciones y cálculos

      const stats: MarketStats = {
        id: period,
        totalProducts: await this.countTotalProducts(),
        totalUsers: await this.countTotalUsers(),
        totalOrders: await this.countTotalOrders(periodStart, periodEnd),
        totalSales: await this.calculateTotalSales(periodStart, periodEnd),
        activeListings: await this.countActiveListings(),
        averageOrderValue: await this.calculateAverageOrderValue(periodStart, periodEnd),
        categories: await this.getCategoriesStats(periodStart, periodEnd),
        topSellers: await this.getTopSellers(periodStart, periodEnd),
        topProducts: await this.getTopProducts(periodStart, periodEnd),
        periodStart,
        periodEnd,
        updatedAt: new Date(),
      };

      await setDoc(doc(this.db, 'marketStats', period), stats);
      return stats;
    } catch (error: any) {
      throw new Error(`Error al generar estadísticas del mercado: ${error.message}`);
    }
  }

  private async generateUserStats(
    userId: string,
    period: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<UserStats> {
    try {
      // Implementar lógica para generar estadísticas del usuario
      const stats: UserStats = {
        id: `${userId}_${period}`,
        userId,
        totalListings: await this.countUserListings(userId),
        activeSales: await this.countUserActiveSales(userId),
        completedSales: await this.countUserCompletedSales(userId, periodStart, periodEnd),
        totalRevenue: await this.calculateUserRevenue(userId, periodStart, periodEnd),
        averageRating: await this.calculateUserAverageRating(userId),
        responseRate: await this.calculateUserResponseRate(userId, periodStart, periodEnd),
        responseTime: await this.calculateUserResponseTime(userId, periodStart, periodEnd),
        views: await this.countUserProfileViews(userId, periodStart, periodEnd),
        favorites: await this.countUserFavorites(userId),
        followers: await this.countUserFollowers(userId),
        following: await this.countUserFollowing(userId),
        periodStart,
        periodEnd,
        updatedAt: new Date(),
      };

      await setDoc(doc(this.db, 'userStats', stats.id), stats);
      return stats;
    } catch (error: any) {
      throw new Error(`Error al generar estadísticas del usuario: ${error.message}`);
    }
  }

  private async generateProductStats(
    productId: string,
    period: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<ProductStats> {
    try {
      // Implementar lógica para generar estadísticas del producto
      const stats: ProductStats = {
        id: `${productId}_${period}`,
        productId,
        views: await this.countProductViews(productId, periodStart, periodEnd),
        uniqueViews: await this.countProductUniqueViews(productId, periodStart, periodEnd),
        favorites: await this.countProductFavorites(productId),
        shares: await this.countProductShares(productId, periodStart, periodEnd),
        clicks: await this.countProductClicks(productId, periodStart, periodEnd),
        conversions: await this.countProductConversions(productId, periodStart, periodEnd),
        conversionRate: 0, // Se calcula después
        revenue: await this.calculateProductRevenue(productId, periodStart, periodEnd),
        periodStart,
        periodEnd,
        updatedAt: new Date(),
      };

      // Calcular tasa de conversión
      stats.conversionRate = stats.clicks > 0 ? (stats.conversions / stats.clicks) * 100 : 0;

      await setDoc(doc(this.db, 'productStats', stats.id), stats);
      return stats;
    } catch (error: any) {
      throw new Error(`Error al generar estadísticas del producto: ${error.message}`);
    }
  }

  private async generateCategoryStats(
    categoryId: string,
    period: string,
    periodStart: Date,
    periodEnd: Date
  ): Promise<CategoryStats> {
    try {
      // Implementar lógica para generar estadísticas de la categoría
      const stats: CategoryStats = {
        id: `${categoryId}_${period}`,
        categoryId,
        totalProducts: await this.countCategoryProducts(categoryId),
        activeListings: await this.countCategoryActiveListings(categoryId),
        totalSales: await this.countCategorySales(categoryId, periodStart, periodEnd),
        totalRevenue: await this.calculateCategoryRevenue(categoryId, periodStart, periodEnd),
        averagePrice: await this.calculateCategoryAveragePrice(categoryId),
        views: await this.countCategoryViews(categoryId, periodStart, periodEnd),
        searches: await this.countCategorySearches(categoryId, periodStart, periodEnd),
        periodStart,
        periodEnd,
        updatedAt: new Date(),
      };

      await setDoc(doc(this.db, 'categoryStats', stats.id), stats);
      return stats;
    } catch (error: any) {
      throw new Error(`Error al generar estadísticas de la categoría: ${error.message}`);
    }
  }

  // Métodos auxiliares para cálculos específicos
  private async countTotalProducts(): Promise<number> {
    const snapshot = await getDocs(collection(this.db, 'products'));
    return snapshot.size;
  }

  private async countTotalUsers(): Promise<number> {
    const snapshot = await getDocs(collection(this.db, 'users'));
    return snapshot.size;
  }

  private async countTotalOrders(start: Date, end: Date): Promise<number> {
    const q = query(
      collection(this.db, 'orders'),
      where('createdAt', '>=', start),
      where('createdAt', '<=', end)
    );
    const snapshot = await getDocs(q);
    return snapshot.size;
  }

  private async calculateTotalSales(start: Date, end: Date): Promise<number> {
    const q = query(
      collection(this.db, 'orders'),
      where('status', '==', 'completed'),
      where('createdAt', '>=', start),
      where('createdAt', '<=', end)
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.reduce((total, doc) => total + doc.data().total, 0);
  }

  // Implementar los demás métodos auxiliares según sea necesario
  // ...
}

export const statsService = StatsService.getInstance();