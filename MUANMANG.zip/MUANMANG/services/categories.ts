import { getFirestore, collection, addDoc, query, where, orderBy, getDocs, updateDoc, doc, deleteDoc } from 'firebase/firestore';

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  icon?: string;
  color?: string;
  parentId?: string;
  order: number;
  metadata?: {
    featuredProducts?: string[];
    bannerImage?: string;
    seoDescription?: string;
    keywords?: string[];
  };
  stats: {
    productCount: number;
    activeProducts: number;
    totalSales: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  description?: string;
  color?: string;
  productCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export class CategoryService {
  private db = getFirestore();

  async createCategory(categoryData: Omit<Category, 'id' | 'stats' | 'createdAt' | 'updatedAt'>): Promise<Category> {
    try {
      const category: Omit<Category, 'id'> = {
        ...categoryData,
        stats: {
          productCount: 0,
          activeProducts: 0,
          totalSales: 0,
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'categories'), category);
      return { ...category, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear categoría: ${error.message}`);
    }
  }

  async updateCategory(categoryId: string, updates: Partial<Category>): Promise<void> {
    try {
      const categoryRef = doc(this.db, 'categories', categoryId);
      await updateDoc(categoryRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar categoría: ${error.message}`);
    }
  }

  async deleteCategory(categoryId: string): Promise<void> {
    try {
      // Verificar si hay subcategorías
      const subCategoriesQuery = query(
        collection(this.db, 'categories'),
        where('parentId', '==', categoryId)
      );
      const subCategories = await getDocs(subCategoriesQuery);

      if (!subCategories.empty) {
        throw new Error('No se puede eliminar una categoría que tiene subcategorías');
      }

      // Verificar si hay productos en la categoría
      const productsQuery = query(
        collection(this.db, 'products'),
        where('category', '==', categoryId)
      );
      const products = await getDocs(productsQuery);

      if (!products.empty) {
        throw new Error('No se puede eliminar una categoría que contiene productos');
      }

      await deleteDoc(doc(this.db, 'categories', categoryId));
    } catch (error: any) {
      throw new Error(`Error al eliminar categoría: ${error.message}`);
    }
  }

  async getCategories(parentId?: string): Promise<Category[]> {
    try {
      const q = query(
        collection(this.db, 'categories'),
        where('parentId', '==', parentId || null),
        orderBy('order', 'asc')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Category[];
    } catch (error: any) {
      throw new Error(`Error al obtener categorías: ${error.message}`);
    }
  }

  async getCategoryHierarchy(): Promise<Category[]> {
    try {
      const allCategories = await this.getCategories();
      const hierarchy: Category[] = [];

      const buildHierarchy = (parentId: string | null = null, level: number = 0) => {
        const children = allCategories.filter((cat) => cat.parentId === parentId);
        children.forEach((child) => {
          hierarchy.push({ ...child, level });
          buildHierarchy(child.id, level + 1);
        });
      };

      buildHierarchy();
      return hierarchy;
    } catch (error: any) {
      throw new Error(`Error al obtener jerarquía de categorías: ${error.message}`);
    }
  }

  async updateCategoryStats(categoryId: string, stats: Partial<Category['stats']>): Promise<void> {
    try {
      const categoryRef = doc(this.db, 'categories', categoryId);
      await updateDoc(categoryRef, {
        stats: stats,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar estadísticas de categoría: ${error.message}`);
    }
  }

  // Gestión de etiquetas
  async createTag(tagData: Omit<Tag, 'id' | 'productCount' | 'createdAt' | 'updatedAt'>): Promise<Tag> {
    try {
      const tag: Omit<Tag, 'id'> = {
        ...tagData,
        productCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'tags'), tag);
      return { ...tag, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear etiqueta: ${error.message}`);
    }
  }

  async updateTag(tagId: string, updates: Partial<Tag>): Promise<void> {
    try {
      const tagRef = doc(this.db, 'tags', tagId);
      await updateDoc(tagRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar etiqueta: ${error.message}`);
    }
  }

  async deleteTag(tagId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'tags', tagId));
    } catch (error: any) {
      throw new Error(`Error al eliminar etiqueta: ${error.message}`);
    }
  }

  async getTags(): Promise<Tag[]> {
    try {
      const q = query(collection(this.db, 'tags'), orderBy('name', 'asc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Tag[];
    } catch (error: any) {
      throw new Error(`Error al obtener etiquetas: ${error.message}`);
    }
  }

  async updateTagProductCount(tagId: string, increment: number): Promise<void> {
    try {
      const tagRef = doc(this.db, 'tags', tagId);
      await updateDoc(tagRef, {
        productCount: increment,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar contador de productos: ${error.message}`);
    }
  }

  async searchTags(query: string): Promise<Tag[]> {
    try {
      const q = query(collection(this.db, 'tags'));
      const snapshot = await getDocs(q);
      const tags = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Tag[];

      return tags.filter(
        (tag) =>
          tag.name.toLowerCase().includes(query.toLowerCase()) ||
          tag.description?.toLowerCase().includes(query.toLowerCase())
      );
    } catch (error: any) {
      throw new Error(`Error al buscar etiquetas: ${error.message}`);
    }
  }
}

export const categoryService = new CategoryService();