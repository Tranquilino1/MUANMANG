import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { marketService } from './market';
import { profileService } from './profile';

export interface ShippingZone {
  id: string;
  name: string;
  regions: string[];
  methods: ShippingMethod[];
  restrictions?: {
    minOrderValue?: number;
    maxOrderValue?: number;
    excludedCategories?: string[];
    maxWeight?: number;
    maxDimensions?: {
      length: number;
      width: number;
      height: number;
    };
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface ShippingMethod {
  id: string;
  name: string;
  carrier: string;
  type: 'fixed' | 'weight_based' | 'price_based' | 'free';
  cost: number;
  estimatedDays: {
    min: number;
    max: number;
  };
  conditions?: {
    minOrderValue?: number;
    maxWeight?: number;
    freeShippingThreshold?: number;
  };
  active: boolean;
}

export interface ShipmentTracking {
  id: string;
  orderId: string;
  carrier: string;
  trackingNumber: string;
  status: 'pending' | 'in_transit' | 'delivered' | 'failed' | 'returned';
  events: Array<{
    status: string;
    location: string;
    timestamp: Date;
    description: string;
  }>;
  estimatedDelivery: Date;
  actualDelivery?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface ShippingRate {
  methodId: string;
  cost: number;
  estimatedDays: {
    min: number;
    max: number;
  };
  restrictions?: string[];
}

export class ShippingService {
  private db = getFirestore();
  private static instance: ShippingService;

  private constructor() {}

  static getInstance(): ShippingService {
    if (!ShippingService.instance) {
      ShippingService.instance = new ShippingService();
    }
    return ShippingService.instance;
  }

  async createShippingZone(zone: Omit<ShippingZone, 'id' | 'createdAt' | 'updatedAt'>): Promise<ShippingZone> {
    try {
      const newZone: Omit<ShippingZone, 'id'> = {
        ...zone,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'shippingZones'), newZone);
      return { ...newZone, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear zona de envío: ${error.message}`);
    }
  }

  async getShippingZone(zoneId: string): Promise<ShippingZone> {
    try {
      const docRef = doc(this.db, 'shippingZones', zoneId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Zona de envío no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as ShippingZone;
    } catch (error: any) {
      throw new Error(`Error al obtener zona de envío: ${error.message}`);
    }
  }

  async updateShippingZone(
    zoneId: string,
    updates: Partial<Omit<ShippingZone, 'id' | 'createdAt' | 'updatedAt'>>
  ): Promise<void> {
    try {
      const zoneRef = doc(this.db, 'shippingZones', zoneId);
      await updateDoc(zoneRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar zona de envío: ${error.message}`);
    }
  }

  async deleteShippingZone(zoneId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'shippingZones', zoneId));
    } catch (error: any) {
      throw new Error(`Error al eliminar zona de envío: ${error.message}`);
    }
  }

  async calculateShippingRates(
    address: {
      city: string;
      region: string;
      country: string;
    },
    items: Array<{
      productId: string;
      quantity: number;
    }>
  ): Promise<ShippingRate[]> {
    try {
      // Obtener zona de envío correspondiente
      const zones = await this.getShippingZonesByRegion(address.region);
      if (zones.length === 0) {
        throw new Error('No hay zonas de envío disponibles para esta región');
      }

      // Calcular detalles del pedido
      const orderDetails = await this.calculateOrderDetails(items);

      const rates: ShippingRate[] = [];

      for (const zone of zones) {
        // Verificar restricciones de la zona
        if (!this.checkZoneRestrictions(zone, orderDetails)) {
          continue;
        }

        // Calcular tarifas para cada método de envío disponible
        for (const method of zone.methods) {
          if (!method.active) continue;

          const rate = await this.calculateMethodRate(method, orderDetails);
          if (rate) {
            rates.push(rate);
          }
        }
      }

      return rates;
    } catch (error: any) {
      throw new Error(`Error al calcular tarifas de envío: ${error.message}`);
    }
  }

  private async getShippingZonesByRegion(region: string): Promise<ShippingZone[]> {
    try {
      const q = query(
        collection(this.db, 'shippingZones'),
        where('regions', 'array-contains', region)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as ShippingZone[];
    } catch (error: any) {
      throw new Error(`Error al obtener zonas de envío por región: ${error.message}`);
    }
  }

  private async calculateOrderDetails(items: Array<{ productId: string; quantity: number }>) {
    const products = await Promise.all(
      items.map(async (item) => {
        const product = await marketService.getProduct(item.productId);
        return {
          ...product,
          quantity: item.quantity,
        };
      })
    );

    return {
      totalValue: products.reduce((sum, p) => sum + p.price * p.quantity, 0),
      totalWeight: products.reduce((sum, p) => sum + (p.weight || 0) * p.quantity, 0),
      categories: [...new Set(products.map((p) => p.categoryId))],
      dimensions: products.map((p) => ({
        length: p.dimensions?.length || 0,
        width: p.dimensions?.width || 0,
        height: p.dimensions?.height || 0,
      })),
    };
  }

  private checkZoneRestrictions(
    zone: ShippingZone,
    orderDetails: ReturnType<typeof this.calculateOrderDetails> extends Promise<infer T> ? T : never
  ): boolean {
    if (!zone.restrictions) return true;

    const { minOrderValue, maxOrderValue, excludedCategories, maxWeight, maxDimensions } =
      zone.restrictions;

    if (minOrderValue && orderDetails.totalValue < minOrderValue) return false;
    if (maxOrderValue && orderDetails.totalValue > maxOrderValue) return false;
    if (maxWeight && orderDetails.totalWeight > maxWeight) return false;

    if (excludedCategories?.some((cat) => orderDetails.categories.includes(cat))) return false;

    if (maxDimensions) {
      const hasOversizedItem = orderDetails.dimensions.some(
        (dim) =>
          dim.length > maxDimensions.length ||
          dim.width > maxDimensions.width ||
          dim.height > maxDimensions.height
      );
      if (hasOversizedItem) return false;
    }

    return true;
  }

  private async calculateMethodRate(
    method: ShippingMethod,
    orderDetails: ReturnType<typeof this.calculateOrderDetails> extends Promise<infer T> ? T : never
  ): Promise<ShippingRate | null> {
    try {
      // Verificar condiciones del método
      if (
        method.conditions?.minOrderValue &&
        orderDetails.totalValue < method.conditions.minOrderValue
      ) {
        return null;
      }

      if (
        method.conditions?.maxWeight &&
        orderDetails.totalWeight > method.conditions.maxWeight
      ) {
        return null;
      }

      // Calcular costo según el tipo de método
      let cost = method.cost;

      switch (method.type) {
        case 'weight_based':
          cost *= orderDetails.totalWeight;
          break;
        case 'price_based':
          cost = (orderDetails.totalValue * method.cost) / 100;
          break;
        case 'free':
          cost = 0;
          break;
      }

      // Aplicar envío gratis si se cumple el umbral
      if (
        method.conditions?.freeShippingThreshold &&
        orderDetails.totalValue >= method.conditions.freeShippingThreshold
      ) {
        cost = 0;
      }

      return {
        methodId: method.id,
        cost,
        estimatedDays: method.estimatedDays,
        restrictions: [],
      };
    } catch (error: any) {
      throw new Error(`Error al calcular tarifa del método: ${error.message}`);
    }
  }

  async createShipmentTracking(
    orderId: string,
    tracking: Omit<ShipmentTracking, 'id' | 'events' | 'createdAt' | 'updatedAt'>
  ): Promise<ShipmentTracking> {
    try {
      const newTracking: Omit<ShipmentTracking, 'id'> = {
        ...tracking,
        events: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'shipmentTracking'), newTracking);
      return { ...newTracking, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear seguimiento de envío: ${error.message}`);
    }
  }

  async updateShipmentStatus(
    trackingId: string,
    status: ShipmentTracking['status'],
    event: {
      status: string;
      location: string;
      description: string;
    }
  ): Promise<void> {
    try {
      const trackingRef = doc(this.db, 'shipmentTracking', trackingId);
      const tracking = await this.getShipmentTracking(trackingId);

      const newEvent = {
        ...event,
        timestamp: new Date(),
      };

      const updates: Partial<ShipmentTracking> = {
        status,
        events: [...tracking.events, newEvent],
        updatedAt: new Date(),
      };

      if (status === 'delivered') {
        updates.actualDelivery = new Date();
      }

      await updateDoc(trackingRef, updates);
    } catch (error: any) {
      throw new Error(`Error al actualizar estado del envío: ${error.message}`);
    }
  }

  async getShipmentTracking(trackingId: string): Promise<ShipmentTracking> {
    try {
      const docRef = doc(this.db, 'shipmentTracking', trackingId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Seguimiento de envío no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as ShipmentTracking;
    } catch (error: any) {
      throw new Error(`Error al obtener seguimiento de envío: ${error.message}`);
    }
  }

  async getShipmentsByOrder(orderId: string): Promise<ShipmentTracking[]> {
    try {
      const q = query(
        collection(this.db, 'shipmentTracking'),
        where('orderId', '==', orderId)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as ShipmentTracking[];
    } catch (error: any) {
      throw new Error(`Error al obtener envíos del pedido: ${error.message}`);
    }
  }
}

export const shippingService = ShippingService.getInstance();