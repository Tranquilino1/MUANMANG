import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { marketService } from './market';
import { profileService } from './profile';

export interface Review {
  id: string;
  productId: string;
  sellerId: string;
  buyerId: string;
  rating: number;
  comment: string;
  images?: string[];
  likes: number;
  dislikes: number;
  isVerifiedPurchase: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface ReviewStats {
  totalReviews: number;
  averageRating: number;
  ratingDistribution: {
    [key: number]: number;
  };
  verifiedPurchaseCount: number;
  withImagesCount: number;
}

export class ReviewService {
  private db = getFirestore();
  private static instance: ReviewService;

  private constructor() {}

  static getInstance(): ReviewService {
    if (!ReviewService.instance) {
      ReviewService.instance = new ReviewService();
    }
    return ReviewService.instance;
  }

  async createReview({
    productId,
    buyerId,
    rating,
    comment,
    images = [],
  }: {
    productId: string;
    buyerId: string;
    rating: number;
    comment: string;
    images?: string[];
  }): Promise<Review> {
    try {
      // Verificar que el producto existe
      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      // Verificar que el comprador existe
      const buyer = await profileService.getUserProfile(buyerId);
      if (!buyer) {
        throw new Error('Comprador no encontrado');
      }

      // Verificar si el usuario ha comprado el producto
      const isVerifiedPurchase = await this.verifyPurchase(buyerId, productId);

      const review: Omit<Review, 'id'> = {
        productId,
        sellerId: product.sellerId,
        buyerId,
        rating,
        comment,
        images,
        likes: 0,
        dislikes: 0,
        isVerifiedPurchase,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'reviews'), review);
      const newReview = { ...review, id: docRef.id };

      // Actualizar estadísticas
      await this.updateProductStats(productId);
      await this.updateSellerStats(product.sellerId);

      return newReview;
    } catch (error: any) {
      throw new Error(`Error al crear reseña: ${error.message}`);
    }
  }

  private async verifyPurchase(buyerId: string, productId: string): Promise<boolean> {
    try {
      const q = query(
        collection(this.db, 'orders'),
        where('buyerId', '==', buyerId),
        where('productId', '==', productId),
        where('status', '==', 'completed')
      );
      const snapshot = await getDocs(q);
      return !snapshot.empty;
    } catch (error: any) {
      throw new Error(`Error al verificar compra: ${error.message}`);
    }
  }

  async getReview(reviewId: string): Promise<Review> {
    try {
      const docRef = doc(this.db, 'reviews', reviewId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Reseña no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as Review;
    } catch (error: any) {
      throw new Error(`Error al obtener reseña: ${error.message}`);
    }
  }

  async getProductReviews(
    productId: string,
    options: {
      sortBy?: 'date' | 'rating' | 'likes';
      order?: 'asc' | 'desc';
      limit?: number;
      onlyVerified?: boolean;
      withImages?: boolean;
    } = {}
  ): Promise<Review[]> {
    try {
      let q = query(collection(this.db, 'reviews'), where('productId', '==', productId));

      if (options.onlyVerified) {
        q = query(q, where('isVerifiedPurchase', '==', true));
      }

      if (options.withImages) {
        q = query(q, where('images', '!=', []));
      }

      switch (options.sortBy) {
        case 'rating':
          q = query(q, orderBy('rating', options.order || 'desc'));
          break;
        case 'likes':
          q = query(q, orderBy('likes', options.order || 'desc'));
          break;
        default:
          q = query(q, orderBy('createdAt', options.order || 'desc'));
      }

      if (options.limit) {
        q = query(q, limit(options.limit));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Review[];
    } catch (error: any) {
      throw new Error(`Error al obtener reseñas del producto: ${error.message}`);
    }
  }

  async getUserReviews(userId: string): Promise<Review[]> {
    try {
      const q = query(
        collection(this.db, 'reviews'),
        where('buyerId', '==', userId),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Review[];
    } catch (error: any) {
      throw new Error(`Error al obtener reseñas del usuario: ${error.message}`);
    }
  }

  async updateReview(
    reviewId: string,
    updates: Pick<Review, 'rating' | 'comment' | 'images'>
  ): Promise<void> {
    try {
      const reviewRef = doc(this.db, 'reviews', reviewId);
      const review = await this.getReview(reviewId);

      await updateDoc(reviewRef, {
        ...updates,
        updatedAt: new Date(),
      });

      // Actualizar estadísticas
      await this.updateProductStats(review.productId);
      await this.updateSellerStats(review.sellerId);
    } catch (error: any) {
      throw new Error(`Error al actualizar reseña: ${error.message}`);
    }
  }

  async deleteReview(reviewId: string): Promise<void> {
    try {
      const review = await this.getReview(reviewId);
      await deleteDoc(doc(this.db, 'reviews', reviewId));

      // Actualizar estadísticas
      await this.updateProductStats(review.productId);
      await this.updateSellerStats(review.sellerId);
    } catch (error: any) {
      throw new Error(`Error al eliminar reseña: ${error.message}`);
    }
  }

  async likeReview(reviewId: string): Promise<void> {
    try {
      const reviewRef = doc(this.db, 'reviews', reviewId);
      await updateDoc(reviewRef, {
        likes: increment(1),
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al dar like a la reseña: ${error.message}`);
    }
  }

  async dislikeReview(reviewId: string): Promise<void> {
    try {
      const reviewRef = doc(this.db, 'reviews', reviewId);
      await updateDoc(reviewRef, {
        dislikes: increment(1),
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al dar dislike a la reseña: ${error.message}`);
    }
  }

  async getProductStats(productId: string): Promise<ReviewStats> {
    try {
      const reviews = await this.getProductReviews(productId);

      const stats: ReviewStats = {
        totalReviews: reviews.length,
        averageRating:
          reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length || 0,
        ratingDistribution: {},
        verifiedPurchaseCount: reviews.filter((r) => r.isVerifiedPurchase).length,
        withImagesCount: reviews.filter((r) => r.images && r.images.length > 0).length,
      };

      // Calcular distribución de calificaciones
      reviews.forEach((review) => {
        stats.ratingDistribution[review.rating] =
          (stats.ratingDistribution[review.rating] || 0) + 1;
      });

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas del producto: ${error.message}`);
    }
  }

  private async updateProductStats(productId: string): Promise<void> {
    try {
      const stats = await this.getProductStats(productId);
      await marketService.updateProductRating(productId, stats.averageRating);
    } catch (error: any) {
      throw new Error(`Error al actualizar estadísticas del producto: ${error.message}`);
    }
  }

  private async updateSellerStats(sellerId: string): Promise<void> {
    try {
      const q = query(collection(this.db, 'reviews'), where('sellerId', '==', sellerId));
      const snapshot = await getDocs(q);
      const reviews = snapshot.docs.map((doc) => doc.data()) as Review[];

      const averageRating =
        reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length || 0;

      await profileService.updateSellerRating(sellerId, averageRating);
    } catch (error: any) {
      throw new Error(`Error al actualizar estadísticas del vendedor: ${error.message}`);
    }
  }

  async getTopRatedProducts(limit = 10): Promise<string[]> {
    try {
      const q = query(
        collection(this.db, 'products'),
        orderBy('rating', 'desc'),
        limit(limit)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => doc.id);
    } catch (error: any) {
      throw new Error(`Error al obtener productos mejor valorados: ${error.message}`);
    }
  }

  async getTopRatedSellers(limit = 10): Promise<string[]> {
    try {
      const q = query(
        collection(this.db, 'users'),
        orderBy('sellerRating', 'desc'),
        limit(limit)
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => doc.id);
    } catch (error: any) {
      throw new Error(`Error al obtener vendedores mejor valorados: ${error.message}`);
    }
  }
}

export const reviewService = ReviewService.getInstance();