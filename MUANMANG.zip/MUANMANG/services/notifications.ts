import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { useAppState } from '@/hooks/useAppState';

export async function registerForPushNotificationsAsync() {
  let token;

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('default', {
      name: 'default',
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: '#FF6B35',
    });
  }

  const { status: existingStatus } = await Notifications.getPermissionsAsync();
  let finalStatus = existingStatus;

  if (existingStatus !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }

  if (finalStatus !== 'granted') {
    return;
  }

  token = (await Notifications.getExpoPushTokenAsync()).data;
  return token;
}

export async function scheduleLocalNotification({
  title,
  body,
  data,
  trigger = null,
}: {
  title: string;
  body: string;
  data?: any;
  trigger?: Notifications.NotificationTriggerInput;
}) {
  await Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      data,
      sound: true,
      priority: Notifications.AndroidNotificationPriority.HIGH,
    },
    trigger,
  });
}

export function setupNotificationHandler() {
  const addNotification = useAppState.getState().addNotification;

  Notifications.setNotificationHandler({
    handleNotification: async () => ({
      shouldShowAlert: true,
      shouldPlaySound: true,
      shouldSetBadge: true,
    }),
  });

  const subscription = Notifications.addNotificationReceivedListener(
    (notification) => {
      const { title, body } = notification.request.content;
      addNotification({
        id: notification.request.identifier,
        title: title || 'Nueva notificación',
        message: body || '',
        type: 'info',
        read: false,
        createdAt: new Date(),
      });
    }
  );

  return () => subscription.remove();
}

export async function sendPushNotification(expoPushToken: string, {
  title,
  body,
  data,
}: {
  title: string;
  body: string;
  data?: any;
}) {
  const message = {
    to: expoPushToken,
    sound: 'default',
    title,
    body,
    data,
  };

  await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Accept-encoding': 'gzip, deflate',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(message),
  });
}