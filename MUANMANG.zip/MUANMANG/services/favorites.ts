import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs } from 'firebase/firestore';
import { marketService } from './market';

export interface WishlistItem {
  productId: string;
  addedAt: Date;
  notes?: string;
  priceAtAdd: number;
  currentPrice?: number;
  notifyOnPriceChange?: boolean;
  notifyOnAvailability?: boolean;
}

export interface Wishlist {
  id: string;
  userId: string;
  name: string;
  description?: string;
  isPublic: boolean;
  items: WishlistItem[];
  createdAt: Date;
  updatedAt: Date;
}

export interface FavoriteItem {
  productId: string;
  addedAt: Date;
}

export interface Favorites {
  userId: string;
  items: FavoriteItem[];
  updatedAt: Date;
}

export class FavoritesService {
  private db = getFirestore();
  private static instance: FavoritesService;

  private constructor() {}

  static getInstance(): FavoritesService {
    if (!FavoritesService.instance) {
      FavoritesService.instance = new FavoritesService();
    }
    return FavoritesService.instance;
  }

  // Gestión de Favoritos
  async getFavorites(userId: string): Promise<Favorites> {
    try {
      const favoritesRef = doc(this.db, 'favorites', userId);
      const favoritesDoc = await getDoc(favoritesRef);

      if (!favoritesDoc.exists()) {
        const newFavorites: Favorites = {
          userId,
          items: [],
          updatedAt: new Date(),
        };
        await setDoc(favoritesRef, newFavorites);
        return newFavorites;
      }

      return favoritesDoc.data() as Favorites;
    } catch (error: any) {
      throw new Error(`Error al obtener favoritos: ${error.message}`);
    }
  }

  async addToFavorites(userId: string, productId: string): Promise<void> {
    try {
      // Verificar que el producto existe
      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      const favorites = await this.getFavorites(userId);
      const exists = favorites.items.some((item) => item.productId === productId);

      if (!exists) {
        favorites.items.push({
          productId,
          addedAt: new Date(),
        });

        const favoritesRef = doc(this.db, 'favorites', userId);
        await setDoc(favoritesRef, {
          ...favorites,
          updatedAt: new Date(),
        });
      }
    } catch (error: any) {
      throw new Error(`Error al agregar a favoritos: ${error.message}`);
    }
  }

  async removeFromFavorites(userId: string, productId: string): Promise<void> {
    try {
      const favorites = await this.getFavorites(userId);
      favorites.items = favorites.items.filter((item) => item.productId !== productId);

      const favoritesRef = doc(this.db, 'favorites', userId);
      await setDoc(favoritesRef, {
        ...favorites,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al eliminar de favoritos: ${error.message}`);
    }
  }

  async isFavorite(userId: string, productId: string): Promise<boolean> {
    try {
      const favorites = await this.getFavorites(userId);
      return favorites.items.some((item) => item.productId === productId);
    } catch (error: any) {
      throw new Error(`Error al verificar favorito: ${error.message}`);
    }
  }

  // Gestión de Listas de Deseos
  async createWishlist({
    userId,
    name,
    description,
    isPublic = false,
  }: {
    userId: string;
    name: string;
    description?: string;
    isPublic?: boolean;
  }): Promise<Wishlist> {
    try {
      const wishlist: Omit<Wishlist, 'id'> = {
        userId,
        name,
        description,
        isPublic,
        items: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'wishlists'), wishlist);
      return { ...wishlist, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear lista de deseos: ${error.message}`);
    }
  }

  async getWishlist(wishlistId: string): Promise<Wishlist> {
    try {
      const docRef = doc(this.db, 'wishlists', wishlistId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Lista de deseos no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as Wishlist;
    } catch (error: any) {
      throw new Error(`Error al obtener lista de deseos: ${error.message}`);
    }
  }

  async getUserWishlists(userId: string): Promise<Wishlist[]> {
    try {
      const q = query(collection(this.db, 'wishlists'), where('userId', '==', userId));
      const snapshot = await getDocs(q);

      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Wishlist[];
    } catch (error: any) {
      throw new Error(`Error al obtener listas de deseos: ${error.message}`);
    }
  }

  async addToWishlist(
    wishlistId: string,
    productId: string,
    options: {
      notes?: string;
      notifyOnPriceChange?: boolean;
      notifyOnAvailability?: boolean;
    } = {}
  ): Promise<void> {
    try {
      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      const wishlist = await this.getWishlist(wishlistId);
      const exists = wishlist.items.some((item) => item.productId === productId);

      if (!exists) {
        const newItem: WishlistItem = {
          productId,
          addedAt: new Date(),
          notes: options.notes,
          priceAtAdd: product.price,
          currentPrice: product.price,
          notifyOnPriceChange: options.notifyOnPriceChange,
          notifyOnAvailability: options.notifyOnAvailability,
        };

        wishlist.items.push(newItem);

        const wishlistRef = doc(this.db, 'wishlists', wishlistId);
        await updateDoc(wishlistRef, {
          items: wishlist.items,
          updatedAt: new Date(),
        });
      }
    } catch (error: any) {
      throw new Error(`Error al agregar a lista de deseos: ${error.message}`);
    }
  }

  async removeFromWishlist(wishlistId: string, productId: string): Promise<void> {
    try {
      const wishlist = await this.getWishlist(wishlistId);
      wishlist.items = wishlist.items.filter((item) => item.productId !== productId);

      const wishlistRef = doc(this.db, 'wishlists', wishlistId);
      await updateDoc(wishlistRef, {
        items: wishlist.items,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al eliminar de lista de deseos: ${error.message}`);
    }
  }

  async updateWishlistItem(
    wishlistId: string,
    productId: string,
    updates: Partial<WishlistItem>
  ): Promise<void> {
    try {
      const wishlist = await this.getWishlist(wishlistId);
      const itemIndex = wishlist.items.findIndex((item) => item.productId === productId);

      if (itemIndex === -1) {
        throw new Error('Producto no encontrado en la lista de deseos');
      }

      wishlist.items[itemIndex] = {
        ...wishlist.items[itemIndex],
        ...updates,
      };

      const wishlistRef = doc(this.db, 'wishlists', wishlistId);
      await updateDoc(wishlistRef, {
        items: wishlist.items,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar item de lista de deseos: ${error.message}`);
    }
  }

  async deleteWishlist(wishlistId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'wishlists', wishlistId));
    } catch (error: any) {
      throw new Error(`Error al eliminar lista de deseos: ${error.message}`);
    }
  }

  async updateWishlistDetails(
    wishlistId: string,
    updates: Pick<Wishlist, 'name' | 'description' | 'isPublic'>
  ): Promise<void> {
    try {
      const wishlistRef = doc(this.db, 'wishlists', wishlistId);
      await updateDoc(wishlistRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar detalles de lista de deseos: ${error.message}`);
    }
  }

  async getPublicWishlists(): Promise<Wishlist[]> {
    try {
      const q = query(collection(this.db, 'wishlists'), where('isPublic', '==', true));
      const snapshot = await getDocs(q);

      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Wishlist[];
    } catch (error: any) {
      throw new Error(`Error al obtener listas de deseos públicas: ${error.message}`);
    }
  }
}

export const favoritesService = FavoritesService.getInstance();