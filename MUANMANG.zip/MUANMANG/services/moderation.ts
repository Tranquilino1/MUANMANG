import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { profileService } from './profile';
import { marketService } from './market';
import { reviewService } from './reviews';
import { chatService } from './chat';

export interface Report {
  id: string;
  reporterId: string;
  reportedId: string;
  reportType: 'user' | 'product' | 'review' | 'message';
  reason: string;
  description: string;
  evidence?: string[];
  status: 'pending' | 'investigating' | 'resolved' | 'dismissed';
  moderatorNotes?: string;
  moderatorId?: string;
  createdAt: Date;
  updatedAt: Date;
  resolvedAt?: Date;
}

export interface ContentViolation {
  id: string;
  userId: string;
  violationType: 'spam' | 'inappropriate' | 'offensive' | 'scam' | 'copyright' | 'other';
  severity: 'low' | 'medium' | 'high';
  description: string;
  createdAt: Date;
  expiresAt?: Date;
}

export interface ModerationStats {
  totalReports: number;
  pendingReports: number;
  resolvedReports: number;
  dismissedReports: number;
  averageResolutionTime: number;
  reportsByType: {
    user: number;
    product: number;
    review: number;
    message: number;
  };
}

export class ModerationService {
  private db = getFirestore();
  private static instance: ModerationService;

  private constructor() {}

  static getInstance(): ModerationService {
    if (!ModerationService.instance) {
      ModerationService.instance = new ModerationService();
    }
    return ModerationService.instance;
  }

  async createReport({
    reporterId,
    reportedId,
    reportType,
    reason,
    description,
    evidence = [],
  }: {
    reporterId: string;
    reportedId: string;
    reportType: Report['reportType'];
    reason: string;
    description: string;
    evidence?: string[];
  }): Promise<Report> {
    try {
      // Verificar que el reportador existe
      const reporter = await profileService.getUserProfile(reporterId);
      if (!reporter) {
        throw new Error('Reportador no encontrado');
      }

      // Verificar que el elemento reportado existe
      await this.validateReportedItem(reportedId, reportType);

      const report: Omit<Report, 'id'> = {
        reporterId,
        reportedId,
        reportType,
        reason,
        description,
        evidence,
        status: 'pending',
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'reports'), report);
      return { ...report, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear reporte: ${error.message}`);
    }
  }

  private async validateReportedItem(
    reportedId: string,
    reportType: Report['reportType']
  ): Promise<void> {
    try {
      switch (reportType) {
        case 'user':
          const user = await profileService.getUserProfile(reportedId);
          if (!user) throw new Error('Usuario reportado no encontrado');
          break;
        case 'product':
          const product = await marketService.getProduct(reportedId);
          if (!product) throw new Error('Producto reportado no encontrado');
          break;
        case 'review':
          const review = await reviewService.getReview(reportedId);
          if (!review) throw new Error('Reseña reportada no encontrada');
          break;
        case 'message':
          const message = await chatService.getMessage(reportedId);
          if (!message) throw new Error('Mensaje reportado no encontrado');
          break;
        default:
          throw new Error('Tipo de reporte inválido');
      }
    } catch (error: any) {
      throw new Error(`Error al validar elemento reportado: ${error.message}`);
    }
  }

  async getReport(reportId: string): Promise<Report> {
    try {
      const docRef = doc(this.db, 'reports', reportId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Reporte no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as Report;
    } catch (error: any) {
      throw new Error(`Error al obtener reporte: ${error.message}`);
    }
  }

  async updateReportStatus(
    reportId: string,
    status: Report['status'],
    moderatorId: string,
    notes?: string
  ): Promise<void> {
    try {
      const reportRef = doc(this.db, 'reports', reportId);
      const updates: Partial<Report> = {
        status,
        moderatorId,
        moderatorNotes: notes,
        updatedAt: new Date(),
      };

      if (status === 'resolved' || status === 'dismissed') {
        updates.resolvedAt = new Date();
      }

      await updateDoc(reportRef, updates);
    } catch (error: any) {
      throw new Error(`Error al actualizar estado del reporte: ${error.message}`);
    }
  }

  async getReports(
    options: {
      status?: Report['status'];
      reportType?: Report['reportType'];
      limit?: number;
      sortBy?: 'date' | 'status';
      order?: 'asc' | 'desc';
    } = {}
  ): Promise<Report[]> {
    try {
      let q = query(collection(this.db, 'reports'));

      if (options.status) {
        q = query(q, where('status', '==', options.status));
      }

      if (options.reportType) {
        q = query(q, where('reportType', '==', options.reportType));
      }

      switch (options.sortBy) {
        case 'status':
          q = query(q, orderBy('status', options.order || 'asc'));
          break;
        default:
          q = query(q, orderBy('createdAt', options.order || 'desc'));
      }

      if (options.limit) {
        q = query(q, limit(options.limit));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Report[];
    } catch (error: any) {
      throw new Error(`Error al obtener reportes: ${error.message}`);
    }
  }

  async addContentViolation(
    userId: string,
    violation: Omit<ContentViolation, 'id' | 'userId' | 'createdAt'>
  ): Promise<ContentViolation> {
    try {
      const user = await profileService.getUserProfile(userId);
      if (!user) {
        throw new Error('Usuario no encontrado');
      }

      const contentViolation: Omit<ContentViolation, 'id'> = {
        userId,
        ...violation,
        createdAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'contentViolations'), contentViolation);
      return { ...contentViolation, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al agregar violación de contenido: ${error.message}`);
    }
  }

  async getUserViolations(userId: string): Promise<ContentViolation[]> {
    try {
      const q = query(
        collection(this.db, 'contentViolations'),
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as ContentViolation[];
    } catch (error: any) {
      throw new Error(`Error al obtener violaciones del usuario: ${error.message}`);
    }
  }

  async getModerationStats(): Promise<ModerationStats> {
    try {
      const reports = await this.getReports();
      const now = new Date();

      const stats: ModerationStats = {
        totalReports: reports.length,
        pendingReports: reports.filter((r) => r.status === 'pending').length,
        resolvedReports: reports.filter((r) => r.status === 'resolved').length,
        dismissedReports: reports.filter((r) => r.status === 'dismissed').length,
        averageResolutionTime: this.calculateAverageResolutionTime(reports),
        reportsByType: {
          user: reports.filter((r) => r.reportType === 'user').length,
          product: reports.filter((r) => r.reportType === 'product').length,
          review: reports.filter((r) => r.reportType === 'review').length,
          message: reports.filter((r) => r.reportType === 'message').length,
        },
      };

      return stats;
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas de moderación: ${error.message}`);
    }
  }

  private calculateAverageResolutionTime(reports: Report[]): number {
    const resolvedReports = reports.filter(
      (r) => (r.status === 'resolved' || r.status === 'dismissed') && r.resolvedAt
    );

    if (resolvedReports.length === 0) return 0;

    const totalTime = resolvedReports.reduce((sum, report) => {
      const resolutionTime = report.resolvedAt!.getTime() - report.createdAt.getTime();
      return sum + resolutionTime;
    }, 0);

    return totalTime / resolvedReports.length;
  }

  async deleteReport(reportId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'reports', reportId));
    } catch (error: any) {
      throw new Error(`Error al eliminar reporte: ${error.message}`);
    }
  }

  async getReportsByUser(userId: string, type: 'reporter' | 'reported'): Promise<Report[]> {
    try {
      const field = type === 'reporter' ? 'reporterId' : 'reportedId';
      const q = query(
        collection(this.db, 'reports'),
        where(field, '==', userId),
        orderBy('createdAt', 'desc')
      );
      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Report[];
    } catch (error: any) {
      throw new Error(`Error al obtener reportes del usuario: ${error.message}`);
    }
  }
}

export const moderationService = ModerationService.getInstance();