import { getFirestore, collection, doc, getDoc, setDoc, updateDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { settingsService } from './settings';

export interface WebhookEndpoint {
  id: string;
  url: string;
  secret: string;
  description?: string;
  events: string[];
  headers?: Record<string, string>;
  active: boolean;
  retryConfig?: {
    maxAttempts: number;
    backoffDelay: number;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface WebhookDelivery {
  id: string;
  endpointId: string;
  eventType: string;
  payload: any;
  status: 'pending' | 'success' | 'failed';
  statusCode?: number;
  response?: string;
  error?: string;
  attempts: number;
  nextAttempt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface EventSubscription {
  id: string;
  eventType: string;
  callback: (payload: any) => Promise<void>;
  filter?: (payload: any) => boolean;
  active: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export class EventService {
  private db = getFirestore();
  private static instance: EventService;
  private subscriptions: Map<string, EventSubscription[]> = new Map();
  private webhookQueue: WebhookDelivery[] = [];
  private isProcessingQueue = false;

  private constructor() {
    this.startWebhookProcessor();
  }

  static getInstance(): EventService {
    if (!EventService.instance) {
      EventService.instance = new EventService();
    }
    return EventService.instance;
  }

  async createWebhookEndpoint(endpoint: Omit<WebhookEndpoint, 'id' | 'createdAt' | 'updatedAt'>): Promise<WebhookEndpoint> {
    try {
      const newEndpoint: Omit<WebhookEndpoint, 'id'> = {
        ...endpoint,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'webhookEndpoints'), newEndpoint);
      return { ...newEndpoint, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear endpoint de webhook: ${error.message}`);
    }
  }

  async updateWebhookEndpoint(
    endpointId: string,
    updates: Partial<Omit<WebhookEndpoint, 'id' | 'createdAt' | 'updatedAt'>>
  ): Promise<void> {
    try {
      const endpointRef = doc(this.db, 'webhookEndpoints', endpointId);
      await updateDoc(endpointRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar endpoint de webhook: ${error.message}`);
    }
  }

  async deleteWebhookEndpoint(endpointId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'webhookEndpoints', endpointId));
    } catch (error: any) {
      throw new Error(`Error al eliminar endpoint de webhook: ${error.message}`);
    }
  }

  async getWebhookEndpoint(endpointId: string): Promise<WebhookEndpoint> {
    try {
      const docRef = doc(this.db, 'webhookEndpoints', endpointId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Endpoint de webhook no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as WebhookEndpoint;
    } catch (error: any) {
      throw new Error(`Error al obtener endpoint de webhook: ${error.message}`);
    }
  }

  async getWebhookEndpoints(): Promise<WebhookEndpoint[]> {
    try {
      const snapshot = await getDocs(collection(this.db, 'webhookEndpoints'));
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as WebhookEndpoint[];
    } catch (error: any) {
      throw new Error(`Error al obtener endpoints de webhook: ${error.message}`);
    }
  }

  subscribe(eventType: string, callback: (payload: any) => Promise<void>, filter?: (payload: any) => boolean): string {
    const subscription: EventSubscription = {
      id: generateId(), // Función para generar ID único
      eventType,
      callback,
      filter,
      active: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const eventSubscriptions = this.subscriptions.get(eventType) || [];
    eventSubscriptions.push(subscription);
    this.subscriptions.set(eventType, eventSubscriptions);

    return subscription.id;
  }

  unsubscribe(subscriptionId: string): void {
    this.subscriptions.forEach((subscriptions, eventType) => {
      const index = subscriptions.findIndex((sub) => sub.id === subscriptionId);
      if (index !== -1) {
        subscriptions.splice(index, 1);
        if (subscriptions.length === 0) {
          this.subscriptions.delete(eventType);
        }
      }
    });
  }

  async emit(eventType: string, payload: any): Promise<void> {
    try {
      // Notificar a los suscriptores locales
      const eventSubscriptions = this.subscriptions.get(eventType) || [];
      const promises = eventSubscriptions
        .filter((sub) => sub.active && (!sub.filter || sub.filter(payload)))
        .map((sub) => sub.callback(payload));

      // Enviar a endpoints de webhook
      const webhookPromises = this.queueWebhookDeliveries(eventType, payload);

      await Promise.all([...promises, ...webhookPromises]);
    } catch (error: any) {
      throw new Error(`Error al emitir evento: ${error.message}`);
    }
  }

  private async queueWebhookDeliveries(eventType: string, payload: any): Promise<void> {
    try {
      const q = query(
        collection(this.db, 'webhookEndpoints'),
        where('active', '==', true),
        where('events', 'array-contains', eventType)
      );

      const snapshot = await getDocs(q);
      const deliveries: WebhookDelivery[] = [];

      snapshot.forEach((doc) => {
        const endpoint = { id: doc.id, ...doc.data() } as WebhookEndpoint;
        deliveries.push({
          id: generateId(), // Función para generar ID único
          endpointId: endpoint.id,
          eventType,
          payload,
          status: 'pending',
          attempts: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        });
      });

      // Guardar las entregas en la base de datos
      const batch = writeBatch(this.db);
      deliveries.forEach((delivery) => {
        const deliveryRef = doc(collection(this.db, 'webhookDeliveries'), delivery.id);
        batch.set(deliveryRef, delivery);
      });
      await batch.commit();

      // Agregar a la cola de procesamiento
      this.webhookQueue.push(...deliveries);

      // Iniciar procesamiento si no está en curso
      if (!this.isProcessingQueue) {
        this.processWebhookQueue();
      }
    } catch (error: any) {
      throw new Error(`Error al encolar entregas de webhook: ${error.message}`);
    }
  }

  private async processWebhookQueue(): Promise<void> {
    if (this.webhookQueue.length === 0) {
      this.isProcessingQueue = false;
      return;
    }

    this.isProcessingQueue = true;
    const delivery = this.webhookQueue.shift()!;

    try {
      const endpoint = await this.getWebhookEndpoint(delivery.endpointId);
      const result = await this.sendWebhook(endpoint, delivery);

      // Actualizar estado de la entrega
      await this.updateDeliveryStatus(delivery.id, result);

      // Procesar siguiente entrega
      setTimeout(() => this.processWebhookQueue(), 1000);
    } catch (error: any) {
      console.error(`Error al procesar webhook: ${error.message}`);
      // Reintentar si es posible
      if (this.shouldRetry(delivery)) {
        this.webhookQueue.push(delivery);
      }
      setTimeout(() => this.processWebhookQueue(), 1000);
    }
  }

  private async sendWebhook(endpoint: WebhookEndpoint, delivery: WebhookDelivery): Promise<{
    success: boolean;
    statusCode?: number;
    response?: string;
    error?: string;
  }> {
    try {
      const signature = this.generateSignature(delivery.payload, endpoint.secret);

      const response = await fetch(endpoint.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Webhook-Signature': signature,
          ...endpoint.headers,
        },
        body: JSON.stringify({
          id: delivery.id,
          type: delivery.eventType,
          payload: delivery.payload,
          timestamp: delivery.createdAt.toISOString(),
        }),
      });

      const responseText = await response.text();

      return {
        success: response.ok,
        statusCode: response.status,
        response: responseText,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  private async updateDeliveryStatus(
    deliveryId: string,
    result: {
      success: boolean;
      statusCode?: number;
      response?: string;
      error?: string;
    }
  ): Promise<void> {
    try {
      const deliveryRef = doc(this.db, 'webhookDeliveries', deliveryId);
      const delivery = (await getDoc(deliveryRef)).data() as WebhookDelivery;

      const updates: Partial<WebhookDelivery> = {
        status: result.success ? 'success' : 'failed',
        statusCode: result.statusCode,
        response: result.response,
        error: result.error,
        attempts: delivery.attempts + 1,
        updatedAt: new Date(),
      };

      if (!result.success && this.shouldRetry({ ...delivery, ...updates })) {
        updates.nextAttempt = this.calculateNextAttempt(delivery);
      }

      await updateDoc(deliveryRef, updates);
    } catch (error: any) {
      throw new Error(`Error al actualizar estado de entrega: ${error.message}`);
    }
  }

  private shouldRetry(delivery: WebhookDelivery): boolean {
    if (delivery.status === 'success') return false;

    const endpoint = await this.getWebhookEndpoint(delivery.endpointId);
    const maxAttempts = endpoint.retryConfig?.maxAttempts || 3;

    return delivery.attempts < maxAttempts;
  }

  private calculateNextAttempt(delivery: WebhookDelivery): Date {
    const endpoint = await this.getWebhookEndpoint(delivery.endpointId);
    const backoffDelay = endpoint.retryConfig?.backoffDelay || 60000; // 1 minuto por defecto

    const delay = backoffDelay * Math.pow(2, delivery.attempts);
    return new Date(Date.now() + delay);
  }

  private generateSignature(payload: any, secret: string): string {
    const hmac = createHmac('sha256', secret);
    return hmac.update(JSON.stringify(payload)).digest('hex');
  }

  async getDeliveryStatus(deliveryId: string): Promise<WebhookDelivery> {
    try {
      const docRef = doc(this.db, 'webhookDeliveries', deliveryId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Entrega de webhook no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as WebhookDelivery;
    } catch (error: any) {
      throw new Error(`Error al obtener estado de entrega: ${error.message}`);
    }
  }

  async getEndpointDeliveries(
    endpointId: string,
    options: {
      status?: WebhookDelivery['status'];
      limit?: number;
      startAfter?: Date;
    } = {}
  ): Promise<WebhookDelivery[]> {
    try {
      let q = query(
        collection(this.db, 'webhookDeliveries'),
        where('endpointId', '==', endpointId),
        orderBy('createdAt', 'desc')
      );

      if (options.status) {
        q = query(q, where('status', '==', options.status));
      }

      if (options.startAfter) {
        q = query(q, where('createdAt', '>', options.startAfter));
      }

      if (options.limit) {
        q = query(q, limit(options.limit));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as WebhookDelivery[];
    } catch (error: any) {
      throw new Error(`Error al obtener entregas del endpoint: ${error.message}`);
    }
  }
}

export const eventService = EventService.getInstance();