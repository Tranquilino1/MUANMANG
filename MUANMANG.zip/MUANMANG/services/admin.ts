import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { analyticsService } from './analytics';
import { marketService } from './market';
import { profileService } from './profile';
import { orderService } from './orders';
import { moderationService } from './moderation';

export interface AdminStats {
  users: {
    total: number;
    active: number;
    new: number;
    sellers: number;
    buyers: number;
  };
  products: {
    total: number;
    active: number;
    sold: number;
    reported: number;
    byCategory: { [key: string]: number };
  };
  orders: {
    total: number;
    pending: number;
    completed: number;
    cancelled: number;
    totalRevenue: number;
    averageOrderValue: number;
  };
  moderation: {
    totalReports: number;
    pendingReports: number;
    resolvedReports: number;
    contentViolations: number;
  };
  performance: {
    averageResponseTime: number;
    serverUptime: number;
    errorRate: number;
  };
}

export interface AdminAction {
  id: string;
  adminId: string;
  actionType: 'user_ban' | 'product_remove' | 'review_delete' | 'report_resolve' | 'settings_update';
  targetId: string;
  reason: string;
  metadata?: Record<string, any>;
  createdAt: Date;
}

export interface AdminSettings {
  id: string;
  commissionRate: number;
  minWithdrawalAmount: number;
  maxImageSize: number;
  allowedFileTypes: string[];
  autoModeration: {
    enabled: boolean;
    spamFilter: boolean;
    profanityFilter: boolean;
    imageModeration: boolean;
  };
  notificationSettings: {
    adminEmails: string[];
    alertThresholds: {
      reportCount: number;
      errorRate: number;
      responseTime: number;
    };
  };
  updatedAt: Date;
  updatedBy: string;
}

export class AdminService {
  private db = getFirestore();
  private static instance: AdminService;

  private constructor() {}

  static getInstance(): AdminService {
    if (!AdminService.instance) {
      AdminService.instance = new AdminService();
    }
    return AdminService.instance;
  }

  async getDashboardStats(timeRange?: { start: Date; end: Date }): Promise<AdminStats> {
    try {
      const [users, products, orders, moderation] = await Promise.all([
        this.getUserStats(timeRange),
        this.getProductStats(timeRange),
        this.getOrderStats(timeRange),
        moderationService.getModerationStats(),
      ]);

      const performance = await this.getPerformanceMetrics();

      return {
        users,
        products,
        orders,
        moderation: {
          totalReports: moderation.totalReports,
          pendingReports: moderation.pendingReports,
          resolvedReports: moderation.resolvedReports,
          contentViolations: await this.getContentViolationsCount(),
        },
        performance,
      };
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas del panel: ${error.message}`);
    }
  }

  private async getUserStats(timeRange?: {
    start: Date;
    end: Date;
  }): Promise<AdminStats['users']> {
    try {
      let q = query(collection(this.db, 'users'));

      if (timeRange) {
        q = query(
          q,
          where('createdAt', '>=', timeRange.start),
          where('createdAt', '<=', timeRange.end)
        );
      }

      const snapshot = await getDocs(q);
      const users = snapshot.docs.map((doc) => doc.data());

      return {
        total: users.length,
        active: users.filter((u) => u.lastActive > Date.now() - 30 * 24 * 60 * 60 * 1000).length,
        new: users.filter(
          (u) => u.createdAt > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        ).length,
        sellers: users.filter((u) => u.isSeller).length,
        buyers: users.filter((u) => u.purchases && u.purchases.length > 0).length,
      };
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas de usuarios: ${error.message}`);
    }
  }

  private async getProductStats(timeRange?: {
    start: Date;
    end: Date;
  }): Promise<AdminStats['products']> {
    try {
      let q = query(collection(this.db, 'products'));

      if (timeRange) {
        q = query(
          q,
          where('createdAt', '>=', timeRange.start),
          where('createdAt', '<=', timeRange.end)
        );
      }

      const snapshot = await getDocs(q);
      const products = snapshot.docs.map((doc) => doc.data());

      const byCategory = products.reduce((acc, product) => {
        acc[product.category] = (acc[product.category] || 0) + 1;
        return acc;
      }, {} as { [key: string]: number });

      return {
        total: products.length,
        active: products.filter((p) => p.status === 'active').length,
        sold: products.filter((p) => p.status === 'sold').length,
        reported: products.filter((p) => p.reportCount > 0).length,
        byCategory,
      };
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas de productos: ${error.message}`);
    }
  }

  private async getOrderStats(timeRange?: {
    start: Date;
    end: Date;
  }): Promise<AdminStats['orders']> {
    try {
      let q = query(collection(this.db, 'orders'));

      if (timeRange) {
        q = query(
          q,
          where('createdAt', '>=', timeRange.start),
          where('createdAt', '<=', timeRange.end)
        );
      }

      const snapshot = await getDocs(q);
      const orders = snapshot.docs.map((doc) => doc.data());

      const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);

      return {
        total: orders.length,
        pending: orders.filter((o) => o.status === 'pending').length,
        completed: orders.filter((o) => o.status === 'completed').length,
        cancelled: orders.filter((o) => o.status === 'cancelled').length,
        totalRevenue,
        averageOrderValue: totalRevenue / orders.length || 0,
      };
    } catch (error: any) {
      throw new Error(`Error al obtener estadísticas de pedidos: ${error.message}`);
    }
  }

  private async getContentViolationsCount(): Promise<number> {
    try {
      const snapshot = await getDocs(collection(this.db, 'contentViolations'));
      return snapshot.size;
    } catch (error: any) {
      throw new Error(`Error al obtener conteo de violaciones: ${error.message}`);
    }
  }

  private async getPerformanceMetrics(): Promise<AdminStats['performance']> {
    try {
      // Implementar lógica para obtener métricas de rendimiento
      return {
        averageResponseTime: 0, // Implementar cálculo real
        serverUptime: 0, // Implementar cálculo real
        errorRate: 0, // Implementar cálculo real
      };
    } catch (error: any) {
      throw new Error(`Error al obtener métricas de rendimiento: ${error.message}`);
    }
  }

  async logAdminAction(action: Omit<AdminAction, 'id' | 'createdAt'>): Promise<AdminAction> {
    try {
      const adminAction: Omit<AdminAction, 'id'> = {
        ...action,
        createdAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'adminActions'), adminAction);
      return { ...adminAction, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al registrar acción administrativa: ${error.message}`);
    }
  }

  async getAdminActions(
    options: {
      adminId?: string;
      actionType?: AdminAction['actionType'];
      limit?: number;
      startAfter?: Date;
    } = {}
  ): Promise<AdminAction[]> {
    try {
      let q = query(collection(this.db, 'adminActions'), orderBy('createdAt', 'desc'));

      if (options.adminId) {
        q = query(q, where('adminId', '==', options.adminId));
      }

      if (options.actionType) {
        q = query(q, where('actionType', '==', options.actionType));
      }

      if (options.startAfter) {
        q = query(q, where('createdAt', '>', options.startAfter));
      }

      if (options.limit) {
        q = query(q, limit(options.limit));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as AdminAction[];
    } catch (error: any) {
      throw new Error(`Error al obtener acciones administrativas: ${error.message}`);
    }
  }

  async getAdminSettings(): Promise<AdminSettings> {
    try {
      const docRef = doc(this.db, 'adminSettings', 'global');
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Configuración administrativa no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as AdminSettings;
    } catch (error: any) {
      throw new Error(`Error al obtener configuración administrativa: ${error.message}`);
    }
  }

  async updateAdminSettings(
    updates: Partial<Omit<AdminSettings, 'id' | 'updatedAt' | 'updatedBy'>>,
    adminId: string
  ): Promise<void> {
    try {
      const settingsRef = doc(this.db, 'adminSettings', 'global');
      await updateDoc(settingsRef, {
        ...updates,
        updatedAt: new Date(),
        updatedBy: adminId,
      });

      await this.logAdminAction({
        adminId,
        actionType: 'settings_update',
        targetId: 'global',
        reason: 'Actualización de configuración administrativa',
        metadata: updates,
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar configuración administrativa: ${error.message}`);
    }
  }

  async getSystemHealth(): Promise<{
    status: 'healthy' | 'degraded' | 'critical';
    issues: string[];
  }> {
    try {
      const issues: string[] = [];
      const metrics = await this.getPerformanceMetrics();
      const settings = await this.getAdminSettings();

      if (metrics.errorRate > settings.notificationSettings.alertThresholds.errorRate) {
        issues.push('Alta tasa de errores');
      }

      if (
        metrics.averageResponseTime >
        settings.notificationSettings.alertThresholds.responseTime
      ) {
        issues.push('Tiempo de respuesta elevado');
      }

      if (metrics.serverUptime < 95) {
        issues.push('Baja disponibilidad del servidor');
      }

      return {
        status: issues.length === 0 ? 'healthy' : issues.length < 2 ? 'degraded' : 'critical',
        issues,
      };
    } catch (error: any) {
      throw new Error(`Error al obtener estado del sistema: ${error.message}`);
    }
  }
}

export const adminService = AdminService.getInstance();