import { getFirestore, doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';

export interface AppSettings {
  id: string;
  general: {
    appName: string;
    defaultLanguage: string;
    defaultCurrency: string;
    supportedLanguages: string[];
    supportedCurrencies: string[];
    maintenanceMode: boolean;
    version: string;
  };
  features: {
    enableChat: boolean;
    enableNotifications: boolean;
    enableRatings: boolean;
    enableComments: boolean;
    enableSharing: boolean;
  };
  security: {
    passwordMinLength: number;
    requireEmailVerification: boolean;
    requirePhoneVerification: boolean;
    maxLoginAttempts: number;
    sessionTimeout: number;
  };
  payment: {
    providers: {
      munidinero: {
        enabled: boolean;
        minAmount: number;
        maxAmount: number;
        fee: number;
      };
      ecobank: {
        enabled: boolean;
        minAmount: number;
        maxAmount: number;
        fee: number;
      };
      bange: {
        enabled: boolean;
        minAmount: number;
        maxAmount: number;
        fee: number;
      };
    };
    defaultCurrency: string;
    minimumOrderAmount: number;
  };
  marketplace: {
    categories: string[];
    featuredCategories: string[];
    maxImagesPerProduct: number;
    maxProductsPerSeller: number;
    commissionRate: number;
  };
  notifications: {
    email: {
      enabled: boolean;
      fromEmail: string;
      templates: {
        welcome: string;
        orderConfirmation: string;
        passwordReset: string;
      };
    };
    push: {
      enabled: boolean;
      vapidKey: string;
    };
  };
  localization: {
    defaultTimeZone: string;
    dateFormat: string;
    timeFormat: string;
    numberFormat: string;
    currencies: {
      [key: string]: {
        symbol: string;
        position: 'before' | 'after';
        decimals: number;
      };
    };
  };
  seo: {
    defaultTitle: string;
    defaultDescription: string;
    defaultKeywords: string[];
    googleAnalyticsId?: string;
  };
  updatedAt: Date;
}

export class SettingsService {
  private db = getFirestore();
  private static instance: SettingsService;
  private cachedSettings: AppSettings | null = null;
  private lastFetch: number = 0;
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 minutos

  private constructor() {}

  static getInstance(): SettingsService {
    if (!SettingsService.instance) {
      SettingsService.instance = new SettingsService();
    }
    return SettingsService.instance;
  }

  async getSettings(): Promise<AppSettings> {
    try {
      const now = Date.now();
      if (this.cachedSettings && now - this.lastFetch < this.CACHE_DURATION) {
        return this.cachedSettings;
      }

      const docRef = doc(this.db, 'settings', 'app_settings');
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        // Crear configuración predeterminada si no existe
        const defaultSettings: AppSettings = {
          id: 'app_settings',
          general: {
            appName: 'MUANMANG',
            defaultLanguage: 'es',
            defaultCurrency: 'XAF',
            supportedLanguages: ['es'],
            supportedCurrencies: ['XAF'],
            maintenanceMode: false,
            version: '1.0.0',
          },
          features: {
            enableChat: true,
            enableNotifications: true,
            enableRatings: true,
            enableComments: true,
            enableSharing: true,
          },
          security: {
            passwordMinLength: 8,
            requireEmailVerification: true,
            requirePhoneVerification: true,
            maxLoginAttempts: 5,
            sessionTimeout: 30 * 24 * 60 * 60 * 1000, // 30 días
          },
          payment: {
            providers: {
              munidinero: {
                enabled: true,
                minAmount: 1000,
                maxAmount: 500000,
                fee: 0.015,
              },
              ecobank: {
                enabled: true,
                minAmount: 5000,
                maxAmount: 1000000,
                fee: 0.02,
              },
              bange: {
                enabled: true,
                minAmount: 2500,
                maxAmount: 750000,
                fee: 0.018,
              },
            },
            defaultCurrency: 'XAF',
            minimumOrderAmount: 1000,
          },
          marketplace: {
            categories: [
              'Moda',
              'Electrónica',
              'Hogar',
              'Deportes',
              'Belleza',
              'Juguetes',
              'Libros',
              'Arte',
            ],
            featuredCategories: ['Moda', 'Electrónica', 'Hogar'],
            maxImagesPerProduct: 10,
            maxProductsPerSeller: 100,
            commissionRate: 0.05,
          },
          notifications: {
            email: {
              enabled: true,
              fromEmail: 'noreply@muanmang.com',
              templates: {
                welcome: 'welcome_template',
                orderConfirmation: 'order_confirmation_template',
                passwordReset: 'password_reset_template',
              },
            },
            push: {
              enabled: true,
              vapidKey: '',
            },
          },
          localization: {
            defaultTimeZone: 'Africa/Malabo',
            dateFormat: 'DD/MM/YYYY',
            timeFormat: 'HH:mm',
            numberFormat: '#,##0.00',
            currencies: {
              XAF: {
                symbol: 'XAF',
                position: 'after',
                decimals: 0,
              },
            },
          },
          seo: {
            defaultTitle: 'MUANMANG - Mercado Digital de Guinea Ecuatorial',
            defaultDescription:
              'Compra y vende productos en el mercado digital líder de Guinea Ecuatorial',
            defaultKeywords: [
              'mercado',
              'ecommerce',
              'guinea ecuatorial',
              'compras',
              'ventas',
            ],
          },
          updatedAt: new Date(),
        };

        await setDoc(docRef, defaultSettings);
        this.cachedSettings = defaultSettings;
      } else {
        this.cachedSettings = { id: docSnap.id, ...docSnap.data() } as AppSettings;
      }

      this.lastFetch = now;
      return this.cachedSettings;
    } catch (error: any) {
      throw new Error(`Error al obtener configuración: ${error.message}`);
    }
  }

  async updateSettings(updates: Partial<AppSettings>): Promise<void> {
    try {
      const docRef = doc(this.db, 'settings', 'app_settings');
      await updateDoc(docRef, {
        ...updates,
        updatedAt: new Date(),
      });

      // Invalidar caché
      this.cachedSettings = null;
      this.lastFetch = 0;
    } catch (error: any) {
      throw new Error(`Error al actualizar configuración: ${error.message}`);
    }
  }

  async getPaymentSettings(): Promise<AppSettings['payment']> {
    const settings = await this.getSettings();
    return settings.payment;
  }

  async getMarketplaceSettings(): Promise<AppSettings['marketplace']> {
    const settings = await this.getSettings();
    return settings.marketplace;
  }

  async getLocalizationSettings(): Promise<AppSettings['localization']> {
    const settings = await this.getSettings();
    return settings.localization;
  }

  async updateMaintenanceMode(enabled: boolean): Promise<void> {
    await this.updateSettings({
      general: {
        maintenanceMode: enabled,
      } as AppSettings['general'],
    });
  }

  async updateFeatureFlags(features: Partial<AppSettings['features']>): Promise<void> {
    await this.updateSettings({ features });
  }

  async updateSecuritySettings(security: Partial<AppSettings['security']>): Promise<void> {
    await this.updateSettings({ security });
  }
}

export const settingsService = SettingsService.getInstance();