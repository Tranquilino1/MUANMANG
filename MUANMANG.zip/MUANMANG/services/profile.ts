import { getFirestore, doc, getDoc, updateDoc, collection, query, where, getDocs } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export interface UserProfile {
  id: string;
  displayName: string;
  email: string;
  phoneNumber?: string;
  avatar?: string;
  bio?: string;
  location?: string;
  preferences: {
    language: string;
    currency: string;
    notifications: {
      email: boolean;
      push: boolean;
      sms: boolean;
    };
    privacy: {
      profileVisibility: 'public' | 'private';
      showEmail: boolean;
      showPhone: boolean;
    };
  };
  stats: {
    productsListed: number;
    productsSold: number;
    rating: number;
    reviews: number;
  };
  verification: {
    email: boolean;
    phone: boolean;
    government: boolean;
  };
  paymentInfo?: {
    munidinero?: string;
    ecobank?: string;
    bange?: string;
  };
  createdAt: Date;
  updatedAt: Date;
}

export interface Review {
  id: string;
  userId: string;
  reviewerId: string;
  rating: number;
  comment: string;
  createdAt: Date;
}

export class ProfileService {
  private db = getFirestore();
  private storage = getStorage();

  async getUserProfile(userId: string): Promise<UserProfile> {
    try {
      const docRef = doc(this.db, 'users', userId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Perfil de usuario no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as UserProfile;
    } catch (error: any) {
      throw new Error(`Error al obtener perfil: ${error.message}`);
    }
  }

  async updateProfile(userId: string, updates: Partial<UserProfile>): Promise<void> {
    try {
      const userRef = doc(this.db, 'users', userId);
      await updateDoc(userRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar perfil: ${error.message}`);
    }
  }

  async uploadAvatar(userId: string, file: Blob): Promise<string> {
    try {
      const storageRef = ref(this.storage, `avatars/${userId}`);
      await uploadBytes(storageRef, file);
      const avatarUrl = await getDownloadURL(storageRef);

      await this.updateProfile(userId, { avatar: avatarUrl });
      return avatarUrl;
    } catch (error: any) {
      throw new Error(`Error al subir avatar: ${error.message}`);
    }
  }

  async updatePaymentInfo(
    userId: string,
    paymentInfo: {
      munidinero?: string;
      ecobank?: string;
      bange?: string;
    }
  ): Promise<void> {
    try {
      await this.updateProfile(userId, { paymentInfo });
    } catch (error: any) {
      throw new Error(`Error al actualizar información de pago: ${error.message}`);
    }
  }

  async updatePrivacySettings(
    userId: string,
    privacy: {
      profileVisibility: 'public' | 'private';
      showEmail: boolean;
      showPhone: boolean;
    }
  ): Promise<void> {
    try {
      await this.updateProfile(userId, {
        preferences: { privacy },
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar configuración de privacidad: ${error.message}`);
    }
  }

  async updateNotificationPreferences(
    userId: string,
    notifications: {
      email: boolean;
      push: boolean;
      sms: boolean;
    }
  ): Promise<void> {
    try {
      await this.updateProfile(userId, {
        preferences: { notifications },
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar preferencias de notificación: ${error.message}`);
    }
  }

  async addReview(review: Omit<Review, 'id' | 'createdAt'>): Promise<Review> {
    try {
      const reviewData = {
        ...review,
        createdAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'reviews'), reviewData);

      // Actualizar estadísticas del usuario
      const userRef = doc(this.db, 'users', review.userId);
      const userDoc = await getDoc(userRef);
      const userData = userDoc.data() as UserProfile;

      const newRating =
        (userData.stats.rating * userData.stats.reviews + review.rating) /
        (userData.stats.reviews + 1);

      await updateDoc(userRef, {
        'stats.rating': newRating,
        'stats.reviews': increment(1),
      });

      return { ...reviewData, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al añadir reseña: ${error.message}`);
    }
  }

  async getUserReviews(userId: string): Promise<Review[]> {
    try {
      const q = query(
        collection(this.db, 'reviews'),
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Review[];
    } catch (error: any) {
      throw new Error(`Error al obtener reseñas: ${error.message}`);
    }
  }

  async searchUsers(query: string): Promise<UserProfile[]> {
    try {
      const q = query(
        collection(this.db, 'users'),
        where('preferences.privacy.profileVisibility', '==', 'public'),
        orderBy('displayName')
      );

      const snapshot = await getDocs(q);
      const users = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as UserProfile[];

      return users.filter(
        (user) =>
          user.displayName.toLowerCase().includes(query.toLowerCase()) ||
          (user.preferences.privacy.showEmail &&
            user.email.toLowerCase().includes(query.toLowerCase()))
      );
    } catch (error: any) {
      throw new Error(`Error al buscar usuarios: ${error.message}`);
    }
  }
}

export const profileService = new ProfileService();