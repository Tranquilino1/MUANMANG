import { getFirestore, doc, getDoc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { marketService } from './market';

export interface CartItem {
  productId: string;
  quantity: number;
  price: number;
  addedAt: Date;
}

export interface Cart {
  id: string;
  userId: string;
  items: CartItem[];
  subtotal: number;
  shipping: number;
  tax: number;
  total: number;
  createdAt: Date;
  updatedAt: Date;
}

export class CartService {
  private db = getFirestore();
  private static instance: CartService;

  private constructor() {}

  static getInstance(): CartService {
    if (!CartService.instance) {
      CartService.instance = new CartService();
    }
    return CartService.instance;
  }

  async getCart(userId: string): Promise<Cart> {
    try {
      const cartRef = doc(this.db, 'carts', userId);
      const cartDoc = await getDoc(cartRef);

      if (!cartDoc.exists()) {
        // Crear un carrito vacío si no existe
        const newCart: Cart = {
          id: userId,
          userId,
          items: [],
          subtotal: 0,
          shipping: 0,
          tax: 0,
          total: 0,
          createdAt: new Date(),
          updatedAt: new Date(),
        };

        await setDoc(cartRef, newCart);
        return newCart;
      }

      return cartDoc.data() as Cart;
    } catch (error: any) {
      throw new Error(`Error al obtener carrito: ${error.message}`);
    }
  }

  async addToCart(
    userId: string,
    productId: string,
    quantity: number = 1
  ): Promise<Cart> {
    try {
      // Verificar el producto
      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      if (product.stock < quantity) {
        throw new Error('Stock insuficiente');
      }

      const cart = await this.getCart(userId);
      const existingItemIndex = cart.items.findIndex(
        (item) => item.productId === productId
      );

      if (existingItemIndex >= 0) {
        // Actualizar cantidad si el producto ya está en el carrito
        const newQuantity = cart.items[existingItemIndex].quantity + quantity;
        if (newQuantity > product.stock) {
          throw new Error('Stock insuficiente');
        }
        cart.items[existingItemIndex].quantity = newQuantity;
      } else {
        // Agregar nuevo item al carrito
        cart.items.push({
          productId,
          quantity,
          price: product.price,
          addedAt: new Date(),
        });
      }

      // Recalcular totales
      await this.updateCartTotals(cart);

      // Guardar cambios
      const cartRef = doc(this.db, 'carts', userId);
      await updateDoc(cartRef, {
        items: cart.items,
        subtotal: cart.subtotal,
        shipping: cart.shipping,
        tax: cart.tax,
        total: cart.total,
        updatedAt: new Date(),
      });

      return cart;
    } catch (error: any) {
      throw new Error(`Error al agregar al carrito: ${error.message}`);
    }
  }

  async updateCartItem(
    userId: string,
    productId: string,
    quantity: number
  ): Promise<Cart> {
    try {
      if (quantity < 0) {
        throw new Error('La cantidad debe ser mayor a 0');
      }

      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      if (quantity > product.stock) {
        throw new Error('Stock insuficiente');
      }

      const cart = await this.getCart(userId);
      const itemIndex = cart.items.findIndex((item) => item.productId === productId);

      if (itemIndex === -1) {
        throw new Error('Producto no encontrado en el carrito');
      }

      if (quantity === 0) {
        // Eliminar el item si la cantidad es 0
        cart.items.splice(itemIndex, 1);
      } else {
        // Actualizar cantidad
        cart.items[itemIndex].quantity = quantity;
      }

      // Recalcular totales
      await this.updateCartTotals(cart);

      // Guardar cambios
      const cartRef = doc(this.db, 'carts', userId);
      await updateDoc(cartRef, {
        items: cart.items,
        subtotal: cart.subtotal,
        shipping: cart.shipping,
        tax: cart.tax,
        total: cart.total,
        updatedAt: new Date(),
      });

      return cart;
    } catch (error: any) {
      throw new Error(`Error al actualizar item del carrito: ${error.message}`);
    }
  }

  async removeFromCart(userId: string, productId: string): Promise<Cart> {
    try {
      const cart = await this.getCart(userId);
      cart.items = cart.items.filter((item) => item.productId !== productId);

      // Recalcular totales
      await this.updateCartTotals(cart);

      // Guardar cambios
      const cartRef = doc(this.db, 'carts', userId);
      await updateDoc(cartRef, {
        items: cart.items,
        subtotal: cart.subtotal,
        shipping: cart.shipping,
        tax: cart.tax,
        total: cart.total,
        updatedAt: new Date(),
      });

      return cart;
    } catch (error: any) {
      throw new Error(`Error al eliminar del carrito: ${error.message}`);
    }
  }

  async clearCart(userId: string): Promise<void> {
    try {
      const cartRef = doc(this.db, 'carts', userId);
      await updateDoc(cartRef, {
        items: [],
        subtotal: 0,
        shipping: 0,
        tax: 0,
        total: 0,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al limpiar carrito: ${error.message}`);
    }
  }

  private async updateCartTotals(cart: Cart): Promise<void> {
    try {
      // Calcular subtotal
      cart.subtotal = cart.items.reduce(
        (total, item) => total + item.price * item.quantity,
        0
      );

      // Calcular envío (implementar lógica de cálculo de envío según necesidades)
      cart.shipping = await this.calculateShipping(cart);

      // Calcular impuestos (implementar según regulaciones locales)
      cart.tax = await this.calculateTax(cart.subtotal);

      // Calcular total
      cart.total = cart.subtotal + cart.shipping + cart.tax;
    } catch (error: any) {
      throw new Error(`Error al actualizar totales: ${error.message}`);
    }
  }

  private async calculateShipping(cart: Cart): Promise<number> {
    // Implementar lógica de cálculo de envío
    // Por ejemplo, basado en peso, distancia, o tarifa fija
    return 0; // Por ahora, envío gratuito
  }

  private async calculateTax(subtotal: number): Promise<number> {
    // Implementar cálculo de impuestos según regulaciones locales
    const taxRate = 0.16; // 16% IVA
    return subtotal * taxRate;
  }

  async validateCartItems(userId: string): Promise<{
    valid: boolean;
    invalidItems: string[];
  }> {
    try {
      const cart = await this.getCart(userId);
      const invalidItems: string[] = [];

      for (const item of cart.items) {
        const product = await marketService.getProduct(item.productId);
        if (!product || product.stock < item.quantity) {
          invalidItems.push(item.productId);
        }
      }

      return {
        valid: invalidItems.length === 0,
        invalidItems,
      };
    } catch (error: any) {
      throw new Error(`Error al validar items del carrito: ${error.message}`);
    }
  }
}

export const cartService = CartService.getInstance();