import { getFirestore, collection, addDoc, query, where, orderBy, getDocs, updateDoc, doc, writeBatch } from 'firebase/firestore';
import { marketService } from './market';
import { paymentService } from './payments';
import { notificationService } from './notifications';

export interface Order {
  id: string;
  buyerId: string;
  sellerId: string;
  productId: string;
  quantity: number;
  totalAmount: number;
  currency: string;
  status: 'pending' | 'paid' | 'processing' | 'shipped' | 'delivered' | 'cancelled' | 'refunded';
  paymentMethod: string;
  paymentStatus: 'pending' | 'completed' | 'failed' | 'refunded';
  shippingAddress?: {
    name: string;
    address: string;
    city: string;
    phone: string;
    notes?: string;
  };
  tracking?: {
    number?: string;
    carrier?: string;
    status?: string;
    estimatedDelivery?: Date;
    updates: {
      status: string;
      location?: string;
      timestamp: Date;
      description?: string;
    }[];
  };
  metadata?: any;
  createdAt: Date;
  updatedAt: Date;
}

export class OrderService {
  private db = getFirestore();

  async createOrder({
    buyerId,
    productId,
    quantity,
    paymentMethod,
    shippingAddress,
  }: {
    buyerId: string;
    productId: string;
    quantity: number;
    paymentMethod: string;
    shippingAddress?: Order['shippingAddress'];
  }): Promise<Order> {
    try {
      const product = await marketService.getProduct(productId);
      if (!product) {
        throw new Error('Producto no encontrado');
      }

      if (product.stock < quantity) {
        throw new Error('Stock insuficiente');
      }

      const totalAmount = product.price * quantity;
      const orderData: Omit<Order, 'id'> = {
        buyerId,
        sellerId: product.seller.id,
        productId,
        quantity,
        totalAmount,
        currency: 'XAF',
        status: 'pending',
        paymentMethod,
        paymentStatus: 'pending',
        shippingAddress,
        tracking: {
          updates: [],
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'orders'), orderData);

      // Iniciar el proceso de pago
      const payment = await paymentService.initializePayment({
        userId: buyerId,
        amount: totalAmount,
        paymentMethod,
        description: `Pago por ${quantity} unidad(es) de ${product.name}`,
      });

      // Actualizar el stock del producto
      await marketService.updateProduct(productId, {
        stock: product.stock - quantity,
      });

      // Notificar al vendedor
      await notificationService.sendNotification({
        userId: product.seller.id,
        title: 'Nuevo pedido recibido',
        body: `Has recibido un nuevo pedido por ${quantity} unidad(es) de ${product.name}`,
        type: 'order',
        data: { orderId: docRef.id },
      });

      return { ...orderData, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear pedido: ${error.message}`);
    }
  }

  async getOrder(orderId: string): Promise<Order> {
    try {
      const docRef = doc(this.db, 'orders', orderId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Pedido no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as Order;
    } catch (error: any) {
      throw new Error(`Error al obtener pedido: ${error.message}`);
    }
  }

  async getUserOrders(userId: string, role: 'buyer' | 'seller'): Promise<Order[]> {
    try {
      const q = query(
        collection(this.db, 'orders'),
        where(role === 'buyer' ? 'buyerId' : 'sellerId', '==', userId),
        orderBy('createdAt', 'desc')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Order[];
    } catch (error: any) {
      throw new Error(`Error al obtener pedidos: ${error.message}`);
    }
  }

  async updateOrderStatus(orderId: string, status: Order['status'], metadata?: any): Promise<void> {
    try {
      const orderRef = doc(this.db, 'orders', orderId);
      const order = await this.getOrder(orderId);

      await updateDoc(orderRef, {
        status,
        metadata: { ...order.metadata, ...metadata },
        updatedAt: new Date(),
      });

      // Notificar al comprador sobre el cambio de estado
      await notificationService.sendNotification({
        userId: order.buyerId,
        title: 'Actualización de pedido',
        body: `Tu pedido ha sido actualizado a: ${status}`,
        type: 'order',
        data: { orderId },
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar estado del pedido: ${error.message}`);
    }
  }

  async updateTrackingInfo(
    orderId: string,
    trackingInfo: {
      number?: string;
      carrier?: string;
      status?: string;
      estimatedDelivery?: Date;
      update?: {
        status: string;
        location?: string;
        description?: string;
      };
    }
  ): Promise<void> {
    try {
      const orderRef = doc(this.db, 'orders', orderId);
      const order = await this.getOrder(orderId);

      const updates = order.tracking?.updates || [];
      if (trackingInfo.update) {
        updates.push({
          ...trackingInfo.update,
          timestamp: new Date(),
        });
      }

      await updateDoc(orderRef, {
        tracking: {
          ...order.tracking,
          ...trackingInfo,
          updates,
        },
        updatedAt: new Date(),
      });

      // Notificar al comprador sobre la actualización del envío
      await notificationService.sendNotification({
        userId: order.buyerId,
        title: 'Actualización de envío',
        body: trackingInfo.update?.description || 'Tu pedido ha sido actualizado',
        type: 'order',
        data: { orderId },
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar información de seguimiento: ${error.message}`);
    }
  }

  async cancelOrder(orderId: string, reason: string): Promise<void> {
    try {
      const order = await this.getOrder(orderId);
      if (order.status !== 'pending' && order.status !== 'paid') {
        throw new Error('No se puede cancelar este pedido en su estado actual');
      }

      const batch = writeBatch(this.db);

      // Actualizar estado del pedido
      const orderRef = doc(this.db, 'orders', orderId);
      batch.update(orderRef, {
        status: 'cancelled',
        metadata: { ...order.metadata, cancellationReason: reason },
        updatedAt: new Date(),
      });

      // Restaurar stock del producto
      const productRef = doc(this.db, 'products', order.productId);
      batch.update(productRef, {
        stock: increment(order.quantity),
      });

      await batch.commit();

      // Procesar reembolso si es necesario
      if (order.paymentStatus === 'completed') {
        await paymentService.refundPayment(order.id);
      }

      // Notificar a las partes involucradas
      await Promise.all([
        notificationService.sendNotification({
          userId: order.buyerId,
          title: 'Pedido cancelado',
          body: `Tu pedido ha sido cancelado. Razón: ${reason}`,
          type: 'order',
          data: { orderId },
        }),
        notificationService.sendNotification({
          userId: order.sellerId,
          title: 'Pedido cancelado',
          body: `Un pedido ha sido cancelado. Razón: ${reason}`,
          type: 'order',
          data: { orderId },
        }),
      ]);
    } catch (error: any) {
      throw new Error(`Error al cancelar pedido: ${error.message}`);
    }
  }
}

export const orderService = new OrderService();