import { getDatabase, ref, onValue, off, push, set, update, remove, query, orderByChild, equalTo, limitToLast } from 'firebase/database';
import { profileService } from './profile';
import { notificationsService } from './notifications';

export interface RealtimeMessage {
  id: string;
  type: 'chat' | 'system' | 'order_update' | 'payment_update' | 'shipping_update';
  senderId: string;
  receiverId: string;
  content: string;
  metadata?: {
    orderId?: string;
    productId?: string;
    paymentId?: string;
    shipmentId?: string;
    [key: string]: any;
  };
  status: 'sent' | 'delivered' | 'read';
  createdAt: number; // timestamp
  updatedAt: number; // timestamp
}

export interface RealtimePresence {
  userId: string;
  status: 'online' | 'away' | 'offline';
  lastSeen: number; // timestamp
  device?: {
    type: string;
    platform: string;
    version: string;
  };
}

export interface RealtimeRoom {
  id: string;
  type: 'private' | 'group' | 'support';
  participants: string[];
  lastMessage?: {
    content: string;
    senderId: string;
    timestamp: number;
  };
  metadata?: {
    orderId?: string;
    productId?: string;
    [key: string]: any;
  };
  createdAt: number;
  updatedAt: number;
}

export class RealtimeService {
  private db = getDatabase();
  private static instance: RealtimeService;
  private presenceRef: any;
  private userStatusRef: any;
  private messageListeners: Map<string, () => void> = new Map();
  private presenceListeners: Map<string, () => void> = new Map();

  private constructor() {
    this.setupPresenceSystem();
  }

  static getInstance(): RealtimeService {
    if (!RealtimeService.instance) {
      RealtimeService.instance = new RealtimeService();
    }
    return RealtimeService.instance;
  }

  private setupPresenceSystem() {
    const userId = profileService.getCurrentUserId();
    if (!userId) return;

    this.presenceRef = ref(this.db, '.info/connected');
    this.userStatusRef = ref(this.db, `status/${userId}`);

    onValue(this.presenceRef, (snapshot) => {
      if (snapshot.val() === false) {
        return;
      }

      const presence: RealtimePresence = {
        userId,
        status: 'online',
        lastSeen: Date.now(),
        device: this.getDeviceInfo(),
      };

      onDisconnect(this.userStatusRef)
        .update({
          status: 'offline',
          lastSeen: Date.now(),
        })
        .then(() => {
          set(this.userStatusRef, presence);
        });
    });
  }

  private getDeviceInfo() {
    // Implementar detección de dispositivo
    return {
      type: 'web',
      platform: navigator.platform,
      version: navigator.userAgent,
    };
  }

  async createRoom(room: Omit<RealtimeRoom, 'id' | 'createdAt' | 'updatedAt'>): Promise<RealtimeRoom> {
    try {
      const timestamp = Date.now();
      const newRoom: Omit<RealtimeRoom, 'id'> = {
        ...room,
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      const roomRef = push(ref(this.db, 'rooms'));
      await set(roomRef, newRoom);

      return { ...newRoom, id: roomRef.key! };
    } catch (error: any) {
      throw new Error(`Error al crear sala: ${error.message}`);
    }
  }

  async sendMessage(roomId: string, message: Omit<RealtimeMessage, 'id' | 'createdAt' | 'updatedAt'>): Promise<RealtimeMessage> {
    try {
      const timestamp = Date.now();
      const newMessage: Omit<RealtimeMessage, 'id'> = {
        ...message,
        status: 'sent',
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      const messageRef = push(ref(this.db, `messages/${roomId}`));
      await set(messageRef, newMessage);

      // Actualizar última actividad de la sala
      await update(ref(this.db, `rooms/${roomId}`), {
        lastMessage: {
          content: message.content,
          senderId: message.senderId,
          timestamp,
        },
        updatedAt: timestamp,
      });

      // Enviar notificación push si el receptor está offline
      const receiverStatus = await this.getUserStatus(message.receiverId);
      if (receiverStatus?.status === 'offline') {
        await notificationsService.sendPushNotification({
          userId: message.receiverId,
          title: 'Nuevo mensaje',
          body: message.content,
          data: {
            type: 'chat',
            roomId,
            messageId: messageRef.key!,
          },
        });
      }

      return { ...newMessage, id: messageRef.key! };
    } catch (error: any) {
      throw new Error(`Error al enviar mensaje: ${error.message}`);
    }
  }

  subscribeToMessages(roomId: string, callback: (messages: RealtimeMessage[]) => void): () => void {
    const messagesRef = query(
      ref(this.db, `messages/${roomId}`),
      orderByChild('createdAt'),
      limitToLast(50)
    );

    const unsubscribe = onValue(messagesRef, (snapshot) => {
      const messages: RealtimeMessage[] = [];
      snapshot.forEach((childSnapshot) => {
        messages.push({
          id: childSnapshot.key!,
          ...childSnapshot.val(),
        });
      });
      callback(messages);
    });

    this.messageListeners.set(roomId, unsubscribe);
    return unsubscribe;
  }

  unsubscribeFromMessages(roomId: string): void {
    const unsubscribe = this.messageListeners.get(roomId);
    if (unsubscribe) {
      unsubscribe();
      this.messageListeners.delete(roomId);
    }
  }

  async updateMessageStatus(roomId: string, messageId: string, status: RealtimeMessage['status']): Promise<void> {
    try {
      await update(ref(this.db, `messages/${roomId}/${messageId}`), {
        status,
        updatedAt: Date.now(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar estado del mensaje: ${error.message}`);
    }
  }

  async getUserStatus(userId: string): Promise<RealtimePresence | null> {
    try {
      const statusRef = ref(this.db, `status/${userId}`);
      const snapshot = await get(statusRef);

      if (!snapshot.exists()) return null;

      return snapshot.val() as RealtimePresence;
    } catch (error: any) {
      throw new Error(`Error al obtener estado del usuario: ${error.message}`);
    }
  }

  subscribeToUserStatus(userId: string, callback: (status: RealtimePresence) => void): () => void {
    const statusRef = ref(this.db, `status/${userId}`);

    const unsubscribe = onValue(statusRef, (snapshot) => {
      if (snapshot.exists()) {
        callback(snapshot.val() as RealtimePresence);
      }
    });

    this.presenceListeners.set(userId, unsubscribe);
    return unsubscribe;
  }

  unsubscribeFromUserStatus(userId: string): void {
    const unsubscribe = this.presenceListeners.get(userId);
    if (unsubscribe) {
      unsubscribe();
      this.presenceListeners.delete(userId);
    }
  }

  async getRoomParticipants(roomId: string): Promise<RealtimePresence[]> {
    try {
      const roomRef = ref(this.db, `rooms/${roomId}`);
      const roomSnapshot = await get(roomRef);

      if (!roomSnapshot.exists()) {
        throw new Error('Sala no encontrada');
      }

      const room = roomSnapshot.val() as RealtimeRoom;
      const statuses: RealtimePresence[] = [];

      for (const userId of room.participants) {
        const status = await this.getUserStatus(userId);
        if (status) {
          statuses.push(status);
        }
      }

      return statuses;
    } catch (error: any) {
      throw new Error(`Error al obtener participantes de la sala: ${error.message}`);
    }
  }

  async getUserRooms(userId: string): Promise<RealtimeRoom[]> {
    try {
      const roomsRef = query(
        ref(this.db, 'rooms'),
        orderByChild('participants'),
        equalTo(userId)
      );

      const snapshot = await get(roomsRef);
      const rooms: RealtimeRoom[] = [];

      snapshot.forEach((childSnapshot) => {
        rooms.push({
          id: childSnapshot.key!,
          ...childSnapshot.val(),
        });
      });

      return rooms;
    } catch (error: any) {
      throw new Error(`Error al obtener salas del usuario: ${error.message}`);
    }
  }

  async deleteRoom(roomId: string): Promise<void> {
    try {
      // Eliminar mensajes de la sala
      await remove(ref(this.db, `messages/${roomId}`));
      // Eliminar la sala
      await remove(ref(this.db, `rooms/${roomId}`));
    } catch (error: any) {
      throw new Error(`Error al eliminar sala: ${error.message}`);
    }
  }

  async clearMessages(roomId: string): Promise<void> {
    try {
      await remove(ref(this.db, `messages/${roomId}`));
    } catch (error: any) {
      throw new Error(`Error al limpiar mensajes: ${error.message}`);
    }
  }

  dispose() {
    // Limpiar todos los listeners al destruir el servicio
    this.messageListeners.forEach((unsubscribe) => unsubscribe());
    this.presenceListeners.forEach((unsubscribe) => unsubscribe());
    this.messageListeners.clear();
    this.presenceListeners.clear();

    if (this.presenceRef) {
      off(this.presenceRef);
    }
    if (this.userStatusRef) {
      off(this.userStatusRef);
    }
  }
}

export const realtimeService = RealtimeService.getInstance();