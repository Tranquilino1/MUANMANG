import { getFirestore, collection, addDoc, query, where, orderBy, getDocs, updateDoc, doc, increment } from 'firebase/firestore';

export interface AnalyticsEvent {
  id: string;
  name: string;
  category: string;
  timestamp: Date;
  userId?: string;
  properties?: Record<string, any>;
  deviceInfo?: {
    platform: string;
    os: string;
    browser?: string;
    screenSize?: string;
  };
}

export interface Metrics {
  id: string;
  name: string;
  value: number;
  period: 'daily' | 'weekly' | 'monthly' | 'yearly';
  category: string;
  timestamp: Date;
  metadata?: Record<string, any>;
}

export interface UserAnalytics {
  userId: string;
  sessions: {
    count: number;
    averageDuration: number;
    lastSession: Date;
  };
  engagement: {
    productViews: number;
    searches: number;
    favorites: number;
    purchases: number;
    messages: number;
    reviews: number;
  };
  preferences: {
    categories: Record<string, number>;
    priceRanges: Record<string, number>;
    searchTerms: string[];
  };
  lastUpdated: Date;
}

export class AnalyticsService {
  private db = getFirestore();
  private static instance: AnalyticsService;

  private constructor() {}

  static getInstance(): AnalyticsService {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  async trackEvent({
    name,
    category,
    userId,
    properties,
    deviceInfo,
  }: {
    name: string;
    category: string;
    userId?: string;
    properties?: Record<string, any>;
    deviceInfo?: AnalyticsEvent['deviceInfo'];
  }): Promise<void> {
    try {
      const event: Omit<AnalyticsEvent, 'id'> = {
        name,
        category,
        timestamp: new Date(),
        userId,
        properties,
        deviceInfo,
      };

      await addDoc(collection(this.db, 'analytics_events'), event);

      // Actualizar métricas agregadas si es necesario
      await this.updateAggregateMetrics(name, category);

      // Actualizar analíticas de usuario si hay userId
      if (userId) {
        await this.updateUserAnalytics(userId, name, properties);
      }
    } catch (error: any) {
      console.error('Error al registrar evento:', error);
    }
  }

  private async updateAggregateMetrics(eventName: string, category: string): Promise<void> {
    try {
      const now = new Date();
      const periods: Array<'daily' | 'weekly' | 'monthly' | 'yearly'> = [
        'daily',
        'weekly',
        'monthly',
        'yearly',
      ];

      const batch = writeBatch(this.db);

      for (const period of periods) {
        const metricId = this.getMetricId(eventName, period, now);
        const metricRef = doc(this.db, 'metrics', metricId);

        batch.set(
          metricRef,
          {
            name: eventName,
            category,
            period,
            value: increment(1),
            timestamp: now,
          },
          { merge: true }
        );
      }

      await batch.commit();
    } catch (error: any) {
      console.error('Error al actualizar métricas agregadas:', error);
    }
  }

  private async updateUserAnalytics(
    userId: string,
    eventName: string,
    properties?: Record<string, any>
  ): Promise<void> {
    try {
      const userAnalyticsRef = doc(this.db, 'user_analytics', userId);
      const updates: Partial<UserAnalytics> = {
        lastUpdated: new Date(),
      };

      // Actualizar métricas específicas según el tipo de evento
      switch (eventName) {
        case 'view_product':
          updates['engagement.productViews'] = increment(1);
          if (properties?.category) {
            updates[`preferences.categories.${properties.category}`] = increment(1);
          }
          if (properties?.price) {
            const priceRange = this.getPriceRange(properties.price);
            updates[`preferences.priceRanges.${priceRange}`] = increment(1);
          }
          break;

        case 'search':
          updates['engagement.searches'] = increment(1);
          if (properties?.query) {
            updates['preferences.searchTerms'] = arrayUnion(properties.query);
          }
          break;

        case 'add_favorite':
          updates['engagement.favorites'] = increment(1);
          break;

        case 'purchase':
          updates['engagement.purchases'] = increment(1);
          break;

        case 'send_message':
          updates['engagement.messages'] = increment(1);
          break;

        case 'write_review':
          updates['engagement.reviews'] = increment(1);
          break;

        case 'session_start':
          updates['sessions.count'] = increment(1);
          updates['sessions.lastSession'] = new Date();
          break;
      }

      await updateDoc(userAnalyticsRef, updates);
    } catch (error: any) {
      console.error('Error al actualizar analíticas de usuario:', error);
    }
  }

  private getMetricId(name: string, period: string, date: Date): string {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const week = this.getWeekNumber(date);
    const day = date.getDate();

    switch (period) {
      case 'yearly':
        return `${name}_${year}`;
      case 'monthly':
        return `${name}_${year}_${month}`;
      case 'weekly':
        return `${name}_${year}_w${week}`;
      case 'daily':
        return `${name}_${year}_${month}_${day}`;
      default:
        return `${name}_${date.getTime()}`;
    }
  }

  private getWeekNumber(date: Date): number {
    const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
    const dayNum = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - dayNum);
    const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    return Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  }

  private getPriceRange(price: number): string {
    if (price < 5000) return '0-5k';
    if (price < 10000) return '5k-10k';
    if (price < 50000) return '10k-50k';
    if (price < 100000) return '50k-100k';
    return '100k+';
  }

  async getMetrics({
    name,
    period,
    startDate,
    endDate,
  }: {
    name: string;
    period: Metrics['period'];
    startDate: Date;
    endDate: Date;
  }): Promise<Metrics[]> {
    try {
      const q = query(
        collection(this.db, 'metrics'),
        where('name', '==', name),
        where('period', '==', period),
        where('timestamp', '>=', startDate),
        where('timestamp', '<=', endDate),
        orderBy('timestamp', 'asc')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Metrics[];
    } catch (error: any) {
      console.error('Error al obtener métricas:', error);
      return [];
    }
  }

  async getUserAnalytics(userId: string): Promise<UserAnalytics | null> {
    try {
      const docRef = doc(this.db, 'user_analytics', userId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        return null;
      }

      return docSnap.data() as UserAnalytics;
    } catch (error: any) {
      console.error('Error al obtener analíticas de usuario:', error);
      return null;
    }
  }

  async getTopSearchTerms(limit: number = 10): Promise<{ term: string; count: number }[]> {
    try {
      const q = query(
        collection(this.db, 'search_terms'),
        orderBy('count', 'desc'),
        limit(limit)
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        term: doc.id,
        count: doc.data().count,
      }));
    } catch (error: any) {
      console.error('Error al obtener términos de búsqueda populares:', error);
      return [];
    }
  }

  async getMostViewedCategories(limit: number = 5): Promise<{ category: string; views: number }[]> {
    try {
      const q = query(
        collection(this.db, 'category_views'),
        orderBy('views', 'desc'),
        limit(limit)
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        category: doc.id,
        views: doc.data().views,
      }));
    } catch (error: any) {
      console.error('Error al obtener categorías más vistas:', error);
      return [];
    }
  }
}

export const analyticsService = AnalyticsService.getInstance();