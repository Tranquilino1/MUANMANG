import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject, listAll } from 'firebase/storage';
import { getFirestore, collection, addDoc, updateDoc, deleteDoc, doc } from 'firebase/firestore';

export interface FileMetadata {
  id: string;
  name: string;
  path: string;
  type: string;
  size: number;
  url: string;
  uploadedBy: string;
  category: 'product' | 'avatar' | 'chat' | 'document';
  tags?: string[];
  createdAt: Date;
  updatedAt: Date;
}

export class StorageService {
  private storage = getStorage();
  private db = getFirestore();
  private static instance: StorageService;

  private constructor() {}

  static getInstance(): StorageService {
    if (!StorageService.instance) {
      StorageService.instance = new StorageService();
    }
    return StorageService.instance;
  }

  async uploadFile({
    file,
    path,
    metadata,
  }: {
    file: Blob;
    path: string;
    metadata: {
      name: string;
      type: string;
      category: FileMetadata['category'];
      uploadedBy: string;
      tags?: string[];
    };
  }): Promise<FileMetadata> {
    try {
      // Validar el tipo de archivo
      if (!this.isValidFileType(metadata.type)) {
        throw new Error('Tipo de archivo no permitido');
      }

      // Validar el tamaño del archivo
      if (!this.isValidFileSize(file.size)) {
        throw new Error('El archivo excede el tamaño máximo permitido');
      }

      // Generar un nombre único para el archivo
      const uniquePath = `${path}/${Date.now()}_${metadata.name}`;
      const storageRef = ref(this.storage, uniquePath);

      // Subir el archivo
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);

      // Guardar los metadatos en Firestore
      const fileMetadata: Omit<FileMetadata, 'id'> = {
        name: metadata.name,
        path: uniquePath,
        type: metadata.type,
        size: file.size,
        url,
        uploadedBy: metadata.uploadedBy,
        category: metadata.category,
        tags: metadata.tags,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      const docRef = await addDoc(collection(this.db, 'files'), fileMetadata);
      return { ...fileMetadata, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al subir archivo: ${error.message}`);
    }
  }

  private isValidFileType(type: string): boolean {
    const allowedTypes = [
      'image/jpeg',
      'image/png',
      'image/gif',
      'image/webp',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'text/plain',
    ];
    return allowedTypes.includes(type);
  }

  private isValidFileSize(size: number): boolean {
    const maxSize = 10 * 1024 * 1024; // 10MB
    return size <= maxSize;
  }

  async deleteFile(fileId: string): Promise<void> {
    try {
      const fileRef = doc(this.db, 'files', fileId);
      const fileDoc = await getDoc(fileRef);

      if (!fileDoc.exists()) {
        throw new Error('Archivo no encontrado');
      }

      const fileData = fileDoc.data() as FileMetadata;
      const storageRef = ref(this.storage, fileData.path);

      // Eliminar el archivo del storage
      await deleteObject(storageRef);

      // Eliminar los metadatos de Firestore
      await deleteDoc(fileRef);
    } catch (error: any) {
      throw new Error(`Error al eliminar archivo: ${error.message}`);
    }
  }

  async getFileMetadata(fileId: string): Promise<FileMetadata> {
    try {
      const docRef = doc(this.db, 'files', fileId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Archivo no encontrado');
      }

      return { id: docSnap.id, ...docSnap.data() } as FileMetadata;
    } catch (error: any) {
      throw new Error(`Error al obtener metadatos del archivo: ${error.message}`);
    }
  }

  async updateFileMetadata(
    fileId: string,
    updates: Partial<Pick<FileMetadata, 'name' | 'tags'>>
  ): Promise<void> {
    try {
      const fileRef = doc(this.db, 'files', fileId);
      await updateDoc(fileRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar metadatos del archivo: ${error.message}`);
    }
  }

  async listFiles({
    category,
    uploadedBy,
    tags,
  }: {
    category?: FileMetadata['category'];
    uploadedBy?: string;
    tags?: string[];
  } = {}): Promise<FileMetadata[]> {
    try {
      let q = query(collection(this.db, 'files'));

      if (category) {
        q = query(q, where('category', '==', category));
      }

      if (uploadedBy) {
        q = query(q, where('uploadedBy', '==', uploadedBy));
      }

      if (tags && tags.length > 0) {
        q = query(q, where('tags', 'array-contains-any', tags));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as FileMetadata[];
    } catch (error: any) {
      throw new Error(`Error al listar archivos: ${error.message}`);
    }
  }

  async getFileUrl(path: string): Promise<string> {
    try {
      const storageRef = ref(this.storage, path);
      return await getDownloadURL(storageRef);
    } catch (error: any) {
      throw new Error(`Error al obtener URL del archivo: ${error.message}`);
    }
  }

  async copyFile(sourceId: string, destinationPath: string): Promise<FileMetadata> {
    try {
      const sourceMetadata = await this.getFileMetadata(sourceId);
      const sourceUrl = await this.getFileUrl(sourceMetadata.path);

      // Descargar el archivo original
      const response = await fetch(sourceUrl);
      const blob = await response.blob();

      // Subir la copia
      return await this.uploadFile({
        file: blob,
        path: destinationPath,
        metadata: {
          name: sourceMetadata.name,
          type: sourceMetadata.type,
          category: sourceMetadata.category,
          uploadedBy: sourceMetadata.uploadedBy,
          tags: sourceMetadata.tags,
        },
      });
    } catch (error: any) {
      throw new Error(`Error al copiar archivo: ${error.message}`);
    }
  }

  async moveFile(fileId: string, newPath: string): Promise<void> {
    try {
      // Copiar el archivo a la nueva ubicación
      const newFile = await this.copyFile(fileId, newPath);

      // Eliminar el archivo original
      await this.deleteFile(fileId);

      // Actualizar los metadatos con la nueva ubicación
      await this.updateFileMetadata(newFile.id, {
        name: newFile.name,
      });
    } catch (error: any) {
      throw new Error(`Error al mover archivo: ${error.message}`);
    }
  }

  async cleanupUnusedFiles(): Promise<void> {
    try {
      const unusedFiles = await this.findUnusedFiles();
      const batch = writeBatch(this.db);

      for (const file of unusedFiles) {
        try {
          const storageRef = ref(this.storage, file.path);
          await deleteObject(storageRef);
          batch.delete(doc(this.db, 'files', file.id));
        } catch (error) {
          console.error(`Error al eliminar archivo ${file.id}:`, error);
        }
      }

      await batch.commit();
    } catch (error: any) {
      throw new Error(`Error al limpiar archivos no utilizados: ${error.message}`);
    }
  }

  private async findUnusedFiles(): Promise<FileMetadata[]> {
    // Implementar lógica para encontrar archivos no utilizados
    // Por ejemplo, archivos más antiguos que cierta fecha o que no están referenciados en ningún lugar
    return [];
  }
}

export const storageService = StorageService.getInstance();