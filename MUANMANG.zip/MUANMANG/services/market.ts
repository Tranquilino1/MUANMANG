import { getFirestore, collection, doc, addDoc, updateDoc, deleteDoc, query, where, getDocs } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: string;
  category: string;
  images: string[];
  seller: {
    id: string;
    name: string;
    avatar: string;
    rating: number;
  };
  stock: number;
  tags: string[];
  status: 'active' | 'inactive' | 'sold';
  createdAt: Date;
  updatedAt: Date;
  stats: {
    views: number;
    likes: number;
    sales: number;
  };
  shipping: {
    available: boolean;
    locations: string[];
    cost: number;
  };
}

export class MarketService {
  private db = getFirestore();
  private storage = getStorage();

  async createProduct(product: Omit<Product, 'id' | 'createdAt' | 'updatedAt' | 'stats'>): Promise<Product> {
    try {
      const productData = {
        ...product,
        createdAt: new Date(),
        updatedAt: new Date(),
        stats: {
          views: 0,
          likes: 0,
          sales: 0,
        },
        currency: 'XAF', // Moneda predeterminada para Guinea Ecuatorial
      };

      const docRef = await addDoc(collection(this.db, 'products'), productData);
      return { ...productData, id: docRef.id } as Product;
    } catch (error: any) {
      throw new Error(`Error al crear producto: ${error.message}`);
    }
  }

  async uploadProductImage(file: Blob, productId: string): Promise<string> {
    try {
      const storageRef = ref(this.storage, `products/${productId}/${Date.now()}`);
      await uploadBytes(storageRef, file);
      return getDownloadURL(storageRef);
    } catch (error: any) {
      throw new Error(`Error al subir imagen: ${error.message}`);
    }
  }

  async updateProduct(productId: string, updates: Partial<Product>): Promise<void> {
    try {
      const productRef = doc(this.db, 'products', productId);
      await updateDoc(productRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar producto: ${error.message}`);
    }
  }

  async deleteProduct(productId: string): Promise<void> {
    try {
      await deleteDoc(doc(this.db, 'products', productId));
    } catch (error: any) {
      throw new Error(`Error al eliminar producto: ${error.message}`);
    }
  }

  async searchProducts({
    category,
    query: searchQuery,
    minPrice,
    maxPrice,
    seller,
    tags,
  }: {
    category?: string;
    query?: string;
    minPrice?: number;
    maxPrice?: number;
    seller?: string;
    tags?: string[];
  }): Promise<Product[]> {
    try {
      let q = query(collection(this.db, 'products'));

      if (category) {
        q = query(q, where('category', '==', category));
      }

      if (seller) {
        q = query(q, where('seller.id', '==', seller));
      }

      if (minPrice !== undefined) {
        q = query(q, where('price', '>=', minPrice));
      }

      if (maxPrice !== undefined) {
        q = query(q, where('price', '<=', maxPrice));
      }

      if (tags && tags.length > 0) {
        q = query(q, where('tags', 'array-contains-any', tags));
      }

      const snapshot = await getDocs(q);
      const products = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Product[];

      // Filtrar por búsqueda de texto si existe
      if (searchQuery) {
        const searchLower = searchQuery.toLowerCase();
        return products.filter(
          (product) =>
            product.name.toLowerCase().includes(searchLower) ||
            product.description.toLowerCase().includes(searchLower)
        );
      }

      return products;
    } catch (error: any) {
      throw new Error(`Error al buscar productos: ${error.message}`);
    }
  }

  async incrementProductStats(productId: string, stat: 'views' | 'likes' | 'sales'): Promise<void> {
    try {
      const productRef = doc(this.db, 'products', productId);
      await updateDoc(productRef, {
        [`stats.${stat}`]: increment(1),
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar estadísticas: ${error.message}`);
    }
  }

  async getPopularProducts(limit: number = 10): Promise<Product[]> {
    try {
      const q = query(
        collection(this.db, 'products'),
        where('status', '==', 'active'),
        orderBy('stats.views', 'desc'),
        limit(limit)
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Product[];
    } catch (error: any) {
      throw new Error(`Error al obtener productos populares: ${error.message}`);
    }
  }

  async getSellerProducts(sellerId: string): Promise<Product[]> {
    try {
      const q = query(
        collection(this.db, 'products'),
        where('seller.id', '==', sellerId),
        where('status', '==', 'active')
      );

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Product[];
    } catch (error: any) {
      throw new Error(`Error al obtener productos del vendedor: ${error.message}`);
    }
  }
}

export const marketService = new MarketService();