import { getFirestore, collection, doc, getDoc, setDoc, deleteDoc, query, where, getDocs, orderBy, limit } from 'firebase/firestore';
import { profileService } from './profile';

export interface Address {
  id: string;
  userId: string;
  type: 'shipping' | 'billing';
  isDefault: boolean;
  name: string;
  street: string;
  number: string;
  apartment?: string;
  neighborhood: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
  phone: string;
  instructions?: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
  validatedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface AddressValidation {
  id: string;
  addressId: string;
  status: 'valid' | 'invalid' | 'warning';
  issues?: Array<{
    code: string;
    message: string;
    severity: 'error' | 'warning';
  }>;
  suggestions?: Array<{
    field: keyof Address;
    value: string;
    confidence: number;
  }>;
  validatedAt: Date;
}

export class AddressService {
  private db = getFirestore();
  private static instance: AddressService;

  private constructor() {}

  static getInstance(): AddressService {
    if (!AddressService.instance) {
      AddressService.instance = new AddressService();
    }
    return AddressService.instance;
  }

  async createAddress(address: Omit<Address, 'id' | 'createdAt' | 'updatedAt'>): Promise<Address> {
    try {
      const newAddress: Omit<Address, 'id'> = {
        ...address,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Si es dirección por defecto, actualizar otras direcciones del mismo tipo
      if (newAddress.isDefault) {
        await this.updateDefaultStatus(address.userId, address.type, false);
      }

      const docRef = await addDoc(collection(this.db, 'addresses'), newAddress);
      return { ...newAddress, id: docRef.id };
    } catch (error: any) {
      throw new Error(`Error al crear dirección: ${error.message}`);
    }
  }

  async getAddress(addressId: string): Promise<Address> {
    try {
      const docRef = doc(this.db, 'addresses', addressId);
      const docSnap = await getDoc(docRef);

      if (!docSnap.exists()) {
        throw new Error('Dirección no encontrada');
      }

      return { id: docSnap.id, ...docSnap.data() } as Address;
    } catch (error: any) {
      throw new Error(`Error al obtener dirección: ${error.message}`);
    }
  }

  async updateAddress(
    addressId: string,
    updates: Partial<Omit<Address, 'id' | 'userId' | 'createdAt' | 'updatedAt'>>
  ): Promise<void> {
    try {
      const addressRef = doc(this.db, 'addresses', addressId);
      const currentAddress = await this.getAddress(addressId);

      // Si se está actualizando el estado por defecto
      if (updates.isDefault && updates.isDefault !== currentAddress.isDefault) {
        await this.updateDefaultStatus(currentAddress.userId, currentAddress.type, false);
      }

      await updateDoc(addressRef, {
        ...updates,
        updatedAt: new Date(),
      });
    } catch (error: any) {
      throw new Error(`Error al actualizar dirección: ${error.message}`);
    }
  }

  async deleteAddress(addressId: string): Promise<void> {
    try {
      const address = await this.getAddress(addressId);

      // Si es dirección por defecto, establecer otra dirección como predeterminada
      if (address.isDefault) {
        const alternativeAddress = await this.getFirstNonDefaultAddress(address.userId, address.type);
        if (alternativeAddress) {
          await this.updateAddress(alternativeAddress.id, { isDefault: true });
        }
      }

      await deleteDoc(doc(this.db, 'addresses', addressId));
    } catch (error: any) {
      throw new Error(`Error al eliminar dirección: ${error.message}`);
    }
  }

  async getUserAddresses(userId: string, type?: Address['type']): Promise<Address[]> {
    try {
      let q = query(
        collection(this.db, 'addresses'),
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      );

      if (type) {
        q = query(q, where('type', '==', type));
      }

      const snapshot = await getDocs(q);
      return snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Address[];
    } catch (error: any) {
      throw new Error(`Error al obtener direcciones del usuario: ${error.message}`);
    }
  }

  async getDefaultAddress(userId: string, type: Address['type']): Promise<Address | null> {
    try {
      const q = query(
        collection(this.db, 'addresses'),
        where('userId', '==', userId),
        where('type', '==', type),
        where('isDefault', '==', true),
        limit(1)
      );

      const snapshot = await getDocs(q);
      if (snapshot.empty) return null;

      const doc = snapshot.docs[0];
      return { id: doc.id, ...doc.data() } as Address;
    } catch (error: any) {
      throw new Error(`Error al obtener dirección por defecto: ${error.message}`);
    }
  }

  private async updateDefaultStatus(
    userId: string,
    type: Address['type'],
    isDefault: boolean
  ): Promise<void> {
    try {
      const q = query(
        collection(this.db, 'addresses'),
        where('userId', '==', userId),
        where('type', '==', type),
        where('isDefault', '==', !isDefault)
      );

      const snapshot = await getDocs(q);
      const batch = writeBatch(this.db);

      snapshot.docs.forEach((doc) => {
        batch.update(doc.ref, { isDefault, updatedAt: new Date() });
      });

      await batch.commit();
    } catch (error: any) {
      throw new Error(`Error al actualizar estado por defecto: ${error.message}`);
    }
  }

  private async getFirstNonDefaultAddress(userId: string, type: Address['type']): Promise<Address | null> {
    try {
      const q = query(
        collection(this.db, 'addresses'),
        where('userId', '==', userId),
        where('type', '==', type),
        where('isDefault', '==', false),
        limit(1)
      );

      const snapshot = await getDocs(q);
      if (snapshot.empty) return null;

      const doc = snapshot.docs[0];
      return { id: doc.id, ...doc.data() } as Address;
    } catch (error: any) {
      throw new Error(`Error al obtener dirección alternativa: ${error.message}`);
    }
  }

  async validateAddress(address: Address): Promise<AddressValidation> {
    try {
      // Aquí se implementaría la lógica de validación de direcciones
      // Se podría utilizar un servicio externo de validación de direcciones
      // Por ahora, implementamos una validación básica

      const issues: AddressValidation['issues'] = [];

      // Validaciones básicas
      if (!address.postalCode.match(/^\d{5}(-\d{4})?$/)) {
        issues.push({
          code: 'INVALID_POSTAL_CODE',
          message: 'El código postal no tiene un formato válido',
          severity: 'error',
        });
      }

      if (!address.phone.match(/^\+?[1-9]\d{1,14}$/)) {
        issues.push({
          code: 'INVALID_PHONE',
          message: 'El número de teléfono no tiene un formato válido',
          severity: 'error',
        });
      }

      const validation: AddressValidation = {
        id: generateId(), // Función para generar ID único
        addressId: address.id,
        status: issues.some((i) => i.severity === 'error') ? 'invalid' : 'valid',
        issues: issues.length > 0 ? issues : undefined,
        validatedAt: new Date(),
      };

      // Guardar el resultado de la validación
      await setDoc(doc(this.db, 'addressValidations', validation.id), validation);

      // Actualizar la fecha de validación en la dirección
      await updateDoc(doc(this.db, 'addresses', address.id), {
        validatedAt: validation.validatedAt,
        updatedAt: new Date(),
      });

      return validation;
    } catch (error: any) {
      throw new Error(`Error al validar dirección: ${error.message}`);
    }
  }

  async getAddressValidation(addressId: string): Promise<AddressValidation | null> {
    try {
      const q = query(
        collection(this.db, 'addressValidations'),
        where('addressId', '==', addressId),
        orderBy('validatedAt', 'desc'),
        limit(1)
      );

      const snapshot = await getDocs(q);
      if (snapshot.empty) return null;

      return { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as AddressValidation;
    } catch (error: any) {
      throw new Error(`Error al obtener validación de dirección: ${error.message}`);
    }
  }
}

export const addressService = AddressService.getInstance();