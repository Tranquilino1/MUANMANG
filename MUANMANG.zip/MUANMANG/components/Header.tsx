import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, TextInput, Modal, Animated } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Bell, Search, Heart, MessageCircle, Sun, Moon, Menu, X } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface HeaderProps {
  title?: string;
  showSearch?: boolean;
  showNotifications?: boolean;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  onSearch?: (query: string) => void;
}

export default function Header({ 
  title = 'Muan Mang HUB', 
  showSearch = true, 
  showNotifications = true,
  isDarkMode = false,
  onToggleDarkMode,
  onSearch
}: HeaderProps) {
  const [searchVisible, setSearchVisible] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [menuVisible, setMenuVisible] = useState(false);
  const [notificationCount] = useState(3);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    onSearch?.(query);
  };

  return (
    <>
      <LinearGradient
        colors={isDarkMode ? ['#2C3E50', '#34495E'] : ['#009E49', '#0072C6']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.gradient}
      >
        <SafeAreaView edges={['top']}>
          <View style={styles.container}>
            <View style={styles.leftSection}>
              <TouchableOpacity 
                style={styles.menuButton}
                onPress={() => setMenuVisible(true)}
              >
                <Menu size={24} color="white" strokeWidth={2} />
              </TouchableOpacity>
              <View style={styles.titleContainer}>
                <Text style={styles.title}>{title}</Text>
                <Text style={styles.subtitle}>Guinea Ecuatorial 🇬🇶</Text>
              </View>
            </View>
            
            <View style={styles.actions}>
              {showSearch && (
                <TouchableOpacity 
                  style={styles.actionButton}
                  onPress={() => setSearchVisible(true)}
                >
                  <Search size={22} color="white" strokeWidth={2} />
                </TouchableOpacity>
              )}
              
              <TouchableOpacity style={styles.actionButton}>
                <Heart size={22} color="white" strokeWidth={2} />
              </TouchableOpacity>
              
              {showNotifications && (
                <TouchableOpacity style={[styles.actionButton, styles.notificationButton]}>
                  <Bell size={22} color="white" strokeWidth={2} />
                  {notificationCount > 0 && (
                    <View style={styles.notificationBadge}>
                      <Text style={styles.notificationText}>{notificationCount}</Text>
                    </View>
                  )}
                </TouchableOpacity>
              )}
              
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={onToggleDarkMode}
              >
                {isDarkMode ? (
                  <Sun size={22} color="white" strokeWidth={2} />
                ) : (
                  <Moon size={22} color="white" strokeWidth={2} />
                )}
              </TouchableOpacity>
            </View>
          </View>
        </SafeAreaView>
      </LinearGradient>

      {/* Search Modal */}
      <Modal
        visible={searchVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setSearchVisible(false)}
      >
        <View style={styles.searchModal}>
          <LinearGradient
            colors={isDarkMode ? ['#2C3E50', '#34495E'] : ['#009E49', '#0072C6']}
            style={styles.searchHeader}
          >
            <SafeAreaView edges={['top']}>
              <View style={styles.searchContainer}>
                <View style={styles.searchInputContainer}>
                  <Search size={20} color="#999" />
                  <TextInput
                    style={styles.searchInput}
                    placeholder="Buscar en Muan Mang HUB..."
                    placeholderTextColor="#999"
                    value={searchQuery}
                    onChangeText={handleSearch}
                    autoFocus
                  />
                </View>
                <TouchableOpacity 
                  style={styles.closeButton}
                  onPress={() => setSearchVisible(false)}
                >
                  <X size={24} color="white" strokeWidth={2} />
                </TouchableOpacity>
              </View>
            </SafeAreaView>
          </LinearGradient>
          
          <View style={[styles.searchResults, { backgroundColor: isDarkMode ? '#1a1a1a' : 'white' }]}>
            <Text style={[styles.searchResultsTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
              Búsquedas recientes
            </Text>
            {['#CulturaGQ', '#MalaboCulture', '#AfroBeats', '#GuineaEcuatorial'].map((tag, index) => (
              <TouchableOpacity key={index} style={styles.searchResultItem}>
                <Search size={16} color="#999" />
                <Text style={[styles.searchResultText, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                  {tag}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>

      {/* Menu Modal */}
      <Modal
        visible={menuVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setMenuVisible(false)}
      >
        <View style={styles.menuModal}>
          <TouchableOpacity 
            style={styles.menuOverlay}
            onPress={() => setMenuVisible(false)}
          />
          <View style={[styles.menuContent, { backgroundColor: isDarkMode ? '#2C3E50' : 'white' }]}>
            <View style={styles.menuHeader}>
              <Text style={[styles.menuTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                Menú Principal
              </Text>
              <TouchableOpacity onPress={() => setMenuVisible(false)}>
                <X size={24} color={isDarkMode ? 'white' : '#2C3E50'} />
              </TouchableOpacity>
            </View>
            
            {[
              { title: 'Configuración', icon: '⚙️' },
              { title: 'Ayuda', icon: '❓' },
              { title: 'Acerca de', icon: 'ℹ️' },
              { title: 'Términos', icon: '📋' }
            ].map((item, index) => (
              <TouchableOpacity key={index} style={styles.menuItem}>
                <Text style={styles.menuIcon}>{item.icon}</Text>
                <Text style={[styles.menuItemText, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                  {item.title}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  gradient: {
    paddingBottom: 15,
  },
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 10,
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuButton: {
    padding: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
    marginRight: 15,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 22,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  subtitle: {
    fontSize: 11,
    fontFamily: 'Inter-Regular',
    color: 'rgba(255, 255, 255, 0.9)',
    marginTop: 2,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    padding: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
  },
  notificationButton: {
    position: 'relative',
  },
  notificationBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    backgroundColor: '#E74C3C',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'white',
  },
  notificationText: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  searchModal: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  searchHeader: {
    paddingBottom: 15,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 10,
    gap: 15,
  },
  searchInputContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 25,
    paddingHorizontal: 15,
    paddingVertical: 12,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Inter-Regular',
    color: '#2C3E50',
  },
  closeButton: {
    padding: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
  },
  searchResults: {
    flex: 1,
    padding: 20,
  },
  searchResultsTitle: {
    fontSize: 18,
    fontFamily: 'Ubuntu-Bold',
    marginBottom: 15,
  },
  searchResultItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    gap: 12,
  },
  searchResultText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
  menuModal: {
    flex: 1,
    justifyContent: 'flex-end',
  },
  menuOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  menuContent: {
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    padding: 20,
    maxHeight: '50%',
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  menuTitle: {
    fontSize: 20,
    fontFamily: 'Ubuntu-Bold',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    gap: 15,
  },
  menuIcon: {
    fontSize: 20,
  },
  menuItemText: {
    fontSize: 16,
    fontFamily: 'Inter-Regular',
  },
});