import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Plus, Play } from 'lucide-react-native';

interface StoryCardProps {
  user?: {
    name: string;
    avatar: string;
    isLive?: boolean;
  };
  isAddStory?: boolean;
  isDarkMode?: boolean;
}

export default function StoryCard({ user, isAddStory = false, isDarkMode = false }: StoryCardProps) {
  if (isAddStory) {
    return (
      <TouchableOpacity style={styles.addStoryContainer}>
        <LinearGradient
          colors={['#009E49', '#0072C6']}
          style={styles.addStoryGradient}
        >
          <Plus size={24} color="white" strokeWidth={3} />
        </LinearGradient>
        <Text style={[styles.addStoryText, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
          Tu Historia
        </Text>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity style={styles.container}>
      <LinearGradient
        colors={user?.isLive ? ['#E74C3C', '#C0392B'] : ['#009E49', '#0072C6', '#F1C40F']}
        style={styles.storyBorder}
      >
        <View style={styles.imageContainer}>
          <Image
            source={{ uri: user?.avatar }}
            style={styles.avatar}
          />
          {user?.isLive && (
            <View style={styles.liveIndicator}>
              <Play size={8} color="white" fill="white" />
              <Text style={styles.liveText}>EN VIVO</Text>
            </View>
          )}
        </View>
      </LinearGradient>
      <Text style={[styles.username, { color: isDarkMode ? 'white' : '#2C3E50' }]} numberOfLines={1}>
        {user?.name}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginRight: 15,
    width: 75,
  },
  addStoryContainer: {
    alignItems: 'center',
    marginRight: 15,
    width: 75,
  },
  storyBorder: {
    width: 72,
    height: 72,
    borderRadius: 36,
    padding: 3,
    marginBottom: 8,
  },
  imageContainer: {
    width: 66,
    height: 66,
    borderRadius: 33,
    backgroundColor: '#000',
    position: 'relative',
    overflow: 'hidden',
  },
  avatar: {
    width: '100%',
    height: '100%',
    borderRadius: 33,
  },
  addStoryGradient: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  liveIndicator: {
    position: 'absolute',
    bottom: 2,
    left: 2,
    right: 2,
    backgroundColor: '#E74C3C',
    borderRadius: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 2,
    paddingHorizontal: 4,
    gap: 2,
  },
  liveText: {
    fontSize: 8,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  username: {
    fontSize: 11,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
  },
  addStoryText: {
    fontSize: 11,
    fontFamily: 'Inter-SemiBold',
    textAlign: 'center',
  },
});