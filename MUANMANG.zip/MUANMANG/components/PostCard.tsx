import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, Animated } from 'react-native';
import { Heart, MessageCircle, Share, Bookmark, MoveHorizontal as MoreHorizontal, MapPin, Music } from 'lucide-react-native';

interface PostCardProps {
  post: {
    id: string;
    user: {
      name: string;
      avatar: string;
      verified?: boolean;
      location?: string;
    };
    content: string;
    image?: string;
    likes: number;
    comments: number;
    timeAgo: string;
    tags?: string[];
    music?: string;
    category?: string;
  };
  isDarkMode?: boolean;
}

export default function PostCard({ post, isDarkMode = false }: PostCardProps) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likeAnimation] = useState(new Animated.Value(1));

  const handleLike = () => {
    setLiked(!liked);
    Animated.sequence([
      Animated.timing(likeAnimation, {
        toValue: 1.3,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(likeAnimation, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const getCategoryColor = (category?: string) => {
    switch (category) {
      case 'Arte': return '#9B59B6';
      case 'Cultura': return '#009E49';
      case 'Música': return '#E74C3C';
      case 'Gastronomía': return '#F39C12';
      case 'Eventos': return '#0072C6';
      default: return '#34495E';
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#2C3E50' : 'white' }]}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.userInfo}>
          <Image source={{ uri: post.user.avatar }} style={styles.avatar} />
          <View style={styles.userDetails}>
            <View style={styles.userNameRow}>
              <Text style={[styles.username, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                {post.user.name}
              </Text>
              {post.user.verified && <Text style={styles.verifiedBadge}>✓</Text>}
              {post.category && (
                <View style={[styles.categoryBadge, { backgroundColor: getCategoryColor(post.category) }]}>
                  <Text style={styles.categoryText}>{post.category}</Text>
                </View>
              )}
            </View>
            <View style={styles.metaInfo}>
              {post.user.location && (
                <View style={styles.locationInfo}>
                  <MapPin size={12} color="#999" />
                  <Text style={styles.locationText}>{post.user.location}</Text>
                </View>
              )}
              <Text style={styles.timeAgo}>{post.timeAgo}</Text>
            </View>
          </View>
        </View>
        <TouchableOpacity style={styles.moreButton}>
          <MoreHorizontal size={20} color="#999" />
        </TouchableOpacity>
      </View>

      {/* Content */}
      <Text style={[styles.content, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
        {post.content}
      </Text>
      
      {/* Tags */}
      {post.tags && (
        <View style={styles.tagsContainer}>
          {post.tags.map((tag, index) => (
            <TouchableOpacity key={index} style={styles.tag}>
              <Text style={styles.tagText}>#{tag}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* Music Info */}
      {post.music && (
        <View style={styles.musicInfo}>
          <Music size={16} color="#009E49" />
          <Text style={[styles.musicText, { color: isDarkMode ? '#BDC3C7' : '#7F8C8D' }]}>
            {post.music}
          </Text>
        </View>
      )}

      {/* Image */}
      {post.image && (
        <TouchableOpacity style={styles.imageContainer}>
          <Image source={{ uri: post.image }} style={styles.postImage} />
          <View style={styles.imageOverlay}>
            <TouchableOpacity style={styles.fullscreenButton}>
              <Text style={styles.fullscreenText}>⛶</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      )}

      {/* Actions */}
      <View style={styles.actions}>
        <View style={styles.leftActions}>
          <TouchableOpacity 
            style={styles.actionButton}
            onPress={handleLike}
          >
            <Animated.View style={{ transform: [{ scale: likeAnimation }] }}>
              <Heart 
                size={24} 
                color={liked ? '#E74C3C' : '#7F8C8D'} 
                fill={liked ? '#E74C3C' : 'transparent'}
                strokeWidth={2}
              />
            </Animated.View>
            <Text style={[styles.actionText, liked && styles.activeActionText]}>
              {post.likes + (liked ? 1 : 0)}
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <MessageCircle size={24} color="#7F8C8D" strokeWidth={2} />
            <Text style={styles.actionText}>{post.comments}</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <Share size={24} color="#7F8C8D" strokeWidth={2} />
          </TouchableOpacity>
        </View>
        
        <TouchableOpacity onPress={() => setSaved(!saved)}>
          <Bookmark 
            size={24} 
            color={saved ? '#F1C40F' : '#7F8C8D'} 
            fill={saved ? '#F1C40F' : 'transparent'}
            strokeWidth={2}
          />
        </TouchableOpacity>
      </View>

      {/* Likes Info */}
      <TouchableOpacity style={styles.likesInfo}>
        <Text style={[styles.likesText, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
          Les gusta a <Text style={styles.boldText}>kwame_artist</Text> y{' '}
          <Text style={styles.boldText}>{post.likes + (liked ? 1 : 0)} personas más</Text>
        </Text>
      </TouchableOpacity>

      {/* Comments Preview */}
      <TouchableOpacity style={styles.commentsPreview}>
        <Text style={[styles.commentsText, { color: isDarkMode ? '#BDC3C7' : '#7F8C8D' }]}>
          Ver los {post.comments} comentarios
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    borderRadius: 15,
    padding: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatar: {
    width: 45,
    height: 45,
    borderRadius: 22.5,
    marginRight: 12,
    borderWidth: 2,
    borderColor: '#009E49',
  },
  userDetails: {
    flex: 1,
  },
  userNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  username: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  verifiedBadge: {
    fontSize: 14,
    color: '#0072C6',
  },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 10,
  },
  categoryText: {
    fontSize: 10,
    fontFamily: 'Inter-Bold',
    color: 'white',
  },
  metaInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 2,
  },
  locationInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationText: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#999',
  },
  timeAgo: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#999',
  },
  moreButton: {
    padding: 5,
  },
  content: {
    fontSize: 15,
    fontFamily: 'Inter-Regular',
    lineHeight: 22,
    marginBottom: 12,
  },
  tagsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  tag: {
    backgroundColor: 'rgba(0, 158, 73, 0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#009E49',
  },
  tagText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#009E49',
  },
  musicInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    padding: 8,
    backgroundColor: 'rgba(0, 158, 73, 0.05)',
    borderRadius: 10,
  },
  musicText: {
    fontSize: 13,
    fontFamily: 'Inter-Regular',
    fontStyle: 'italic',
  },
  imageContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  postImage: {
    width: '100%',
    height: 300,
    borderRadius: 12,
  },
  imageOverlay: {
    position: 'absolute',
    top: 10,
    right: 10,
  },
  fullscreenButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    padding: 8,
    borderRadius: 20,
  },
  fullscreenText: {
    color: 'white',
    fontSize: 16,
  },
  actions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  leftActions: {
    flexDirection: 'row',
    gap: 20,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
    color: '#7F8C8D',
  },
  activeActionText: {
    color: '#E74C3C',
  },
  likesInfo: {
    marginBottom: 8,
  },
  likesText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  boldText: {
    fontFamily: 'Inter-SemiBold',
  },
  commentsPreview: {
    marginBottom: 5,
  },
  commentsText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
});