import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, ScrollView } from 'react-native';
import { Filter, X, MapPin, Calendar, TrendingUp, Users } from 'lucide-react-native';

interface FilterSidebarProps {
  visible: boolean;
  onClose: () => void;
  onFiltersApply?: (filters: any) => void;
  isDarkMode?: boolean;
}

export default function FilterSidebar({ visible, onClose, onFiltersApply, isDarkMode = false }: FilterSidebarProps) {
  const [selectedLocation, setSelectedLocation] = useState('');
  const [selectedTimeRange, setSelectedTimeRange] = useState('');
  const [selectedPopularity, setSelectedPopularity] = useState('');

  const locations = [
    'Malabo', 'Bata', 'Ebebiyín', 'Aconibe', 'Añisoc', 'Luba', 'Evinayong'
  ];

  const timeRanges = [
    { id: 'today', name: 'Hoy' },
    { id: 'week', name: 'Esta semana' },
    { id: 'month', name: 'Este mes' },
    { id: 'year', name: 'Este año' }
  ];

  const popularityOptions = [
    { id: 'trending', name: 'Tendencia', icon: TrendingUp },
    { id: 'most_liked', name: 'Más gustados', icon: '❤️' },
    { id: 'most_commented', name: 'Más comentados', icon: '💬' },
    { id: 'most_shared', name: 'Más compartidos', icon: '🔄' }
  ];

  const handleApplyFilters = () => {
    const filters = {
      location: selectedLocation,
      timeRange: selectedTimeRange,
      popularity: selectedPopularity
    };
    onFiltersApply?.(filters);
    onClose();
  };

  const clearFilters = () => {
    setSelectedLocation('');
    setSelectedTimeRange('');
    setSelectedPopularity('');
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.modalContainer}>
        <TouchableOpacity style={styles.overlay} onPress={onClose} />
        
        <View style={[styles.sidebar, { backgroundColor: isDarkMode ? '#2C3E50' : 'white' }]}>
          <View style={styles.header}>
            <View style={styles.headerTitle}>
              <Filter size={24} color={isDarkMode ? 'white' : '#2C3E50'} />
              <Text style={[styles.title, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                Filtros
              </Text>
            </View>
            <TouchableOpacity onPress={onClose}>
              <X size={24} color={isDarkMode ? 'white' : '#2C3E50'} />
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
            {/* Location Filter */}
            <View style={styles.filterSection}>
              <View style={styles.sectionHeader}>
                <MapPin size={20} color="#009E49" />
                <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                  Ubicación
                </Text>
              </View>
              <View style={styles.optionsGrid}>
                {locations.map((location) => (
                  <TouchableOpacity
                    key={location}
                    style={[
                      styles.optionButton,
                      selectedLocation === location && styles.selectedOption,
                      { backgroundColor: isDarkMode ? '#34495E' : '#F8F9FA' }
                    ]}
                    onPress={() => setSelectedLocation(selectedLocation === location ? '' : location)}
                  >
                    <Text style={[
                      styles.optionText,
                      selectedLocation === location && styles.selectedOptionText,
                      { color: isDarkMode ? 'white' : '#2C3E50' }
                    ]}>
                      {location}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Time Range Filter */}
            <View style={styles.filterSection}>
              <View style={styles.sectionHeader}>
                <Calendar size={20} color="#0072C6" />
                <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                  Fecha
                </Text>
              </View>
              <View style={styles.optionsList}>
                {timeRanges.map((range) => (
                  <TouchableOpacity
                    key={range.id}
                    style={[
                      styles.listOption,
                      selectedTimeRange === range.id && styles.selectedListOption
                    ]}
                    onPress={() => setSelectedTimeRange(selectedTimeRange === range.id ? '' : range.id)}
                  >
                    <Text style={[
                      styles.listOptionText,
                      selectedTimeRange === range.id && styles.selectedListOptionText,
                      { color: isDarkMode ? 'white' : '#2C3E50' }
                    ]}>
                      {range.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Popularity Filter */}
            <View style={styles.filterSection}>
              <View style={styles.sectionHeader}>
                <TrendingUp size={20} color="#E74C3C" />
                <Text style={[styles.sectionTitle, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                  Popularidad
                </Text>
              </View>
              <View style={styles.optionsList}>
                {popularityOptions.map((option) => (
                  <TouchableOpacity
                    key={option.id}
                    style={[
                      styles.listOption,
                      selectedPopularity === option.id && styles.selectedListOption
                    ]}
                    onPress={() => setSelectedPopularity(selectedPopularity === option.id ? '' : option.id)}
                  >
                    <View style={styles.listOptionContent}>
                      {typeof option.icon === 'string' ? (
                        <Text style={styles.optionEmoji}>{option.icon}</Text>
                      ) : (
                        <option.icon size={16} color={selectedPopularity === option.id ? 'white' : '#7F8C8D'} />
                      )}
                      <Text style={[
                        styles.listOptionText,
                        selectedPopularity === option.id && styles.selectedListOptionText,
                        { color: isDarkMode ? 'white' : '#2C3E50' }
                      ]}>
                        {option.name}
                      </Text>
                    </View>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </ScrollView>

          {/* Action Buttons */}
          <View style={styles.actions}>
            <TouchableOpacity 
              style={[styles.clearButton, { backgroundColor: isDarkMode ? '#34495E' : '#F8F9FA' }]}
              onPress={clearFilters}
            >
              <Text style={[styles.clearButtonText, { color: isDarkMode ? 'white' : '#2C3E50' }]}>
                Limpiar
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.applyButton} onPress={handleApplyFilters}>
              <Text style={styles.applyButtonText}>Aplicar Filtros</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  modalContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  sidebar: {
    width: '80%',
    maxWidth: 350,
    shadowColor: '#000',
    shadowOffset: { width: -2, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerTitle: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  title: {
    fontSize: 20,
    fontFamily: 'Ubuntu-Bold',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  filterSection: {
    marginBottom: 30,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 15,
  },
  sectionTitle: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  optionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  optionButton: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  selectedOption: {
    backgroundColor: '#009E49',
    borderColor: '#009E49',
  },
  optionText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  selectedOptionText: {
    color: 'white',
  },
  optionsList: {
    gap: 8,
  },
  listOption: {
    padding: 15,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  selectedListOption: {
    backgroundColor: '#009E49',
    borderColor: '#009E49',
  },
  listOptionContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  listOptionText: {
    fontSize: 14,
    fontFamily: 'Inter-Regular',
  },
  selectedListOptionText: {
    color: 'white',
  },
  optionEmoji: {
    fontSize: 16,
  },
  actions: {
    flexDirection: 'row',
    gap: 12,
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
  },
  clearButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E0E0E0',
  },
  clearButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
  },
  applyButton: {
    flex: 2,
    backgroundColor: '#009E49',
    paddingVertical: 12,
    borderRadius: 25,
    alignItems: 'center',
  },
  applyButtonText: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
  },
});