import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { TrendingUp, Palette, Music, UtensilsCrossed, Calendar, Sparkles } from 'lucide-react-native';

interface CategoryTabsProps {
  onCategoryChange?: (category: string) => void;
  isDarkMode?: boolean;
}

const categories = [
  { id: 'tendencias', name: 'Tendencias', icon: TrendingUp, color: '#E74C3C' },
  { id: 'arte', name: 'Arte', icon: Palette, color: '#9B59B6' },
  { id: 'cultura', name: 'Cultura', icon: Sparkles, color: '#009E49' },
  { id: 'gastronomia', name: 'Gastronomía', icon: UtensilsCrossed, color: '#F39C12' },
  { id: 'musica', name: 'Música', icon: Music, color: '#E74C3C' },
  { id: 'eventos', name: 'Eventos', icon: Calendar, color: '#0072C6' },
];

export default function CategoryTabs({ onCategoryChange, isDarkMode = false }: CategoryTabsProps) {
  const [selectedCategory, setSelectedCategory] = useState('tendencias');

  const handleCategoryPress = (categoryId: string) => {
    setSelectedCategory(categoryId);
    onCategoryChange?.(categoryId);
  };

  return (
    <View style={[styles.container, { backgroundColor: isDarkMode ? '#34495E' : '#F8F9FA' }]}>
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.scrollContent}
      >
        {categories.map((category) => {
          const isSelected = selectedCategory === category.id;
          const IconComponent = category.icon;
          
          return (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryTab,
                isSelected && [styles.selectedTab, { backgroundColor: category.color }],
                !isSelected && { backgroundColor: isDarkMode ? '#2C3E50' : 'white' }
              ]}
              onPress={() => handleCategoryPress(category.id)}
            >
              <IconComponent 
                size={18} 
                color={isSelected ? 'white' : (isDarkMode ? '#BDC3C7' : category.color)} 
                strokeWidth={2.5}
              />
              <Text 
                style={[
                  styles.categoryText,
                  isSelected && styles.selectedText,
                  !isSelected && { color: isDarkMode ? '#BDC3C7' : '#2C3E50' }
                ]}
              >
                {category.name}
              </Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  scrollContent: {
    paddingHorizontal: 20,
    gap: 12,
  },
  categoryTab: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 25,
    gap: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  selectedTab: {
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  categoryText: {
    fontSize: 14,
    fontFamily: 'Inter-SemiBold',
  },
  selectedText: {
    color: 'white',
  },
});