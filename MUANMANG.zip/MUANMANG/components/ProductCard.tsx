import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { Star, ShoppingCart } from 'lucide-react-native';

interface ProductCardProps {
  product: {
    id: string;
    name: string;
    price: number;
  image: string;
  seller: string;
  rating: number;
  category: string;
  paymentMethods?: string[];
  };
}

export default function ProductCard({ product }: ProductCardProps) {
  return (
    <TouchableOpacity style={styles.container}>
      <Image source={{ uri: product.image }} style={styles.image} />
      
      <View style={styles.content}>
        <Text style={styles.category}>{product.category}</Text>
        <Text style={styles.name} numberOfLines={2}>{product.name}</Text>
        
        <View style={styles.sellerContainer}>
          <Text style={styles.seller}>por {product.seller}</Text>
          <View style={styles.rating}>
            <Star size={12} color="#FFD700" fill="#FFD700" />
            <Text style={styles.ratingText}>{product.rating}</Text>
          </View>
        </View>
        
        <View style={styles.footer}>
          <Text style={styles.price}>{product.price.toLocaleString()} XAF</Text>
          <TouchableOpacity style={styles.cartButton}>
            <ShoppingCart size={16} color="#FF6B35" strokeWidth={2.5} />
            <Text style={styles.cartButtonText}>Comprar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#1a1a1a',
    borderRadius: 15,
    overflow: 'hidden',
    marginBottom: 15,
    borderWidth: 1,
    borderColor: '#333',
  },
  image: {
    width: '100%',
    height: 180,
  },
  content: {
    padding: 15,
  },
  category: {
    fontSize: 11,
    fontFamily: 'Inter-SemiBold',
    color: '#FF6B35',
    textTransform: 'uppercase',
    marginBottom: 5,
  },
  name: {
    fontSize: 16,
    fontFamily: 'Inter-SemiBold',
    color: 'white',
    marginBottom: 8,
    lineHeight: 22,
  },
  sellerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  seller: {
    fontSize: 12,
    fontFamily: 'Inter-Regular',
    color: '#999',
  },
  paymentMethods: {
    flexDirection: 'row',
    gap: 4,
    marginTop: 4,
  },
  rating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 12,
    fontFamily: 'Inter-SemiBold',
    color: '#FFD700',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  price: {
    fontSize: 20,
    fontFamily: 'Ubuntu-Bold',
    color: 'white',
  },
  cartButton: {
    backgroundColor: 'rgba(255, 107, 53, 0.2)',
    padding: 10,
    borderRadius: 25,
  },
});