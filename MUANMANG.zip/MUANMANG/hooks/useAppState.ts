import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface AppState {
  isDarkMode: boolean;
  language: string;
  cart: CartItem[];
  notifications: Notification[];
  unreadMessages: number;
  setDarkMode: (isDark: boolean) => void;
  setLanguage: (lang: string) => void;
  addToCart: (item: CartItem) => void;
  removeFromCart: (itemId: string) => void;
  clearCart: () => void;
  addNotification: (notification: Notification) => void;
  markNotificationAsRead: (notificationId: string) => void;
  setUnreadMessages: (count: number) => void;
}

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
  sellerId: string;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  read: boolean;
  createdAt: Date;
}

export const useAppState = create<AppState>(
  persist(
    (set) => ({
      isDarkMode: false,
      language: 'es',
      cart: [],
      notifications: [],
      unreadMessages: 0,

      setDarkMode: (isDark) => set({ isDarkMode: isDark }),
      
      setLanguage: (lang) => set({ language: lang }),
      
      addToCart: (item) =>
        set((state) => ({
          cart: [...state.cart, item],
        })),
      
      removeFromCart: (itemId) =>
        set((state) => ({
          cart: state.cart.filter((item) => item.id !== itemId),
        })),
      
      clearCart: () => set({ cart: [] }),
      
      addNotification: (notification) =>
        set((state) => ({
          notifications: [notification, ...state.notifications],
        })),
      
      markNotificationAsRead: (notificationId) =>
        set((state) => ({
          notifications: state.notifications.map((notif) =>
            notif.id === notificationId ? { ...notif, read: true } : notif
          ),
        })),
      
      setUnreadMessages: (count) => set({ unreadMessages: count }),
    }),
    {
      name: 'muan-mang-storage',
      getStorage: () => localStorage,
    }
  )
);