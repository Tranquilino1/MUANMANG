import { useState, useEffect, createContext, useContext } from 'react';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  isVerified?: boolean;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Aquí implementaremos la lógica para cargar el usuario desde el almacenamiento local
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      // Simular verificación de token almacenado
      const mockUser = {
        id: '1',
        name: 'Usuario Demo',
        email: 'demo@example.com',
        avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg',
        isVerified: true
      };
      setUser(mockUser);
      setIsAuthenticated(true);
    } catch (error) {
      console.error('Error al verificar autenticación:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      // Aquí implementaremos la lógica de autenticación real
      const mockUser = {
        id: '1',
        name: 'Usuario Demo',
        email,
        avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg',
        isVerified: true
      };
      setUser(mockUser);
      setIsAuthenticated(true);
    } catch (error) {
      console.error('Error al iniciar sesión:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    // Aquí implementaremos la lógica para limpiar el almacenamiento local
  };

  const register = async (name: string, email: string, password: string) => {
    setIsLoading(true);
    try {
      // Aquí implementaremos la lógica de registro real
      const mockUser = {
        id: '1',
        name,
        email,
        avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg',
        isVerified: false
      };
      setUser(mockUser);
      setIsAuthenticated(true);
    } catch (error) {
      console.error('Error al registrar usuario:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    user,
    isLoading,
    isAuthenticated,
    login,
    logout,
    register
  };
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const auth = useAuth();
  return <AuthContext.Provider value={auth}>{children}</AuthContext.Provider>;
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext debe ser usado dentro de un AuthProvider');
  }
  return context;
}